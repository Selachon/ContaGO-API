// Service worker mínimo — esta extensión no necesita lógica en background.
// El popup maneja todo el flujo directamente.
chrome.runtime.onInstalled.addListener(() => {
  console.log("ContaGO Solución Gratuita DIAN instalada.");
});

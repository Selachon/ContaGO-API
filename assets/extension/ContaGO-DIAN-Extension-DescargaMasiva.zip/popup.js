'use strict';

// ── Estado global ──────────────────────────────────────────────────────────────
let cancelled = false;
let dianTabId = null;
let pendingZipBlob = null;

// ── UI helpers ─────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);

function log(msg, cls = 'log-info') {
  const box = $('logBox');
  const line = document.createElement('div');
  line.className = cls;
  line.textContent = msg;
  box.appendChild(line);
  box.scrollTop = box.scrollHeight;
}

function setStep(text, pct) {
  $('progressStep').textContent = text;
  if (pct != null) $('progressBar').style.width = pct + '%';
}

function showProgress() {
  $('progressSection').style.display = 'block';
  $('resultSection').style.display = 'none';
  $('logBox').textContent = '';
  $('progressBar').style.width = '0%';
}

function showResult(text, isError = false) {
  const sec = $('resultSection');
  sec.style.display = 'block';
  sec.className = isError ? 'error' : '';
  $('resultText').textContent = text;
}

function setRunning(running) {
  $('btnStart').disabled = running;
  $('btnCancel').style.display = running ? 'block' : 'none';
}

// ── Validación ─────────────────────────────────────────────────────────────────
function validateDate(s) {
  return /^\d{2}\/\d{2}\/\d{4}$/.test(s);
}

function autofmtDate(input) {
  input.addEventListener('input', () => {
    let v = input.value.replace(/\D/g, '').slice(0, 8);
    if (v.length >= 5) v = v.slice(0,2) + '/' + v.slice(2,4) + '/' + v.slice(4);
    else if (v.length >= 3) v = v.slice(0,2) + '/' + v.slice(2);
    input.value = v;
  });
}
autofmtDate($('fromDate'));
autofmtDate($('toDate'));

// ── Tab helpers ────────────────────────────────────────────────────────────────

/** Espera que el tab navegue a una URL que supere el predicado, o timeout */
function waitForTabUrl(tabId, predicate, timeoutMs = 30000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error('Timeout esperando redirect del token'));
    }, timeoutMs);

    const listener = (id, info, tab) => {
      if (id !== tabId) return;
      if (info.status === 'complete' && tab.url && predicate(tab.url)) {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(tab.url);
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

/** Espera que el tab esté en status=complete con URL que empieza con prefix */
function waitForTabLoad(tabId, urlPrefix, timeoutMs = 20000) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      reject(new Error(`Timeout cargando ${urlPrefix}`));
    }, timeoutMs);

    const listener = (id, info, tab) => {
      if (id !== tabId) return;
      if (info.status === 'complete' && tab.url && tab.url.startsWith(urlPrefix)) {
        clearTimeout(timer);
        chrome.tabs.onUpdated.removeListener(listener);
        resolve(tab.url);
      }
    };
    chrome.tabs.onUpdated.addListener(listener);
  });
}

function delay(ms) {
  return new Promise(r => setTimeout(r, ms));
}

/** Ejecuta una función en el tab y devuelve el resultado */
async function runInTab(tabId, func, args = []) {
  const results = await chrome.scripting.executeScript({
    target: { tabId, allFrames: false },
    func,
    args,
  });
  if (!results || results.length === 0) throw new Error('Sin resultado del tab');
  if (results[0].result instanceof Error) throw results[0].result;
  return results[0].result;
}

// ── Lógica principal ───────────────────────────────────────────────────────────

async function startDownload() {
  const tokenUrl = $('tokenUrl').value.trim();
  const fromDate = $('fromDate').value.trim();
  const toDate = $('toDate').value.trim();
  const includePdf = $('includePdf').checked;

  // Validar
  if (!tokenUrl.includes('catalogo-vpfe.dian.gov.co/User/AuthToken')) {
    $('tokenUrl').classList.add('error');
    $('tokenHint').textContent = 'El URL debe ser de catalogo-vpfe.dian.gov.co/User/AuthToken';
    return;
  }
  $('tokenUrl').classList.remove('error');
  $('tokenHint').textContent = '';

  if (!validateDate(fromDate) || !validateDate(toDate)) {
    alert('Ingresa las fechas en formato dd/mm/aaaa');
    return;
  }

  cancelled = false;
  pendingZipBlob = null;
  $('btnDownload').style.display = 'none';
  setRunning(true);
  showProgress();

  try {
    await runDownloadFlow(tokenUrl, fromDate, toDate, includePdf);
  } catch (err) {
    if (!cancelled) {
      log('Error: ' + err.message, 'log-err');
      showResult('Error: ' + err.message, true);
    }
  } finally {
    // Cerrar el tab de DIAN si sigue abierto
    if (dianTabId != null) {
      chrome.tabs.remove(dianTabId).catch(() => {});
      dianTabId = null;
    }
    setRunning(false);
  }
}

async function runDownloadFlow(tokenUrl, fromDate, toDate, includePdf) {
  // ── 1. Abrir tab del token (en segundo plano) ──────────────────────────
  setStep('Autenticando con DIAN...', 5);
  log('Abriendo sesión DIAN...');

  const authTab = await chrome.tabs.create({ url: tokenUrl, active: false });
  dianTabId = authTab.id;

  // Esperar que el AuthToken redirija (la URL deja de tener /User/AuthToken)
  await waitForTabUrl(
    authTab.id,
    url => !url.includes('/User/AuthToken'),
    30000
  );
  if (cancelled) return;

  log('Sesión establecida en catalogo-vpfe ✓', 'log-ok');
  await delay(1500);

  // ── 2. Navegar a la Solución Gratuita ─────────────────────────────────
  setStep('Abriendo Solución Gratuita...', 15);
  log('Navegando a gratis-vpfe.dian.gov.co...');

  // RedirectToBiller lleva de catalogo → gratis-vpfe
  await chrome.tabs.update(authTab.id, { url: 'https://catalogo-vpfe.dian.gov.co/User/RedirectToBiller' });
  await waitForTabLoad(authTab.id, 'https://gratis-vpfe.dian.gov.co/', 20000).catch(() => {});
  if (cancelled) return;
  await delay(1500);

  // ── 3. Ir a Documentos Recibidos ───────────────────────────────────────
  setStep('Abriendo Documentos Recibidos...', 25);
  log('Navegando a /Document/Received...');

  await chrome.tabs.update(authTab.id, { url: 'https://gratis-vpfe.dian.gov.co/Document/Received' });
  await waitForTabLoad(authTab.id, 'https://gratis-vpfe.dian.gov.co/', 20000);
  if (cancelled) return;
  await delay(2000);

  // ── 4. Leer CurrentAccountId del DOM ──────────────────────────────────
  const accountId = await runInTab(authTab.id, () => {
    const el = document.querySelector('[name="CurrentAccountId"]') ||
               document.getElementById('CurrentAccountId');
    return el ? el.value : '';
  });

  if (!accountId) {
    throw new Error('No se pudo leer CurrentAccountId. ¿La sesión es válida?');
  }
  log('Cuenta DIAN detectada: ' + accountId.slice(0, 8) + '...', 'log-ok');

  // ── 5. POST del formulario de fechas vía fetch (sin navegar la página) ─
  setStep('Aplicando filtro de fechas...', 35);
  log(`Filtrando del ${fromDate} al ${toDate}...`);

  await runInTab(authTab.id, async ([acctId, from, to]) => {
    const body = new URLSearchParams({
      CurrentAccountId: acctId,
      DocumentTypeId: '',
      SenderName: '',
      From: from,
      To: to,
      SenderCode: '',
      StatusId: '',
      Serie: '',
    }).toString();
    await fetch('/Document/Received', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body,
      credentials: 'include',
    });
  }, [accountId, fromDate, toDate]);

  if (cancelled) return;
  await delay(500);

  // ── 6. Obtener total de documentos ────────────────────────────────────
  setStep('Listando documentos...', 45);

  const total = await runInTab(authTab.id, async (params) => {
    const resp = await fetch('/Document/GetReceivedDocuments', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: params,
      credentials: 'include',
    });
    const json = await resp.json();
    return (json.recordsFiltered ?? json.recordsTotal ?? 0);
  }, buildDtParams(0, 1, 1));

  if (cancelled) return;

  if (total === 0) {
    log('No se encontraron documentos en el rango indicado.', 'log-err');
    showResult('Sin documentos en el rango seleccionado.');
    return;
  }

  log(`${total} documentos encontrados ✓`, 'log-ok');

  // ── 7. Traer la lista completa ─────────────────────────────────────────
  setStep(`Obteniendo ${total} documentos...`, 50);

  const docs = await runInTab(authTab.id, async ([params]) => {
    const resp = await fetch('/Document/GetReceivedDocuments', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        'X-Requested-With': 'XMLHttpRequest',
      },
      body: params,
      credentials: 'include',
    });
    const json = await resp.json();
    return (json.data || []).map(row => {
      const txId = row.DT_RowId || row.DT_RowData?.pkey || '';
      const dateM = (row.docDate || '').match(/>([\d/]+)</);
      const senderM = (row.docReceiverName || '').match(/>([^<]+)</);
      const totalM = (row.docTotalAmount || '').match(/>([\s\S]+?)</);
      return {
        transactionId: txId,
        docNumber: row.docNumber || '',
        issueDate: dateM ? dateM[1] : (row.DT_RowDate || ''),
        senderName: senderM ? senderM[1].trim() : '',
        total: totalM ? totalM[1].trim() : '',
      };
    });
  }, [buildDtParams(0, total, 2)]);

  if (cancelled) return;

  // ── 8. Descargar XMLs (y PDFs si se pidió) ────────────────────────────
  setStep('Descargando archivos...', 55);
  log(`Descargando ${docs.length} XMLs...`);

  // Descargar en lotes de 5 para no saturar
  const BATCH = 5;
  const allFiles = []; // { name, b64, mime }
  let done = 0;

  for (let i = 0; i < docs.length && !cancelled; i += BATCH) {
    const batch = docs.slice(i, i + BATCH);
    const batchResult = await runInTab(authTab.id, async ([batchDocs, withPdf]) => {
      const results = [];
      for (const doc of batchDocs) {
        if (!doc.transactionId) continue;
        try {
          // XML
          const xmlResp = await fetch(
            `/Document/DownloadXml?transactionId=${doc.transactionId}&type=2`,
            { credentials: 'include' }
          );
          if (xmlResp.ok) {
            const buf = await xmlResp.arrayBuffer();
            const bytes = new Uint8Array(buf);
            let b64 = '';
            for (let j = 0; j < bytes.length; j += 8192) {
              b64 += btoa(String.fromCharCode(...bytes.slice(j, Math.min(j + 8192, bytes.length))));
            }
            results.push({ name: doc.docNumber.replace(/[^\w\-]/g, '_') + '.xml', b64, mime: 'application/xml', docNumber: doc.docNumber });
          } else {
            results.push({ error: `XML ${doc.docNumber}: HTTP ${xmlResp.status}`, docNumber: doc.docNumber });
          }

          // PDF opcional
          if (withPdf) {
            const pdfResp = await fetch(
              `/IoFacturo/Print/PrintStoragePdf?transactionId=${doc.transactionId}&viewMode=attachment`,
              { credentials: 'include' }
            );
            if (pdfResp.ok) {
              const buf = await pdfResp.arrayBuffer();
              const bytes = new Uint8Array(buf);
              let b64 = '';
              for (let j = 0; j < bytes.length; j += 8192) {
                b64 += btoa(String.fromCharCode(...bytes.slice(j, Math.min(j + 8192, bytes.length))));
              }
              results.push({ name: doc.docNumber.replace(/[^\w\-]/g, '_') + '.pdf', b64, mime: 'application/pdf', docNumber: doc.docNumber });
            }
          }
        } catch (e) {
          results.push({ error: String(e), docNumber: doc.docNumber });
        }
      }
      return results;
    }, [batch, includePdf]);

    for (const f of batchResult) {
      if (f.error) {
        log('Error: ' + f.error, 'log-err');
      } else {
        allFiles.push(f);
        done++;
        const pct = 55 + Math.round((done / docs.length) * 35);
        setStep(`Descargando... (${done}/${docs.length})`, pct);
        log(`✓ ${f.docNumber}`, 'log-ok');
      }
    }
  }

  if (cancelled) {
    showResult('Descarga cancelada.', true);
    return;
  }

  if (allFiles.length === 0) {
    throw new Error('No se pudo descargar ningún archivo.');
  }

  // ── 9. Empaquetar ZIP ─────────────────────────────────────────────────
  setStep('Generando ZIP...', 92);
  log('Empaquetando archivos...');

  const zip = new JSZip();
  for (const f of allFiles) {
    zip.file(f.name, f.b64, { base64: true });
  }

  pendingZipBlob = await zip.generateAsync({ type: 'blob', compression: 'DEFLATE' });

  const xmlCount = allFiles.filter(f => f.name.endsWith('.xml')).length;
  const pdfCount = allFiles.filter(f => f.name.endsWith('.pdf')).length;
  const summary = `${xmlCount} XMLs${pdfCount ? ' + ' + pdfCount + ' PDFs' : ''} listos`;

  setStep('¡Listo!', 100);
  log(summary, 'log-ok');
  showResult(`Descarga completa: ${summary}`);

  $('btnDownload').style.display = 'block';
  $('btnDownload').onclick = () => triggerZipDownload(fromDate, toDate);
}

/** Construye body para llamadas a /Document/GetReceivedDocuments */
function buildDtParams(start, length, draw) {
  const cols = [
    'rowCheck', 'docTypeName', 'docNumber', 'issueDate',
    'senderCode', 'senderName', 'total', 'paymentMeans', 'eventStatus', 'actions',
  ];
  const p = new URLSearchParams();
  p.set('draw', String(draw));
  cols.forEach((col, i) => {
    p.set(`columns[${i}][data]`, col);
    p.set(`columns[${i}][name]`, '');
    p.set(`columns[${i}][searchable]`, 'true');
    p.set(`columns[${i}][orderable]`, 'false');
    p.set(`columns[${i}][search][value]`, '');
    p.set(`columns[${i}][search][regex]`, 'false');
  });
  p.set('order[0][column]', '3');
  p.set('order[0][dir]', 'desc');
  p.set('start', String(start));
  p.set('length', String(length));
  p.set('search[value]', '');
  p.set('search[regex]', 'false');
  return p.toString();
}

function triggerZipDownload(from, to) {
  if (!pendingZipBlob) return;
  const safeFrom = from.replace(/\//g, '-');
  const safeTo = to.replace(/\//g, '-');
  const filename = `DIAN-Recibidos_${safeFrom}_${safeTo}.zip`;

  const url = URL.createObjectURL(pendingZipBlob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

// ── Event listeners ────────────────────────────────────────────────────────────
$('btnStart').addEventListener('click', startDownload);

$('btnCancel').addEventListener('click', () => {
  cancelled = true;
  log('Cancelando...', 'log-err');
  if (dianTabId != null) {
    chrome.tabs.remove(dianTabId).catch(() => {});
    dianTabId = null;
  }
  showResult('Descarga cancelada.', true);
  setRunning(false);
});

// Restaurar valores guardados
chrome.storage.local.get(['gratis_token', 'gratis_from', 'gratis_to'], (s) => {
  if (s.gratis_token) $('tokenUrl').value = s.gratis_token;
  if (s.gratis_from) $('fromDate').value = s.gratis_from;
  if (s.gratis_to) $('toDate').value = s.gratis_to;
});

// Guardar valores al cambiar
['tokenUrl', 'fromDate', 'toDate'].forEach(id => {
  $(id).addEventListener('change', () => {
    chrome.storage.local.set({
      gratis_token: $('tokenUrl').value,
      gratis_from: $('fromDate').value,
      gratis_to: $('toDate').value,
    });
  });
});

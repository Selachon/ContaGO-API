// Puente portal ↔ extensión.
//  · Anuncia que la extensión está instalada (para que el portal lo detecte).
//  · Responde a CONTAGO_PING con CONTAGO_PONG.
//  · Reenvía CONTAGO_OPEN_EXT al background para abrir el panel lateral.
// (Una web no puede abrir ni detectar una extensión por sí sola.)
function announce() {
  try { window.postMessage({ type: "CONTAGO_EXT_PRESENT", version: chrome.runtime.getManifest().version }, "*"); } catch (_) {}
}

window.addEventListener("message", (e) => {
  if (e.source !== window || !e.data) return;
  if (e.data.type === "CONTAGO_PING") {
    announce();
  } else if (e.data.type === "CONTAGO_OPEN_EXT") {
    try { chrome.runtime.sendMessage({ type: "CONTAGO_OPEN_EXT" }); } catch (_) {}
  }
});

// Anuncio proactivo al cargar (por si el portal ya estaba escuchando).
announce();
document.addEventListener("DOMContentLoaded", announce);

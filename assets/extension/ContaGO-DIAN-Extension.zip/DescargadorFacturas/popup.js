// ── Modo: popup (toolbar) vs persistente (pestaña o panel lateral) ─────────────
const MODE = new URLSearchParams(window.location.search).get('mode'); // 'tab' | 'panel' | null
const PERSISTENT = MODE === 'tab' || MODE === 'panel';

// Prefetch del id de la ventana actual (para abrir el panel sin perder el gesto del usuario)
let currentWinId = null;
chrome.windows.getCurrent().then(w => { currentWinId = w.id; }).catch(() => {});

if (!PERSISTENT) {
  // En popup guardamos el tab activo (la página de facturas)
  chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
    if (tab) localStorage.setItem('invoiceTabId', String(tab.id));
  });
} else {
  // Ya somos panel/pestaña: el botón de abrir no aplica
  document.getElementById('openTabBtn').style.display = 'none';
}

document.getElementById('openTabBtn').addEventListener('click', () => {
  // Abrir como panel lateral (sidebar) pegado a la página, sin cerrarse al hacer clic
  try {
    chrome.sidePanel.setOptions({ path: 'popup.html?mode=panel', enabled: true });
    chrome.sidePanel.open({ windowId: currentWinId });
    window.close();
  } catch (_) {
    // Respaldo: abrir en pestaña si el panel lateral no está disponible
    chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') + '?mode=tab' });
    window.close();
  }
});

// ── Encontrar la pestaña de facturas ──────────────────────────────────────────
async function findInvoiceTab() {
  // 1. Buscar por URL (más confiable cuando estamos en modo pestaña)
  try {
    const byUrl = await chrome.tabs.query({ url: '*://catalogo-vpfe.dian.gov.co/*' });
    if (byUrl.length > 0) return byUrl[0];
  } catch (_) {}

  // 2. Usar el tab guardado cuando se abrió el popup
  const savedId = parseInt(localStorage.getItem('invoiceTabId') || '0');
  if (savedId) {
    try { return await chrome.tabs.get(savedId); } catch (_) {}
  }

  // 3. Tab activo como último recurso
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  return active;
}

// ── State ──────────────────────────────────────────────────────────────────────
let cufes = [];
let running = false;
let stopRequested = false;
let fatalReason = '';   // motivo de corte del proceso (p. ej. NIT no autorizado)
let okCount = 0;
let errCount = 0;
let pauseResolver = null; // resuelve la promesa de pausa
let reauthResolver = null; // resuelve la promesa de re-login (token nuevo)
let currentDownloadLabel = null; // CUFE en curso, para nombrar el archivo descargado
let dlCount = 0;                 // descargas de factura iniciadas (para detectar éxito)
let startTime = 0;               // inicio del proceso (para cronómetro y velocidad)
let timerInterval = null;        // intervalo del cronómetro

let listingTipo = null;   // 'recibido' | 'emitido'
let downloadFolder = '';  // nombre de la carpeta destino calculado del listado

// Construye el nombre de carpeta: "<NIT> - <Nombre> - Facturas <Recibidas/Emitidas> DIAN <AAAA-MM-DD>"
function buildFolderName(tipo, nit, nombre) {
  const fecha = new Date().toISOString().slice(0, 10);
  const tipoTxt = tipo === 'emitido' ? 'Emitidas' : 'Recibidas';
  const clean = (s) => String(s || '').replace(/[\\/:*?"<>|]/g, ' ').replace(/\s+/g, ' ').trim();
  const nitTxt = clean(nit) || 'SIN-NIT';
  const nomTxt = clean(nombre) || 'Empresa';
  return `${nitTxt} - ${nomTxt} - Facturas ${tipoTxt} DIAN ${fecha}`;
}

// Enruta las descargas de facturas. En Descarga Masiva quedan en la carpeta con
// nombre = CUFE. En Exportador, los bytes ya se capturan por CDP; el archivo va a
// una carpeta temporal y se borra al completarse (modo "sin disco").
let pendingExcelName = null;   // nombre a forzar para la descarga del Excel (blob)
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  // Excel consolidado: el blob no lleva nombre, así que lo fijamos explícitamente.
  if (pendingExcelName && item.url && item.url.startsWith('blob:')) {
    const n = pendingExcelName; pendingExcelName = null;
    suggest({ filename: n, conflictAction: 'uniquify' });
    return;
  }
  // Descarga Masiva: el ZIP cae a la carpeta con nombre = CUFE. (En Exportador no
  // hay descarga a disco: los bytes se capturan por CDP y la petición se aborta.)
  if (!EXPORT_MODE && currentDownloadLabel && item.url && item.url.includes('DownloadZipFiles')) {
    dlCount++;
    const folder = downloadFolder || 'FacturasDIAN';
    suggest({ filename: `${folder}/${currentDownloadLabel}.zip`, conflictAction: 'uniquify' });
    return;
  }
  suggest();
});

// ── Integración ContaGO: activación + modo + captura por CDP ───────────────────
let EXPORT_MODE = false;            // false = Descarga Masiva (local); true = backend (Exportador o Terceros)
let jobKind = 'invoices';           // 'invoices' (Exportador) | 'terceros'
let uploadedFile = null;           // File del listado (para crear el job del Exportador)
let currentJob = null;             // { jobId, direction, records, driveFolderUrl }
const recordMap = new Map();       // cufe -> docnum (de los records del backend)
const pendingCaptures = new Map(); // tabId -> { resolve } captura CDP en curso
let driveSel = null;               // { connected, selectedConnectionId }
let exporterCfg = null;            // { uploadToDrive, includeDriveLinks, driveConnectionId } del portal
let allowedModes = { masiva: true, exportador: true, terceros: true }; // se ajusta según la cuenta
let isAdminUser = false;
let mergePdf = false;              // Descarga Masiva: unir todos los PDF en uno
let pdfParts = [];                 // [{ i, bytes }] PDFs capturados para fusionar

// Estado del proceso (compartido y persistible para poder REANUDAR si se cierra el panel)
let itemDone = [];
let deferred = [];
let deferredSet = new Set();
let isResuming = false;            // la corrida actual es una reanudación
let pendingResume = null;          // snapshot cargado de chrome.storage al reabrir

const RUN_KEY = 'contago_run';
const RUN_TTL_MS = 3 * 60 * 60 * 1000; // 3h (igual que el job del backend)

// Guarda el progreso para poder reanudar tras cerrar el panel. Se llama tras cada factura.
function persistRunNow() {
  if (!running) return;
  try {
    const mode = !EXPORT_MODE ? 'masiva' : (jobKind === 'terceros' ? 'terceros' : 'exportador');
    const doneIdx = [];
    for (let i = 0; i < itemDone.length; i++) if (itemDone[i]) doneIdx.push(i);
    const snap = {
      v: 1, ts: Date.now(), mode,
      jobId: currentJob?.jobId || null,
      driveFolderUrl: currentJob?.driveFolderUrl || null,
      cufes, total: cufes.length,
      doneIdx, deferredIdx: deferred.slice(),
      okCount, errCount, listingTipo, downloadFolder,
      records: Object.fromEntries(recordMap),
    };
    chrome.storage.local.set({ [RUN_KEY]: snap }).catch(() => {});
  } catch (_) {}
}
function clearRun() { try { chrome.storage.local.remove(RUN_KEY); } catch (_) {} }
async function loadSavedRun() {
  try {
    const { [RUN_KEY]: s } = await chrome.storage.local.get(RUN_KEY);
    if (!s || !s.cufes?.length) return null;
    if (Date.now() - (s.ts || 0) > RUN_TTL_MS) { clearRun(); return null; }
    const pending = s.total - (s.doneIdx?.length || 0);
    if (pending <= 0) { clearRun(); return null; }   // ya estaba todo hecho
    return s;
  } catch (_) { return null; }
}

// Extrae el PDF (representación gráfica) de los bytes de un ZIP de la DIAN.
async function extractPdfFromZipBytes(bytes) {
  try {
    const zip = await JSZip.loadAsync(bytes);
    const entry = Object.values(zip.files).find(f => !f.dir && /\.pdf$/i.test(f.name));
    if (!entry) return null;
    return await entry.async('uint8array');
  } catch (_) { return null; }
}

// Une todos los PDF capturados en uno solo y lo descarga.
async function buildAndDownloadMergedPdf() {
  const parts = pdfParts.slice().sort((a, b) => a.i - b.i);
  if (!parts.length) { setLog('No se capturó ningún PDF para unir.', 'warn'); return; }
  setLog(`Uniendo ${parts.length} PDF en uno…`, 'ok');
  const { PDFDocument } = window.PDFLib;
  const out = await PDFDocument.create();
  let added = 0;
  for (const p of parts) {
    try {
      const src = await PDFDocument.load(p.bytes, { ignoreEncryption: true });
      const pages = await out.copyPages(src, src.getPageIndices());
      pages.forEach(pg => out.addPage(pg));
      added++;
    } catch (_) { /* PDF dañado: se omite */ }
  }
  if (!added) { setLog('No se pudo unir ningún PDF (archivos no válidos).', 'err'); return; }
  const blob = new Blob([await out.save()], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const name = `${downloadFolder || 'Facturas DIAN'}.pdf`;
  pendingExcelName = name; // reusa el forzado de nombre del listener (blob)
  await chrome.downloads.download({ url, filename: name, saveAs: false });
  setTimeout(() => { try { URL.revokeObjectURL(url); } catch (_) {} }, 60000);
  setLog(`📄 PDF unificado con ${added} factura(s) descargado.`, 'ok');
}

function deviceLabel() {
  return (navigator.userAgentData?.platform || navigator.platform || 'Equipo') + ' · ' + new Date().toISOString().slice(0, 10);
}

// Desenvuelve enlaces protegidos por Outlook SafeLinks
// (na01.safelinks.protection.outlook.com/?url=<enlace DIAN codificado>&...).
// Devuelve el enlace DIAN interno; si no es SafeLinks, devuelve el original.
function normalizeAccessLink(link) {
  let url = (link || '').trim();
  for (let i = 0; i < 3; i++) { // por si viene anidado
    try {
      const u = new URL(url);
      if (/(^|\.)safelinks\.protection\.outlook\.com$/i.test(u.hostname) && u.searchParams.get('url')) {
        url = u.searchParams.get('url'); // URLSearchParams ya lo decodifica una vez
        continue;
      }
    } catch (_) {}
    break;
  }
  return url;
}

async function refreshAuthUI() {
  const { token, user, apiBase } = await ContaGO.getAuth();
  const authed = !!token;
  document.getElementById('authCard').classList.toggle('hidden', authed);
  document.getElementById('accountBar').classList.toggle('hidden', !authed);
  document.getElementById('modeCard').classList.toggle('hidden', !authed);
  document.getElementById('toolArea').classList.toggle('hidden', !authed);
  const apiInput = document.getElementById('apiBaseInput');
  if (apiInput && !apiInput.value) apiInput.value = apiBase || '';
  if (authed && user) {
    document.getElementById('accountName').textContent = user.name || 'Cuenta activada';
    document.getElementById('accountEmail').textContent = user.email || '';
  }
  if (authed) {
    try { exporterCfg = await ContaGO.getExporterConfig(); } catch (_) { exporterCfg = null; }
    await loadTools();
  }
}

// Habilita en la extensión solo los modos cuya herramienta tenga el usuario.
async function loadTools() {
  try {
    const t = await ContaGO.getTools();
    isAdminUser = !!t.isAdmin;
    allowedModes = isAdminUser
      ? { masiva: true, exportador: true, terceros: true }
      : { masiva: !!t.modes.masiva, exportador: !!t.modes.exportador, terceros: !!t.modes.terceros };
  } catch (_) {}
  applyModeAccess();
}

function firstAllowedMode() {
  return ['masiva', 'exportador', 'terceros'].find((m) => allowedModes[m]) || null;
}

function applyModeAccess() {
  for (const btn of document.querySelectorAll('.mode-btn')) {
    const m = btn.dataset.mode;
    const ok = !!allowedModes[m];
    btn.disabled = !ok;
    btn.style.opacity = ok ? '1' : '0.5';
    btn.style.cursor = ok ? 'pointer' : 'not-allowed';
    btn.title = ok ? '' : 'No tienes esta herramienta habilitada en tu cuenta';
    const sub = btn.querySelectorAll('div')[1];
    if (sub) {
      if (sub.dataset.label === undefined) sub.dataset.label = sub.textContent;
      sub.textContent = ok ? sub.dataset.label : '🔒 No habilitada';
    }
  }
  // SIEMPRE re-aplicar el modo (no solo si el actual está bloqueado): setMode es
  // lo que muestra el toggle de "unir PDF" en Masiva, la pista del Drive, etc.
  // Si el modo activo está permitido se conserva; si no, se pasa al primero válido.
  const current = document.querySelector('.mode-btn.active')?.dataset.mode;
  const target = (current && allowedModes[current]) ? current : firstAllowedMode();
  if (target) setMode(target);
}

function setMode(mode) {
  if (!allowedModes[mode]) { setLog('No tienes esta herramienta habilitada en tu cuenta.', 'warn'); return; }
  EXPORT_MODE = mode !== 'masiva';                 // exportador y terceros usan el backend
  jobKind = mode === 'terceros' ? 'terceros' : 'invoices';
  for (const btn of document.querySelectorAll('.mode-btn')) {
    const on = btn.dataset.mode === mode;
    btn.classList.toggle('active', on);
    btn.style.borderColor = on ? 'var(--purple)' : '#e0e0e0';
    btn.style.background = on ? '#f4ecfb' : 'white';
    btn.querySelector('div').style.color = on ? 'var(--purple-dark)' : '#666';
  }
  const sub = document.querySelector('#uploadArea .upload-sub');
  if (sub) {
    sub.textContent = mode === 'terceros'
      ? 'Generará el Excel de terceros consolidado'
      : mode === 'exportador'
        ? (exporterCfg?.uploadToDrive ? 'Irá a Drive + Excel consolidado (según el portal)' : 'Generará el Excel consolidado (según el portal)')
        : 'El Excel debe tener columna CUFE/CUDE';
  }
  // Opción "unir PDF" solo aplica en Descarga Masiva
  const mo = document.getElementById('masivaOptions');
  if (mo) mo.style.display = mode === 'masiva' ? 'flex' : 'none';
}

document.getElementById('activateBtn').addEventListener('click', async () => {
  const msg = document.getElementById('authMsg');
  const code = (document.getElementById('activationInput').value || '').trim();
  const apiOverride = (document.getElementById('apiBaseInput').value || '').trim();
  if (code.length < 6) { msg.textContent = 'Pega el código de activación.'; msg.style.color = '#e53935'; return; }
  msg.textContent = 'Activando…'; msg.style.color = '#888';
  try {
    if (apiOverride) await ContaGO.setApiBase(apiOverride);
    const user = await ContaGO.activate(code, deviceLabel());
    msg.textContent = '✓ Activada: ' + (user.email || '');
    msg.style.color = 'var(--purple)';
    await refreshAuthUI();   // carga herramientas y selecciona el primer modo permitido
  } catch (e) {
    msg.textContent = '✗ ' + (e.message || 'No se pudo activar');
    msg.style.color = '#e53935';
  }
});

document.getElementById('logoutBtn').addEventListener('click', async () => {
  await ContaGO.logout();
  await refreshAuthUI();
});

document.getElementById('modeMasiva').addEventListener('click', () => setMode('masiva'));
document.getElementById('modeExport').addEventListener('click', () => setMode('exportador'));
document.getElementById('modeTerceros').addEventListener('click', () => setMode('terceros'));
document.getElementById('reloadToolsBtn').addEventListener('click', async (e) => {
  const btn = e.currentTarget;
  const prev = btn.textContent; btn.textContent = '↻ …'; btn.disabled = true;
  try { exporterCfg = await ContaGO.getExporterConfig(); } catch (_) {}
  await loadTools();
  btn.textContent = prev; btn.disabled = false;
});

// ── Reanudar un proceso interrumpido ──────────────────────────────────────────
async function offerResumeIfAny() {
  const s = await loadSavedRun();
  if (!s) return;
  pendingResume = s;
  const done = s.doneIdx?.length || 0;
  const pending = s.total - done;
  const modeTxt = s.mode === 'masiva' ? 'Descarga Masiva' : s.mode === 'terceros' ? 'Terceros' : 'Exportador';
  document.getElementById('resumeMsg').textContent =
    `Quedó a medias (${modeTxt}): ${done}/${s.total} listas, faltan ${pending}. Reanuda donde quedó sin perder lo avanzado.`;
  document.getElementById('resumeBanner').classList.remove('hidden');
}

function doResumeRestore(s) {
  cufes = s.cufes || [];
  itemDone = new Array(cufes.length).fill(false);
  for (const i of (s.doneIdx || [])) if (i < itemDone.length) itemDone[i] = true;
  deferred = (s.deferredIdx || []).slice();
  deferredSet = new Set(deferred);
  okCount = s.okCount || 0; errCount = s.errCount || 0;
  listingTipo = s.listingTipo || 'recibido';
  downloadFolder = s.downloadFolder || '';
  recordMap.clear();
  for (const [c, d] of Object.entries(s.records || {})) recordMap.set(c, d);
  currentJob = s.jobId ? { jobId: s.jobId, driveFolderUrl: s.driveFolderUrl || null } : null;
  EXPORT_MODE = s.mode !== 'masiva';
  jobKind = s.mode === 'terceros' ? 'terceros' : 'invoices';
  try { setMode(s.mode); } catch (_) {}   // UI del modo (si la cuenta lo permite)
  isResuming = true;
  renderList();
  for (let i = 0; i < itemDone.length; i++) if (itemDone[i]) setItemState(i, 'done', '✅', 'Hecho');
  document.getElementById('statTotal').textContent = cufes.length;
  document.getElementById('statOk').textContent = okCount;
  document.getElementById('statErr').textContent = errCount;
  document.getElementById('progressCard').classList.remove('hidden');
  updateProgress(okCount + errCount);
  const pending = cufes.length - itemDone.filter(Boolean).length;
  const btn = document.getElementById('actionBtn');
  btn.disabled = false; btn.className = 'start';
  btn.textContent = `▶ Reanudar (faltan ${pending})`;
  document.getElementById('resumeBanner').classList.add('hidden');
  setLog(`Listo para reanudar ${pending} factura(s). Pega el enlace de acceso DIAN y pulsa Reanudar.`, 'ok');
}

document.getElementById('resumeBtn').addEventListener('click', () => { if (pendingResume) doResumeRestore(pendingResume); });
document.getElementById('discardResumeBtn').addEventListener('click', () => {
  clearRun(); pendingResume = null;
  document.getElementById('resumeBanner').classList.add('hidden');
});

refreshAuthUI().then(offerResumeIfAny);

// ── File upload ────────────────────────────────────────────────────────────────
document.getElementById('uploadArea').addEventListener('click', () => {
  document.getElementById('fileInput').click();
});

document.getElementById('fileInput').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  uploadedFile = file; // se reenvía al backend para crear el job del Exportador
  // Archivo nuevo = corrida fresca: descarta cualquier reanudación pendiente.
  isResuming = false; pendingResume = null;
  document.getElementById('resumeBanner').classList.add('hidden');
  setLog('Leyendo archivo...');
  resetProgress();
  const btn = document.getElementById('actionBtn');
  try {
    const result = file.name.toLowerCase().endsWith('.zip')
      ? await readCufesFromZip(file)
      : await readCufesFromExcel(file);

    cufes = result.cufes || [];
    if (cufes.length === 0) { setLog('No se encontró la columna CUFE/CUDE o está vacía.', 'err'); return; }

    document.getElementById('uploadFilename').textContent = `✓ ${file.name}  (${cufes.length} registros)`;
    document.getElementById('uploadFilename').classList.remove('hidden');
    document.getElementById('uploadArea').classList.add('has-file');
    document.getElementById('statTotal').textContent = cufes.length;
    renderList();
    document.getElementById('progressCard').classList.remove('hidden');

    // ── Listado mixto: no se puede procesar ──
    if (result.mixed) {
      listingTipo = null; downloadFolder = '';
      btn.disabled = true; btn.className = 'start';
      btn.textContent = 'Listado mixto — no se puede procesar';
      setLog('⚠️ El listado tiene facturas RECIBIDAS y EMITIDAS mezcladas. Sepáralas en dos archivos y procesa uno a la vez.', 'err');
      return;
    }

    // ── Tipo + carpeta destino ──
    listingTipo = result.tipo || 'recibido'; // si no se detectó, se asume recibidas
    downloadFolder = buildFolderName(listingTipo, result.nit, result.nombre);
    const tipoTxt = listingTipo === 'emitido' ? 'EMITIDAS' : 'RECIBIDAS';
    const destino = listingTipo === 'emitido' ? 'Documentos enviados' : 'Documentos recibidos';

    btn.disabled = false;
    btn.className = 'start';
    btn.textContent = `Iniciar descarga (${cufes.length} facturas)`;
    updateETA();

    const nominaTxt = result.omittedNomina ? ` · ${result.omittedNomina} de nómina omitidas` : '';
    setLog(`${cufes.length} facturas ${tipoTxt}${nominaTxt}. Irá a ${destino}.`, 'ok');
    document.getElementById('uploadFilename').textContent =
      `✓ ${file.name} · ${cufes.length} facturas ${tipoTxt}` +
      (result.omittedNomina ? ` (${result.omittedNomina} de nómina omitidas)` : '') +
      (result.tipo ? '' : ' (tipo no detectado → asumo Recibidas)') +
      `\n📁 ${downloadFolder}`;
    document.getElementById('uploadFilename').style.whiteSpace = 'pre-line';
  } catch (err) {
    setLog('Error leyendo archivo: ' + err.message, 'err');
  }
});

// ── Excel / ZIP parsing ────────────────────────────────────────────────────────
async function readCufesFromZip(file) {
  const zip = await JSZip.loadAsync(file);
  const entry = Object.values(zip.files).find(f => /\.(xlsx|xls|xlsm)$/i.test(f.name) && !f.dir);
  if (!entry) throw new Error('No se encontró ningún Excel dentro del ZIP.');
  return parseExcelBuffer(await entry.async('arraybuffer'));
}
async function readCufesFromExcel(file) {
  return parseExcelBuffer(await file.arrayBuffer());
}
function parseExcelBuffer(ab) {
  const wb = XLSX.read(ab, { type: 'array' });
  if (!wb.SheetNames.length) throw new Error('El Excel está vacío.');
  for (const sheet of wb.SheetNames) {
    const rows = XLSX.utils.sheet_to_json(wb.Sheets[sheet], { header: 1, defval: '' });
    if (rows.length < 2) continue;
    const headers = rows[0].map(h => String(h || '').toLowerCase().trim());
    const idx = headers.findIndex(h => h.includes('cufe') || h.includes('cude') || (h.includes('digo') && h.includes('nico')));
    if (idx === -1) continue;

    const tipoIdx = headers.findIndex(h => h.includes('tipo') && h.includes('doc'));
    const grupoIdx = headers.findIndex(h => h.includes('grupo'));
    const emiNitIdx = headers.findIndex(h => h.includes('nit') && h.includes('emisor'));
    const emiNomIdx = headers.findIndex(h => h.includes('nombre') && h.includes('emisor'));
    const recNitIdx = headers.findIndex(h => h.includes('nit') && h.includes('receptor'));
    const recNomIdx = headers.findIndex(h => h.includes('nombre') && h.includes('receptor'));

    // Tipos que NO se descargan: eventos (Application response) y NÓMINA individual
    // (no traen el ZIP/PDF que descarga la extensión → solo harían recargar en vano).
    const norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const isOmitidaNomina = (r) => tipoIdx !== -1 && norm(r[tipoIdx]).includes('nomina');
    const isEvento = (r) => tipoIdx !== -1 && norm(r[tipoIdx]).includes('application response');

    const withCufe = rows.slice(1).filter(r => String(r[idx] || '').trim().length > 20);
    const omittedNomina = withCufe.filter(isOmitidaNomina).length;
    // Filas a procesar: con CUFE, no evento, no nómina
    const dataRows = withCufe.filter(r => !isEvento(r) && !isOmitidaNomina(r));
    if (dataRows.length === 0) continue;

    const cufes = dataRows.map(r => String(r[idx] || '').trim());

    // Tipo del listado según la columna "Grupo": recibido / emitido / mixto
    let tipo = null, mixed = false;
    if (grupoIdx !== -1) {
      const kinds = new Set();
      for (const r of dataRows) {
        const g = String(r[grupoIdx] || '').toLowerCase();
        if (g.includes('recib')) kinds.add('recibido');
        else if (g.includes('emit') || g.includes('envi')) kinds.add('emitido');
      }
      if (kinds.size > 1) mixed = true;
      else if (kinds.size === 1) tipo = [...kinds][0];
    }

    // Empresa procesada: receptor (recibidas) o emisor (emitidas). Valor más frecuente.
    const mostCommon = (colIdx) => {
      if (colIdx < 0) return '';
      const counts = {};
      for (const r of dataRows) { const v = String(r[colIdx] || '').trim(); if (v) counts[v] = (counts[v] || 0) + 1; }
      return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] || '';
    };
    let nit = '', nombre = '';
    if (tipo === 'emitido') { nit = mostCommon(emiNitIdx); nombre = mostCommon(emiNomIdx); }
    else { nit = mostCommon(recNitIdx); nombre = mostCommon(recNomIdx); } // recibido o desconocido → receptor

    return { cufes, tipo, mixed, nit, nombre, omittedNomina };
  }
  const headers = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: '' })[0] || [];
  throw new Error(`Columna CUFE/CUDE no encontrada. Columnas: ${headers.map(h => `"${h}"`).join(', ')}`);
}

// ── Render list ────────────────────────────────────────────────────────────────
function renderList() {
  const list = document.getElementById('cufeList');
  list.innerHTML = '';
  cufes.forEach((cufe, i) => {
    const div = document.createElement('div');
    div.className = 'list-item';
    div.id = `item-${i}`;
    div.innerHTML = `
      <span class="item-num">${i + 1}</span>
      <span class="item-icon" id="icon-${i}">⬜</span>
      <span class="item-cufe" title="${cufe}">${cufe}</span>
      <span class="item-status" id="istatus-${i}">Pendiente</span>`;
    list.appendChild(div);
  });
}

// ── Pausa: esperar acción del usuario ─────────────────────────────────────────
function showPause(msg) {
  document.getElementById('pauseMsg').textContent = msg;
  document.getElementById('pauseBanner').style.display = 'block';
  return new Promise(resolve => { pauseResolver = resolve; });
}
function hidePause() {
  document.getElementById('pauseBanner').style.display = 'none';
  pauseResolver = null;
}

document.getElementById('retryBtn').addEventListener('click', () => {
  if (pauseResolver) { hidePause(); pauseResolver('retry'); }
});
document.getElementById('skipBtn').addEventListener('click', () => {
  if (pauseResolver) { hidePause(); pauseResolver('skip'); }
});

// ── Re-login: pedir un token nuevo (espera indefinida) ────────────────────────
function askNewToken() {
  const banner = document.getElementById('reauthBanner');
  document.getElementById('reauthInput').value = '';
  document.getElementById('reauthMsg').textContent =
    'El token de acceso venció. Pega un enlace de acceso NUEVO para continuar donde quedó. La herramienta espera el tiempo que haga falta.';
  banner.style.display = 'block';
  banner.scrollIntoView({ block: 'center', behavior: 'smooth' });
  return new Promise(resolve => { reauthResolver = resolve; });
}
document.getElementById('reauthBtn').addEventListener('click', () => {
  if (!reauthResolver) return;
  const link = normalizeAccessLink(document.getElementById('reauthInput').value);
  if (!/^https?:\/\//i.test(link)) {
    document.getElementById('reauthMsg').textContent = '⚠️ El enlace debe empezar con http(s):// — pega el enlace completo del correo.';
    return;
  }
  document.getElementById('reauthBanner').style.display = 'none';
  const r = reauthResolver; reauthResolver = null; r(link);
});

// ── Main loop ──────────────────────────────────────────────────────────────────
document.getElementById('actionBtn').addEventListener('click', async () => {
  if (running) {
    stopRequested = true;
    // Si está esperando un token nuevo, cancelar esa espera
    if (reauthResolver) { document.getElementById('reauthBanner').style.display = 'none'; const r = reauthResolver; reauthResolver = null; r(null); }
    document.getElementById('actionBtn').textContent = 'Deteniendo…';
    document.getElementById('actionBtn').disabled = true;
    return;
  }

  // Obtener la pestaña: si pegaron un enlace de acceso, abrimos el portal con él
  let tab;
  const accessLink = normalizeAccessLink(document.getElementById('tokenInput').value);
  if (accessLink) {
    if (!/^https?:\/\//i.test(accessLink)) { setLog('El enlace de acceso debe empezar con http(s)://', 'err'); return; }
    setLog('Abriendo el portal con el enlace de acceso…');
    const r = await accessWithLink(accessLink);
    if (!r.tab) { setLog('No se pudo abrir el enlace de acceso.', 'err'); return; }
    if (r.stuckLogin) { setLog('El enlace sigue redirigiendo al login tras varios intentos. ¿El token es válido y actual?', 'err'); return; }
    tab = r.tab;
  } else {
    tab = await findInvoiceTab();
  }
  if (!tab) { setLog('No se encontró la pestaña de facturas. Abre la página DIAN o pega el enlace de acceso.', 'err'); return; }

  running = true;
  stopRequested = false;
  fatalReason = '';
  if (!isResuming) {
    okCount = 0; errCount = 0;
    // "Unir PDF" solo aplica en Descarga Masiva (debe quedar fijado antes de prepareTabs).
    mergePdf = !EXPORT_MODE && !!document.getElementById('mergePdfChk')?.checked;
    pdfParts = [];
  } else {
    // Reanudación: okCount/errCount/itemDone/deferred/currentJob ya vienen restaurados.
    mergePdf = false; pdfParts = []; // el PDF unificado no se reanuda (los ZIP ya están en disco)
  }
  document.getElementById('statOk').textContent = String(okCount);
  document.getElementById('statErr').textContent = String(errCount);

  const btn = document.getElementById('actionBtn');
  btn.className = 'stop';
  btn.textContent = 'Detener';
  btn.disabled = false;

  // ── Exportador: crear el job en ContaGO (sube el listado y recibe los CUFEs) ──
  // En reanudación NO se crea job nuevo: currentJob y recordMap ya vienen restaurados.
  if (!isResuming) {
  currentJob = null; recordMap.clear();
  if (EXPORT_MODE) {
    if (!uploadedFile) {
      setLog('Sube primero el listado (Excel/ZIP) para el Exportador.', 'err');
      running = false; btn.className = 'start'; btn.disabled = false; btn.textContent = `Iniciar descarga (${cufes.length} facturas)`;
      return;
    }
    setLog('Creando el proceso en ContaGO…');
    try {
      // Parámetros tal cual los configuró el usuario en el portal (Exportador DIAN).
      const cfg = jobKind === 'terceros'
        ? { uploadToDrive: false, includeDriveLinks: false, driveConnectionId: null }
        : await ContaGO.getExporterConfig();
      const job = await ContaGO.createExportJob({
        excelBlob: uploadedFile,
        filename: uploadedFile.name,
        mode: jobKind,
        uploadToDrive: cfg.uploadToDrive,
        driveConnectionId: cfg.driveConnectionId,
        includeDriveLinks: cfg.includeDriveLinks,
      });
      currentJob = job;
      for (const r of (job.records || [])) recordMap.set(r.cufe, r.docnum || '');
      const kindTxt = jobKind === 'terceros' ? 'terceros' : 'facturas';
      const driveTxt = jobKind === 'terceros' ? '' : (cfg.uploadToDrive ? ' · Drive activo' : ' · sin Drive') + (cfg.includeDriveLinks ? ' · con enlaces' : '');
      setLog(`Proceso ContaGO creado (${job.totalProcessable} ${kindTxt})${driveTxt}.`, 'ok');
    } catch (e) {
      setLog('No se pudo crear el proceso en ContaGO: ' + (e.message || e), 'err');
      running = false; btn.className = 'start'; btn.disabled = false; btn.textContent = `Iniciar descarga (${cufes.length} facturas)`;
      return;
    }
  }
  } // /if (!isResuming)

  startTimer();               // cronómetro + velocidad facturas/min
  await setDownloadUi(false); // ocultar la barra/burbuja de descargas durante la corrida

  const MAX_AUTO_RETRIES = 2; // reintentos por CUFE; si falla, va a la cola del final
  const PACE_SEC = 1;         // ritmo fijo entre descargas (1 s)
  const TAB_COUNT = 3;        // pestañas en paralelo (fijo)

  // ── Sección destino según el tipo del listado ──
  const isEmit = listingTipo === 'emitido';
  const DOC_PATH = isEmit ? '/Document/Sent' : '/Document/Received';
  const DOC_URL = 'https://catalogo-vpfe.dian.gov.co' + DOC_PATH;
  const seccion = isEmit ? 'Documentos enviados' : 'Documentos recibidos';

  // ── Estado compartido entre workers ──
  let tabs = [];
  let createdTabs = [];
  if (!isResuming) {
    // facturas en cola (fallaron 2 veces) y completadas; en reanudación ya vienen restauradas
    deferred = []; deferredSet = new Set();
    itemDone = new Array(cufes.length).fill(false);
  }
  let reauthRequested = false;  // alguien detectó token vencido → re-login
  // Salud de las pestañas: se refrescan cada N descargas (la página/reCAPTCHA se
  // degrada tras muchas y el botón deja de responder); enfriamiento si hay racha
  // de fallos (para que la DIAN/captcha se recupere).
  const RELOAD_EVERY = 40;
  const FAIL_COOLDOWN_AT = 8;
  const COOLDOWN_SEC = 45;
  const tabDownloadCount = new Map();   // tabId -> descargas desde el último refresco
  let consecutiveFails = 0;
  let cooldownUntil = 0;
  let lockChain = Promise.resolve();
  const withDownloadLock = (fn) => { const run = lockChain.then(fn); lockChain = run.then(() => {}, () => {}); return run; };
  const exec = (tabId, func, args = []) => chrome.scripting.executeScript({ target: { tabId }, func, args });
  const logAlert = async (tabId, i) => { const m = await readLastAlert(tabId); if (m) setLog(`[#${i + 1}] Alerta aceptada automáticamente: "${m.slice(0, 70)}"`, 'warn'); };

  // Navega la pestaña principal a la sección correcta y abre TAB_COUNT pestañas en paralelo
  async function prepareTabs(primaryTab) {
    await waitNotChallenge(primaryTab.id, 60000); // no navegar durante la verificación de Azure
    const cur = await chrome.tabs.get(primaryTab.id).catch(() => primaryTab);
    if (!new RegExp(DOC_PATH.replace(/\//g, '\\/'), 'i').test(cur.url || '')) {
      setLog(`Navegando a Histórico → ${seccion}…`);
      try { await chrome.tabs.update(primaryTab.id, { url: DOC_URL }); } catch (_) {}
      await waitNotChallenge(primaryTab.id, 60000);
    }
    if (!(await waitTabReady(primaryTab.id, 60000))) { setLog(`No cargó "${seccion}" (¿verificación de Azure o token vencido?).`, 'err'); return false; }
    const newTabs = [primaryTab];
    const newCreated = [];
    for (let n = 1; n < TAB_COUNT; n++) {
      setLog(`Abriendo pestaña ${n + 1} de ${TAB_COUNT} en ${seccion}…`);
      try {
        const dup = await chrome.tabs.duplicate(primaryTab.id); // hereda URL + sesión/token
        if (await waitTabReady(dup.id, 30000)) { newTabs.push(dup); newCreated.push(dup.id); }
        else { try { await chrome.tabs.remove(dup.id); } catch (_) {} setLog(`La pestaña ${n + 1} no quedó lista; sigo con ${newTabs.length}.`, 'warn'); }
      } catch (e) { setLog(`No se pudo abrir la pestaña ${n + 1}.`, 'warn'); }
    }
    for (const t of newTabs) { await attachDialogAutoAccept(t.id); await installAlertAutoAccept(t.id); }
    tabs = newTabs; createdTabs = newCreated;
    setLog(`Procesando con ${tabs.length} pestaña(s)…`);
    return true;
  }

  // ¿Venció el token? La DIAN redirige a /User/Login cuando expira (señal más fiable).
  async function detectExpiry(tabId) {
    try {
      const t = await chrome.tabs.get(tabId);
      if (/\/user\/login/i.test(t.url || '')) return true; // redirigido al login → token vencido
    } catch (_) { return true; } // pestaña perdida → sesión muerta
    try { const r = await exec(tabId, pageStatus); return r?.[0]?.result === 'login'; } catch (_) { return false; }
  }

  // Cierra todo, pide un token NUEVO (espera indefinida) y reabre el proceso donde quedó
  async function doReauth() {
    // marcar como pausadas las que estaban activas
    for (let k = 0; k < cufes.length; k++) {
      const el = document.getElementById(`item-${k}`);
      if (el && el.classList.contains('s-active')) setItemState(k, 'paused', '🔑', 'Pausada (token vencido)');
    }
    await detachDialogAutoAccept();
    for (const id of [...createdTabs]) { try { await chrome.tabs.remove(id); } catch (_) {} }
    try { await chrome.tabs.remove(tab.id); } catch (_) {}
    tabs = []; createdTabs = [];
    setLog(`🔑 Token vencido. Pega un enlace de acceso NUEVO para continuar (van ${okCount}/${cufes.length}).`, 'err');
    const link = await askNewToken();          // espera el tiempo que haga falta
    if (link === null || stopRequested) return false; // el usuario pulsó Detener
    setLog('Reabriendo el portal con el nuevo token…');
    const r = await accessWithLink(link);
    if (stopRequested) return false;
    if (!r.tab || r.stuckLogin) { setLog('El nuevo enlace sigue rebotando al login. Pega otro…', 'err'); return await doReauth(); }
    tab = r.tab;
    if (!(await prepareTabs(tab))) return await doReauth();
    return true;
  }

  // Ritmo entre descargas (se llama DENTRO del candado, tras una descarga, para espaciar globalmente)
  async function applyPacing() {
    if (stopRequested || PACE_SEC <= 0) return;
    await countdownWait(PACE_SEC, 'siguiente');
  }

  // Búsqueda en paralelo + descarga serializada bajo candado
  async function searchAndDownload(tabId, i, cufe) {
    // Enfriamiento global si hubo racha de fallos (deja que la DIAN/captcha se recupere).
    if (cooldownUntil > Date.now() && !stopRequested) {
      const s = Math.ceil((cooldownUntil - Date.now()) / 1000);
      setItemState(i, 'active', '⏸️', `Enfriando ${s}s…`);
      await countdownWait(s, 'enfriando');
    }
    // Refresco proactivo de la pestaña cada N descargas (evita que el botón "se muera").
    if ((tabDownloadCount.get(tabId) || 0) >= RELOAD_EVERY && !stopRequested) {
      setItemState(i, 'active', '🔄', 'Refrescando pestaña…');
      await reloadAndWait(tabId);
      tabDownloadCount.set(tabId, 0);
    }
    setItemState(i, 'active', '⏳', 'Buscando…');
    const r1 = await exec(tabId, pageStep1_FillAndSearch, [cufe]);
    if (!r1?.[0]?.result?.ok) { await logAlert(tabId, i); return { ok: false, error: r1?.[0]?.result?.error || 'Error en Buscar' }; }

    // Espera adaptativa: en cuanto aparece el botón de descarga, seguimos (en paralelo)
    setItemState(i, 'active', '⏳', 'Esperando resultado…');
    const rw = await exec(tabId, pageWaitForDownloadButton, []);
    if (!rw?.[0]?.result?.ready) { await logAlert(tabId, i); return { ok: false, error: 'No apareció el botón de descarga (sin resultados o verificación pendiente)' }; }

    // Descarga: SOLO una a la vez (candado) → detección fiable + ritmo de descarga sin duplicar
    const res = await withDownloadLock(async () => {
      currentDownloadLabel = cufe;
      let started = false;
      let captured = null; // Uint8Array con los bytes del ZIP (Exportador)
      // El reCAPTCHA tarda 1-3s en quedar listo: reintentamos el clic aquí mismo, sin recargar
      for (let click = 0; click < 3 && !started && !stopRequested; click++) {
        if (click > 0) { setItemState(i, 'active', '⏳', `Verificando captcha — reintento ${click + 1}/3…`); await sleep(2500); }
        const before = dlCount;
        const cap = (EXPORT_MODE || mergePdf) ? armCapture(tabId) : null;
        const r2 = await exec(tabId, pageStep2_ClickDownload, []);
        if (!r2?.[0]?.result?.ok) { if (cap) cap.cancel(); continue; } // botón aún no listo; reintenta
        setItemState(i, 'active', '⏳', EXPORT_MODE ? 'Capturando…' : 'Descargando…');
        if (EXPORT_MODE) {
          const bytes = await cap.promise;       // bytes vía CDP (o null si no llegó)
          // Solo es válido si es un ZIP real (magic "PK"). Si llegó la página de
          // "Captcha inválido" (HTML), se descarta y el ciclo reintenta el clic.
          if (bytes && bytes.length > 4 && bytes[0] === 0x50 && bytes[1] === 0x4b) {
            captured = bytes; started = true;
          } else {
            captured = null;
            if (bytes) { setItemState(i, 'active', '⏳', 'Captcha no listo — reintentando…'); await sleep(2500); }
          }
        } else {
          for (let t = 0; t < 6000; t += 300) { await sleep(300); if (dlCount > before) { started = true; break; } }
          // Masiva con "unir PDF": tomar los bytes capturados de esta descarga.
          if (mergePdf && cap) {
            if (started) { const b = await cap.promise; if (b && b.length > 4 && b[0] === 0x50 && b[1] === 0x4b) captured = b; }
            else cap.cancel();
          }
        }
        await readLastAlert(tabId); // limpiar cualquier alerta de "verificación no terminada"
      }
      if (!started) return { ok: false, error: EXPORT_MODE ? 'No se capturó el ZIP (captcha aún inválido)' : 'No inició la descarga (captcha aún inválido)' };
      // Captura exitosa → cuenta para la salud de la pestaña y corta la racha de fallos.
      tabDownloadCount.set(tabId, (tabDownloadCount.get(tabId) || 0) + 1);
      consecutiveFails = 0;

      // ── Exportador: subir los bytes al backend (Drive + Excel) ──
      if (EXPORT_MODE) {
        let up;
        try { up = await ContaGO.uploadZip(currentJob.jobId, cufe, captured, '', recordMap.get(cufe) || ''); }
        catch (e) { return { ok: false, error: 'No se pudo subir a ContaGO: ' + (e.message || e) }; }
        if (up.httpStatus === 403 || up.code === 'NIT_FORBIDDEN') {
          fatalReason = up.detalle || 'El NIT del listado no está autorizado en tu cuenta. Contacta al administrador.';
          stopRequested = true;
          setItemState(i, 'error', '🚫', 'NIT no autorizado');
          setLog('🚫 ' + fatalReason, 'err');
          return { ok: false, error: fatalReason };
        }
        if (up.httpStatus === 200) {
          okCount = (typeof up.ok === 'number') ? up.ok : okCount + 1;
          document.getElementById('statOk').textContent = okCount;
          setItemState(i, 'done', '✅', 'En ContaGO');
          setLog(`Factura ${okCount}/${cufes.length} procesada en ContaGO.`, 'ok');
        } else {
          // 422/500: el backend ya la contó como omitida; no reintentar (la subida ocurrió).
          errCount++;
          document.getElementById('statErr').textContent = errCount;
          setItemState(i, 'error', '❌', 'Sin XML / error');
          setLog(`[#${i + 1}] ${up.detalle || ('Backend status ' + up.httpStatus)}`, 'warn');
        }
        await applyPacing();
        return { ok: true }; // subida realizada → factura cerrada (sin reintento)
      }

      // ── Descarga Masiva: el ZIP quedó en disco ──
      if (mergePdf && captured) {
        const pdf = await extractPdfFromZipBytes(captured);
        if (pdf) pdfParts.push({ i, bytes: pdf });
      }
      okCount++;
      document.getElementById('statOk').textContent = okCount;
      setItemState(i, 'done', '✅', 'Descargada');
      setLog(`Factura ${okCount}/${cufes.length} descargada.`, 'ok');
      await applyPacing();
      return { ok: true };
    });
    await logAlert(tabId, i);
    return res;
  }

  // Procesa un CUFE completo. finalPass=false → si falla 2 veces va a la cola; true → fallo definitivo.
  async function processCufe(tabId, i, finalPass) {
    if (itemDone[i]) return;
    const cufe = cufes[i];
    scrollToItem(i);
    let attempt = 0;
    while (!stopRequested && !reauthRequested) {
      let res;
      try { res = await searchAndDownload(tabId, i, cufe); }
      catch (err) { res = { ok: false, error: 'Error de extensión: ' + err.message }; }

      if (res.ok) { itemDone[i] = true; persistRunNow(); return; }

      // ¿Token vencido? → disparar re-login y dejar esta factura pendiente
      if (!reauthRequested && await detectExpiry(tabId)) {
        reauthRequested = true;
        setItemState(i, 'paused', '🔑', 'Pausada (token vencido)');
        return;
      }

      attempt++;
      if (attempt <= MAX_AUTO_RETRIES && !stopRequested && !reauthRequested) {
        const cool = attempt === 1 ? 0 : 5; // 1er fallo recarga inmediata; 2º enfría 5s
        if (cool > 0) {
          setItemState(i, 'active', '🔄', `Reintento ${attempt}/${MAX_AUTO_RETRIES} — enfriando ${cool}s`);
          setLog(`[#${i + 1}] ${res.error} — esperando ${cool}s…`, 'warn');
          await countdownWait(cool, 'reintento');
          if (stopRequested || reauthRequested) return;
        } else {
          setLog(`[#${i + 1}] ${res.error} — recargando y reintentando…`, 'warn');
        }
        setItemState(i, 'active', '🔄', `Recargando y reintentando (${attempt}/${MAX_AUTO_RETRIES})…`);
        await reloadAndWait(tabId);
      } else if (!finalPass) {
        deferred.push(i); deferredSet.add(i); persistRunNow();
        setItemState(i, 'paused', '🕓', 'En cola (reintento al final)');
        setLog(`[#${i + 1}] ${res.error} — en cola para reintentar al final.`, 'warn');
        // Racha de fallos → programar un enfriamiento para que la DIAN se recupere.
        consecutiveFails++;
        if (consecutiveFails >= FAIL_COOLDOWN_AT && cooldownUntil < Date.now()) {
          consecutiveFails = 0;
          cooldownUntil = Date.now() + COOLDOWN_SEC * 1000;
          setLog(`⏸️ Muchos fallos seguidos — enfriando ${COOLDOWN_SEC}s para que la DIAN se recupere…`, 'warn');
        }
        return;
      } else {
        itemDone[i] = true;
        errCount++;
        setItemState(i, 'error', '❌', 'Falló');
        document.getElementById('statErr').textContent = errCount;
        setLog(`[#${i + 1}] Falló definitivamente: ${res.error}`, 'err');
        persistRunNow();
        return;
      }
    }
  }

  // Recorre una lista de índices con todos los workers (cola compartida)
  async function runQueue(indexList, finalPass) {
    let qi = 0;
    const worker = async (tabId) => {
      while (!stopRequested && !reauthRequested) {
        const k = qi;
        if (k >= indexList.length) break;
        qi++;
        await processCufe(tabId, indexList[k], finalPass);
        updateProgress(okCount + errCount);
      }
    };
    await Promise.all(tabs.map(t => worker(t.id)));
  }

  // Ejecuta una cola; si el token vence a mitad, re-autentica y continúa donde quedó
  async function runQueueResilient(indexList, finalPass) {
    let remaining = indexList.slice();
    while (remaining.length && !stopRequested) {
      reauthRequested = false;
      await runQueue(remaining, finalPass);
      if (stopRequested) break;
      if (reauthRequested) {
        const ok = await doReauth();
        if (!ok) break;
        remaining = remaining.filter(i => !itemDone[i] && (finalPass || !deferredSet.has(i)));
      } else break;
    }
  }

  // ── Preparar pestañas y arrancar ──
  if (!(await prepareTabs(tab))) {
    running = false; stopTimer();
    btn.disabled = false; btn.className = 'start'; btn.textContent = `Iniciar descarga (${cufes.length} facturas)`;
    return;
  }

  persistRunNow();  // snapshot inicial (por si se cierra el panel ya empezado)
  await runQueueResilient(cufes.map((_, idx) => idx), false); // 1ª vuelta
  if (deferred.length > 0 && !stopRequested) {                // 2ª vuelta: las que quedaron en cola
    setLog(`Reintentando ${deferred.length} factura(s) que quedaron en cola…`, 'warn');
    const pend = deferred.splice(0);
    await runQueueResilient(pend, true);
  }

  running = false;
  currentDownloadLabel = null;
  stopTimer();
  hidePause();
  if (reauthResolver) { document.getElementById('reauthBanner').style.display = 'none'; reauthResolver = null; }
  await detachDialogAutoAccept();
  for (const id of createdTabs) { try { await chrome.tabs.remove(id); } catch (_) {} } // cerrar las pestañas extra
  await setDownloadUi(true);
  document.getElementById('etaLabel').textContent = '';

  // ── Exportador: finalizar el job y descargar el Excel consolidado ──
  if (fatalReason) {
    // Corte por una causa de fondo (p. ej. NIT no autorizado): mensaje claro y
    // persistente, no se pisa con logs de captura de otras pestañas.
    setLog('🚫 Proceso detenido: ' + fatalReason, 'err');
  } else if (EXPORT_MODE && currentJob && okCount > 0) {
    try {
      setLog('Generando el Excel consolidado en ContaGO…', 'ok');
      await ContaGO.finalizeJob(currentJob.jobId);
      const { url, filename } = await ContaGO.fetchResultExcel(currentJob.jobId);
      pendingExcelName = filename;            // lo fija onDeterminingFilename
      await chrome.downloads.download({ url, filename, saveAs: false });
      setTimeout(() => { try { URL.revokeObjectURL(url); } catch (_) {} }, 60000);
      const driveTxt = currentJob.driveFolderUrl ? ' · facturas subidas a Google Drive' : '';
      setLog(`✅ Listo: ${okCount} facturas en "${filename}"${driveTxt}${errCount ? ` · ${errCount} omitidas` : ''}.`, errCount ? 'warn' : 'ok');
    } catch (e) {
      setLog('Las facturas se procesaron, pero falló la generación/descarga del Excel: ' + (e.message || e), 'err');
    }
  } else if (EXPORT_MODE) {
    if (!stopRequested) setLog(`Terminó sin facturas procesadas (${errCount} omitidas).`, 'err');
  } else if (okCount > 0) {
    setLog(`✅ Listo: ${okCount} facturas en Descargas/${downloadFolder || 'FacturasDIAN'}${errCount ? ` · ${errCount} fallaron tras la cola` : ''}.`, errCount ? 'warn' : 'ok');
  } else if (!stopRequested) {
    setLog(`Terminó sin descargas (${errCount} fallidas).`, 'err');
  }

  // ── Masiva: unir todos los PDF capturados en uno y descargarlo ──
  if (mergePdf && pdfParts.length) {
    try { await buildAndDownloadMergedPdf(); }
    catch (e) { setLog('No se pudo generar el PDF unificado: ' + (e.message || e), 'err'); }
  }

  // Fin "gracioso" (completó / detuvo / finalizó): ya no hay nada que reanudar.
  // (Si el panel se cerró de golpe, este bloque NO se ejecuta y el snapshot queda
  // guardado → al reabrir se ofrece Reanudar.)
  isResuming = false;
  clearRun();

  btn.disabled = false;
  btn.className = 'done';
  btn.textContent = 'Completado — reiniciar';
  btn.addEventListener('click', () => location.reload(), { once: true });
});

// Espera a que una pestaña termine de cargar y esté ya en el dominio de la DIAN
async function waitTabLoaded(tabId, timeoutMs = 30000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (stopRequested) return false;
    try {
      const t = await chrome.tabs.get(tabId);
      if (t.status === 'complete' && /catalogo-vpfe\.dian\.gov\.co/i.test(t.url || '')) return true;
    } catch (_) {}
    await sleep(400);
  }
  return false;
}

// Abre/renavega al enlace de acceso. El primer acceso a veces rebota a /User/Login,
// pero al volver a abrirlo entra normal → reintentamos antes de darlo por inválido.
async function accessWithLink(link, maxAttempts = 4) {
  let tabId = null;
  for (let attempt = 1; attempt <= maxAttempts && !stopRequested; attempt++) {
    try {
      if (tabId == null) { const c = await chrome.tabs.create({ url: link, active: true }); tabId = c.id; }
      else { await chrome.tabs.update(tabId, { url: link }); }
    } catch (_) {}
    await waitTabLoaded(tabId, 45000);
    await waitNotChallenge(tabId, 60000);
    let t = null; try { t = await chrome.tabs.get(tabId); } catch (_) {}
    const url = (t && t.url || '').toLowerCase();
    if (t && url && !/\/user\/login/i.test(url)) return { tab: t, stuckLogin: false }; // entró bien
    if (attempt < maxAttempts) { setLog(`El acceso rebotó al login (intento ${attempt}/${maxAttempts}); reintentando…`, 'warn'); await sleep(2000); }
  }
  let t = null; try { t = await chrome.tabs.get(tabId); } catch (_) {}
  return { tab: t, stuckLogin: true };
}

// Espera a que una pestaña esté lista para buscar (sin recargarla), aguardando el challenge de Azure
async function waitTabReady(tabId, timeoutMs = 45000) {
  const start = Date.now();
  let lastLog = 0;
  while (Date.now() - start < timeoutMs) {
    if (stopRequested) return false;
    let st = 'loading';
    try {
      const r = await chrome.scripting.executeScript({ target: { tabId }, func: pageStatus });
      st = r?.[0]?.result || 'loading';
    } catch (_) {}
    if (st === 'ready') return true;
    if (st === 'challenge' && Date.now() - lastLog > 2500) { setLog('⏳ Esperando la verificación de Azure…', 'warn'); lastLog = Date.now(); }
    await sleep(400);
  }
  return false;
}

// Espera a que la pestaña deje de estar en la verificación de Azure (para no navegar en medio del challenge)
async function waitNotChallenge(tabId, timeoutMs = 45000) {
  const start = Date.now();
  let lastLog = 0;
  while (Date.now() - start < timeoutMs) {
    if (stopRequested) return false;
    let st = 'loading';
    try {
      const r = await chrome.scripting.executeScript({ target: { tabId }, func: pageStatus });
      st = r?.[0]?.result || 'loading';
    } catch (_) {}
    if (st !== 'challenge') return true;
    if (Date.now() - lastLog > 2500) { setLog('⏳ Esperando la verificación de Azure…', 'warn'); lastLog = Date.now(); }
    await sleep(400);
  }
  return false;
}

// Mostrar/ocultar la barra/burbuja de descargas del navegador
async function setDownloadUi(enabled) {
  try { await chrome.downloads.setUiOptions({ enabled }); return; } catch (_) {}
  try { await chrome.downloads.setShelfEnabled(enabled); } catch (_) {}
}

// ── Página: Paso 1 — llenar y buscar (espera a que la página esté lista) ───────
async function pageStep1_FillAndSearch(cufe) {
  const wait = (ms) => new Promise(r => setTimeout(r, ms));

  // Busca el campo "Código único" de forma amplia
  const findInput = () =>
    [...document.querySelectorAll('input')].find(i => {
      const ph = (i.placeholder || i.getAttribute('aria-label') || i.name || i.id || '').toLowerCase();
      return ph.includes('digo') || ph.includes('nico') || ph.includes('cufe') || ph.includes('cude') || ph.includes('unico');
    }) || document.querySelector('input[type="text"]:not([type="hidden"])') || document.querySelector('input:not([type="hidden"])');

  // Busca el botón "Buscar" de forma amplia: texto, value, clases e ícono de lupa
  const findBuscar = () => {
    const cands = [...document.querySelectorAll('button, input[type="submit"], input[type="button"], a, [role="button"]')];
    const visible = (el) => el && (el.offsetParent !== null || el.getClientRects().length > 0);
    const byText = cands.find(el => {
      const t = (el.textContent || el.value || '').replace(/\s+/g, ' ').trim().toLowerCase();
      return visible(el) && (t === 'buscar' || t.includes('buscar') || t.includes('consultar'));
    });
    return byText
      || document.querySelector('button.btn-radian-success, .btn-radian-success')
      || document.querySelector('button.btn-success:not(.applyBtn)')
      || cands.find(el => visible(el) && el.querySelector && el.querySelector('i.fa-search, .fa-search'));
  };

  // Espera hasta ~10 s a que la página (React) termine de pintar campo + botón
  let inp = null, buscar = null;
  for (let t = 0; t < 10000; t += 250) {
    inp = findInput();
    buscar = findBuscar();
    if (inp && buscar) break;
    await wait(250);
  }

  if (!inp) return { ok: false, error: 'Campo "Código único" no encontrado tras esperar — ¿estás en la página correcta (Document/Received)?' };
  if (!buscar) return { ok: false, error: 'Botón "Buscar" no apareció tras esperar 10s — recargando…' };

  const setVal = (el, v) => {
    try {
      const s = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
      s.call(el, v);
    } catch (_) { el.value = v; }
    el.dispatchEvent(new Event('input',  { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  };

  inp.focus();
  setVal(inp, '');
  setVal(inp, cufe);

  await wait(150); // dar un instante a React para registrar el valor antes de buscar
  buscar.click();
  return { ok: true };
}

// ── Página: esperar (adaptativo) a que aparezca el botón de descarga ───────────
async function pageWaitForDownloadButton() {
  const wait = (ms) => new Promise(r => setTimeout(r, ms));
  for (let t = 0; t < 9000; t += 250) {
    if (document.querySelector('button.download-document')) return { ready: true };
    await wait(250);
  }
  return { ready: false };
}

// ── Página: Paso 2 — clic en el botón de descarga (síncrono) ──────────────────
function pageStep2_ClickDownload() {
  const btn = document.querySelector('button.download-document');
  if (!btn) return { ok: false, error: 'Botón de descarga no encontrado — el resultado no cargó o el CUFE no existe' };
  btn.click();
  return { ok: true };
}

// ── Recargar la página DIAN y esperar a que esté lista para buscar ────────────
async function reloadAndWait(tabId, timeoutMs = 30000) {
  try { await chrome.tabs.reload(tabId); } catch (_) {}
  const start = Date.now();
  await sleep(500); // margen mínimo para que arranque la recarga
  let lastLog = 0;
  while (Date.now() - start < timeoutMs) {
    if (stopRequested) return false;
    let st = 'loading';
    try {
      const r = await chrome.scripting.executeScript({ target: { tabId }, func: pageStatus });
      st = r?.[0]?.result || 'loading';
    } catch (_) { /* la pestaña puede estar navegando aún */ }
    if (st === 'ready') {
      await installAlertAutoAccept(tabId);  // reinstalar override de alertas
      await enableFetchCapture(tabId);       // CLAVE: re-habilitar captura CDP tras la recarga
      return true;
    }
    if (st === 'challenge' && Date.now() - lastLog > 2500) { setLog('⏳ Esperando la verificación de Azure…', 'warn'); lastLog = Date.now(); }
    await sleep(250); // sondeo frecuente: seguir apenas la página esté lista
  }
  return false;
}

// ── Auto-aceptar diálogos nativos ya abiertos vía chrome.debugger (CDP) ───────
// Es la única forma de cerrar un alert/confirm que YA apareció (la página queda
// congelada y el override de window.alert no alcanza a ejecutarse).
const debuggerTabs = new Set();

// Si el usuario cierra el aviso "está depurando este navegador" (o se cae la
// conexión del debugger), la captura deja de funcionar y todo falla con "captcha
// inválido". Mientras hay una corrida activa, reconectamos automáticamente.
chrome.debugger.onDetach.addListener(async (source, reason) => {
  const tabId = source.tabId;
  if (!debuggerTabs.has(tabId)) return;
  debuggerTabs.delete(tabId);
  if (!running || stopRequested || reason === 'target_closed') return;
  setLog('⚠️ Se cerró el aviso de depuración (la captura lo necesita). Reconectando…', 'warn');
  await sleep(400);
  if (!running || stopRequested) return;
  try { await attachDialogAutoAccept(tabId); } catch (_) {}
});

function onDebuggerEvent(source, method, params) {
  const tabId = source.tabId;
  if (!debuggerTabs.has(tabId)) return;

  if (method === 'Page.javascriptDialogOpening') {
    const msg = (params && params.message) || '';
    // Aceptar el diálogo automáticamente
    chrome.debugger.sendCommand({ tabId }, 'Page.handleJavaScriptDialog', { accept: true }).catch(() => {});
    setLog(`Alerta del navegador aceptada automáticamente: "${String(msg).slice(0, 80)}"`, 'warn');
    return;
  }

  // Exportador: capturar los bytes del ZIP en stage Response (método verificado
  // por la sonda: Fetch.getResponseBody) y abortar la bajada a disco.
  if (method === 'Fetch.requestPaused') {
    const reqId = params.requestId;
    const url = (params.request && params.request.url) || '';
    if (/DownloadZipFiles/i.test(url)) {
      // La petición llegó: ampliar el margen para leer el cuerpo (conexiones lentas).
      pendingCaptures.get(tabId)?.markStarted?.();
      (async () => {
        let bytes = null;
        try {
          const body = await chrome.debugger.sendCommand({ tabId }, 'Fetch.getResponseBody', { requestId: reqId });
          if (body && typeof body.body === 'string') {
            const bin = body.base64Encoded ? atob(body.body) : body.body;
            const arr = new Uint8Array(bin.length);
            for (let k = 0; k < bin.length; k++) arr[k] = bin.charCodeAt(k);
            bytes = arr;
          }
        } catch (_) {}
        // Exportador: ABORTAR (no escribir a disco ni diálogo "Guardar como").
        // Masiva con "unir PDF": CONTINUAR (el ZIP debe seguir bajando a disco).
        if (EXPORT_MODE) {
          try { await chrome.debugger.sendCommand({ tabId }, 'Fetch.failRequest', { requestId: reqId, errorReason: 'Aborted' }); }
          catch (_) { try { await chrome.debugger.sendCommand({ tabId }, 'Fetch.continueRequest', { requestId: reqId }); } catch (_) {} }
        } else {
          try { await chrome.debugger.sendCommand({ tabId }, 'Fetch.continueRequest', { requestId: reqId }); } catch (_) {}
        }
        const cap = pendingCaptures.get(tabId);
        if (cap) cap.resolve(bytes);
      })();
    } else {
      chrome.debugger.sendCommand({ tabId }, 'Fetch.continueRequest', { requestId: reqId }).catch(() => {});
    }
  }
}

// (Re)habilita la captura CDP de DownloadZipFiles en una pestaña. Debe llamarse
// al adjuntar y DESPUÉS DE CADA RECARGA: si no, tras recargar el dominio Fetch
// puede dejar de interceptar y todas las descargas de esa pestaña agotan timeout.
async function enableFetchCapture(tabId) {
  if (!(EXPORT_MODE || mergePdf)) return;
  try {
    await chrome.debugger.sendCommand({ tabId }, 'Fetch.enable', {
      patterns: [{ urlPattern: '*DownloadZipFiles*', requestStage: 'Response' }],
    });
  } catch (_) {}
}

// Arma una captura para la próxima descarga de esa pestaña (Exportador).
// Dos fases: si en `firstByteMs` no llega ninguna petición DownloadZipFiles, falla
// rápido (no se disparó la descarga). Pero en cuanto la petición SÍ llega
// (markStarted), se da un margen largo `bodyMs` para leer el cuerpo completo del
// ZIP — clave para conexiones lentas / ZIP grandes (antes 6s fijos se quedaban
// cortos y daban "captcha aún inválido" en falso).
function armCapture(tabId, firstByteMs = 8000, bodyMs = 45000) {
  const prev = pendingCaptures.get(tabId);
  if (prev) prev.resolve(null); // descarta una captura anterior sin resolver
  let resolveFn, timer;
  const promise = new Promise((res) => { resolveFn = res; });
  const settle = (bytes) => { clearTimeout(timer); pendingCaptures.delete(tabId); resolveFn(bytes); };
  timer = setTimeout(() => settle(null), firstByteMs);
  const markStarted = () => { clearTimeout(timer); timer = setTimeout(() => settle(null), bodyMs); };
  pendingCaptures.set(tabId, { resolve: settle, markStarted });
  return { promise, cancel: () => settle(null) };
}

async function attachDialogAutoAccept(tabId) {
  try {
    await chrome.debugger.attach({ tabId }, '1.3');
  } catch (e) {
    // Quizá quedó adjunto de una corrida anterior: soltar y reintentar una vez
    try { await chrome.debugger.detach({ tabId }); await chrome.debugger.attach({ tabId }, '1.3'); }
    catch (e2) {
      setLog('No se pudo activar el auto-aceptar de alertas a nivel navegador (¿DevTools abierto?). Se usa el respaldo.', 'warn');
      return false;
    }
  }
  try {
    await chrome.debugger.sendCommand({ tabId }, 'Page.enable');
    debuggerTabs.add(tabId);
    if (!chrome.debugger.onEvent.hasListener(onDebuggerEvent)) chrome.debugger.onEvent.addListener(onDebuggerEvent);
    // Interceptar la respuesta de DownloadZipFiles para leer los bytes:
    // Exportador (subir al backend) o Masiva con "unir PDF".
    await enableFetchCapture(tabId);
    return true;
  } catch (_) { return false; }
}

async function detachDialogAutoAccept() {
  for (const id of [...debuggerTabs]) {
    debuggerTabs.delete(id);
    try { await chrome.debugger.detach({ tabId: id }); } catch (_) {}
  }
}

// Si el panel/pestaña se cierra a media corrida, soltar el debugger para no dejar el aviso pegado
window.addEventListener('beforeunload', () => {
  for (const id of debuggerTabs) { try { chrome.debugger.detach({ tabId: id }); } catch (_) {} }
});

// ── Aceptar automáticamente alert/confirm/prompt de la página (respaldo JS) ────
// Se inyecta en el "mundo real" (MAIN) de la página, porque los alert nativos
// solo se pueden sustituir desde ahí, no desde el mundo aislado de la extensión.
async function installAlertAutoAccept(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: pageInstallAlertAutoAccept });
  } catch (_) {}
}
function pageInstallAlertAutoAccept() {
  if (window.__alertAutoAccept) return;
  window.__alertAutoAccept = true;
  window.alert = function (m) { try { localStorage.setItem('__lastAlert', String(m == null ? '' : m)); } catch (_) {} };
  window.confirm = function (m) { try { localStorage.setItem('__lastAlert', String(m == null ? '' : m)); } catch (_) {} return true; };
  window.prompt = function (m, d) { return d == null ? '' : d; };
}

// Lee y limpia el último alert que la página intentó mostrar (mundo aislado, mismo localStorage)
async function readLastAlert(tabId) {
  try {
    const r = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => { const m = localStorage.getItem('__lastAlert'); localStorage.removeItem('__lastAlert'); return m; }
    });
    return r?.[0]?.result || '';
  } catch (_) { return ''; }
}

// Se ejecuta en la página: ¿ya cargó el campo de búsqueda y el botón Buscar?
function pageIsReadyToSearch() {
  if (document.readyState !== 'complete') return false;
  const hasInput = [...document.querySelectorAll('input')].some(i => {
    const ph = (i.placeholder || i.getAttribute('aria-label') || i.name || i.id || '').toLowerCase();
    return ph.includes('digo') || ph.includes('nico') || ph.includes('cufe') || ph.includes('cude') || ph.includes('unico');
  });
  const hasBtn =
    [...document.querySelectorAll('button, input[type="submit"], input[type="button"], a, [role="button"]')].some(el => {
      const t = (el.textContent || el.value || '').replace(/\s+/g, ' ').trim().toLowerCase();
      return t === 'buscar' || t.includes('buscar') || t.includes('consultar');
    }) ||
    !!document.querySelector('button.btn-radian-success, .btn-radian-success');
  return hasInput && hasBtn;
}

// Estado de la página: 'ready' (formulario listo) | 'challenge' (verificación Azure/WAF) | 'loading'
function pageStatus() {
  const title = (document.title || '').toLowerCase();
  const body = (document.body ? document.body.innerText || '' : '').slice(0, 2500).toLowerCase();
  const txt = title + ' ' + body;
  const looksChallenge =
    /verif|verify|checking your browser|just a moment|un momento|comprobando|validando|are human|human verification|web application firewall|firewall|ddos|cargando la verificaci/i.test(txt);
  // Las pantallas de verificación no tienen el formulario de la app
  const hasAppInput = [...document.querySelectorAll('input')].some(i => {
    const ph = (i.placeholder || i.getAttribute('aria-label') || i.name || i.id || '').toLowerCase();
    return ph.includes('digo') || ph.includes('nico') || ph.includes('cufe') || ph.includes('cude') || ph.includes('unico');
  });
  if (looksChallenge && !hasAppInput) return 'challenge';

  const hasBtn =
    [...document.querySelectorAll('button, input[type="submit"], input[type="button"], a, [role="button"]')].some(el => {
      const t = (el.textContent || el.value || '').replace(/\s+/g, ' ').trim().toLowerCase();
      return t === 'buscar' || t.includes('buscar') || t.includes('consultar');
    }) ||
    !!document.querySelector('button.btn-radian-success, .btn-radian-success');
  if (hasAppInput && hasBtn && document.readyState === 'complete') return 'ready';

  // Login / sesión vencida (token expirado): texto típico o URL de autenticación, sin el formulario de la app
  const url = (location.href || '').toLowerCase();
  const looksLogin =
    /\/user\/login|\/account\/login|\/login|\/auth|signin|sign-in/.test(url) ||
    /sesi[oó]n (ha )?(expir|vencid|caduc)|token (expir|vencid|inv[aá]lid|caduc)|vuelva? a iniciar sesi|inicie? sesi[oó]n|iniciar sesi[oó]n|acceso denegado|no autorizado|unauthorized|debe autenticar/i.test(txt);
  if (looksLogin && !hasAppInput) return 'login';

  if (document.readyState !== 'complete') return 'loading';
  return 'loading';
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function setItemState(index, stateClass, icon, statusText) {
  const item = document.getElementById(`item-${index}`);
  if (!item) return;
  item.className = `list-item s-${stateClass}`;
  document.getElementById(`icon-${index}`).textContent = icon;
  document.getElementById(`istatus-${index}`).textContent = statusText;
}
function scrollToItem(index) {
  document.getElementById(`item-${index}`)?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}
function updateProgress(done) {
  document.getElementById('progressFill').style.width = `${(done / cufes.length) * 100}%`;
}
function setLog(msg, type) {
  const el = document.getElementById('logMsg');
  el.textContent = msg;
  el.className = 'log' + (type ? ' ' + type : '');
}
function resetProgress() {
  okCount = 0; errCount = 0;
  stopTimer(); startTime = 0;
  document.getElementById('statOk').textContent = '0';
  document.getElementById('statErr').textContent = '0';
  document.getElementById('progressFill').style.width = '0%';
  document.getElementById('elapsedLabel').textContent = '00:00';
  document.getElementById('rateLabel').textContent = '0.0';
}
function updateETA() {
  // ~6.5 s por factura (5 s de carga de resultados + margen de descarga)
  const mins = Math.max(1, Math.round((cufes.length * 6.5) / 60));
  document.getElementById('etaLabel').textContent = `~${mins} min estimados`;
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── Cronómetro y velocidad (facturas/min) ─────────────────────────────────────
function startTimer() {
  startTime = Date.now();
  clearInterval(timerInterval);
  timerInterval = setInterval(updateTimer, 1000);
  updateTimer();
}
function stopTimer() {
  clearInterval(timerInterval);
  timerInterval = null;
  updateTimer(); // congela el valor final
}
function updateTimer() {
  if (!startTime) return;
  const ms = Date.now() - startTime;
  const totalSec = Math.floor(ms / 1000);
  const mm = String(Math.floor(totalSec / 60)).padStart(2, '0');
  const ss = String(totalSec % 60).padStart(2, '0');
  document.getElementById('elapsedLabel').textContent = `${mm}:${ss}`;
  const mins = ms / 60000;
  const rate = mins > 0 ? okCount / mins : 0;
  document.getElementById('rateLabel').textContent = rate.toFixed(1);
}

// Espera con cuenta regresiva visible; se corta si el usuario pulsa Detener
async function countdownWait(seconds, label) {
  for (let s = seconds; s > 0; s--) {
    if (stopRequested) break;
    document.getElementById('etaLabel').textContent = `${label} en ${s}s`;
    await sleep(1000);
  }
  document.getElementById('etaLabel').textContent = '';
}

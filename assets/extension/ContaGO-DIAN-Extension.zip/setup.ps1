# setup.ps1 - Descarga las librerias necesarias para la extension
# Ejecutar una sola vez antes de instalar la extension en Edge

$ErrorActionPreference = 'Stop'

$libsDir = Join-Path $PSScriptRoot 'libs'
if (-not (Test-Path $libsDir)) {
    New-Item -ItemType Directory -Path $libsDir | Out-Null
}

Write-Host ''
Write-Host '======================================' -ForegroundColor Cyan
Write-Host '  Instalador - Descargador de Facturas' -ForegroundColor Cyan
Write-Host '======================================' -ForegroundColor Cyan
Write-Host ''

# JSZip
Write-Host 'Descargando JSZip (lector de ZIP)...' -NoNewline
try {
    $dest1 = Join-Path $libsDir 'jszip.min.js'
    Invoke-WebRequest -Uri 'https://cdnjs.cloudflare.com/ajax/libs/jszip/3.10.1/jszip.min.js' -OutFile $dest1 -UseBasicParsing
    $kb1 = [math]::Round((Get-Item $dest1).Length / 1024)
    Write-Host (' OK - ' + $kb1 + ' KB') -ForegroundColor Green
} catch {
    Write-Host ' ERROR' -ForegroundColor Red
    Write-Host ('  -> ' + $_) -ForegroundColor Red
    Write-Host 'Verifica tu conexion a internet e intenta de nuevo.' -ForegroundColor Yellow
    exit 1
}

# SheetJS
Write-Host 'Descargando SheetJS (lector de Excel)...' -NoNewline
try {
    $dest2 = Join-Path $libsDir 'xlsx.full.min.js'
    Invoke-WebRequest -Uri 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js' -OutFile $dest2 -UseBasicParsing
    $kb2 = [math]::Round((Get-Item $dest2).Length / 1024)
    Write-Host (' OK - ' + $kb2 + ' KB') -ForegroundColor Green
} catch {
    Write-Host ' ERROR' -ForegroundColor Red
    Write-Host ('  -> ' + $_) -ForegroundColor Red
    Write-Host 'Verifica tu conexion a internet e intenta de nuevo.' -ForegroundColor Yellow
    exit 1
}

Write-Host ''
Write-Host 'Librerias descargadas correctamente.' -ForegroundColor Green
Write-Host ''
Write-Host 'PROXIMOS PASOS:' -ForegroundColor Yellow
Write-Host ''
Write-Host '  1. Abre Edge y ve a:  edge://extensions/'
Write-Host '  2. Activa el modo de desarrollador (interruptor arriba a la derecha)'
Write-Host '  3. Haz clic en Cargar sin empaquetar'
Write-Host '  4. Selecciona esta carpeta:'
Write-Host ('     ' + $PSScriptRoot) -ForegroundColor Cyan
Write-Host ''
Write-Host '  Listo! El icono de la extension aparecera en la barra de Edge.'
Write-Host ''

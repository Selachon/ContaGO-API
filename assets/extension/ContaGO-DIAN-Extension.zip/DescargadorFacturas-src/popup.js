// ── Modo: popup (toolbar) vs persistente (pestaña o panel lateral) ─────────────
const MODE = new URLSearchParams(window.location.search).get('mode'); // 'tab' | 'panel' | null
const PERSISTENT = MODE === 'tab' || MODE === 'panel';

// Prefetch del id de la ventana actual (para abrir el panel sin perder el gesto del usuario)
let currentWinId = null;
chrome.windows.getCurrent().then(w => { currentWinId = w.id; }).catch(() => {});

if (!PERSISTENT) {
  // En popup guardamos el tab activo (la página de facturas)
  chrome.tabs.query({ active: true, currentWindow: true }).then(([tab]) => {
    if (tab) localStorage.setItem('invoiceTabId', String(tab.id));
  });
} else {
  // Ya somos panel/pestaña: el botón de abrir no aplica
  document.getElementById('openTabBtn').style.display = 'none';
}

document.getElementById('openTabBtn').addEventListener('click', () => {
  // Abrir como panel lateral (sidebar) pegado a la página, sin cerrarse al hacer clic
  try {
    chrome.sidePanel.setOptions({ path: 'popup.html?mode=panel', enabled: true });
    chrome.sidePanel.open({ windowId: currentWinId });
    window.close();
  } catch (_) {
    // Respaldo: abrir en pestaña si el panel lateral no está disponible
    chrome.tabs.create({ url: chrome.runtime.getURL('popup.html') + '?mode=tab' });
    window.close();
  }
});

// ── Encontrar la pestaña de facturas ──────────────────────────────────────────
async function findInvoiceTab() {
  // 1. Buscar por URL (más confiable cuando estamos en modo pestaña)
  try {
    const byUrl = await chrome.tabs.query({ url: '*://catalogo-vpfe.dian.gov.co/*' });
    if (byUrl.length > 0) return byUrl[0];
  } catch (_) {}

  // 2. Usar el tab guardado cuando se abrió el popup
  const savedId = parseInt(localStorage.getItem('invoiceTabId') || '0');
  if (savedId) {
    try { return await chrome.tabs.get(savedId); } catch (_) {}
  }

  // 3. Tab activo como último recurso
  const [active] = await chrome.tabs.query({ active: true, currentWindow: true });
  return active;
}

// ── State ──────────────────────────────────────────────────────────────────────
let cufes = [];
let running = false;
let stopRequested = false;
let fatalReason = '';   // motivo de corte del proceso (p. ej. NIT no autorizado)
let okCount = 0;
let errCount = 0;
let pauseResolver = null; // resuelve la promesa de pausa
let reauthResolver = null; // resuelve la promesa de re-login (token nuevo)
let reauthRequested = false; // alguien (token vencido o el usuario) pidió re-autenticar
let manualPause = false;     // la re-autenticación la pidió el usuario (no fue token vencido)
let currentDownloadLabel = null; // CUFE en curso, para nombrar el archivo descargado
let dlCount = 0;                 // descargas de factura iniciadas (para detectar éxito)
let startTime = 0;               // inicio del segmento actual (para cronómetro y velocidad)
let accumulatedMs = 0;           // tiempo de segmentos previos (sobrevive a reanudación)
let timerInterval = null;        // intervalo del cronómetro
function elapsedTotalMs() { return accumulatedMs + (startTime ? Date.now() - startTime : 0); }

let listingTipo = null;   // 'recibido' | 'emitido'
let downloadFolder = '';  // nombre de la carpeta destino calculado del listado

// Construye el nombre de carpeta: "<NIT> - <Nombre> - Facturas <Recibidas/Emitidas> DIAN <AAAA-MM-DD>"
function buildFolderName(tipo, nit, nombre) {
  const fecha = new Date().toISOString().slice(0, 10);
  const tipoTxt = tipo === 'emitido' ? 'Emitidas' : 'Recibidas';
  const clean = (s) => String(s || '').replace(/[\\/:*?"<>|]/g, ' ').replace(/\s+/g, ' ').trim();
  const nitTxt = clean(nit) || 'SIN-NIT';
  const nomTxt = clean(nombre) || 'Empresa';
  return `${nitTxt} - ${nomTxt} - Facturas ${tipoTxt} DIAN ${fecha}`;
}

// Enruta las descargas de facturas. En Descarga Masiva quedan en la carpeta con
// nombre = CUFE. En Exportador, los bytes ya se capturan por CDP; el archivo va a
// una carpeta temporal y se borra al completarse (modo "sin disco").
let pendingExcelName = null;   // nombre a forzar para la descarga del Excel (blob)
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  // Excel consolidado: el blob no lleva nombre, así que lo fijamos explícitamente.
  if (pendingExcelName && item.url && item.url.startsWith('blob:')) {
    const n = pendingExcelName; pendingExcelName = null;
    suggest({ filename: n, conflictAction: 'uniquify' });
    return;
  }
  // Modo PDF: dequeue la próxima descarga pendiente y renombrar CUFE.pdf.
  if (PDF_MODE && item.url && item.url.includes('/Document/DownloadPDF')) {
    const pending = pdfDownloadQueue.shift();
    if (pending) {
      dlCount++;
      suggest({ filename: `${downloadFolder || 'FacturasDIAN-PDF'}/${pending.label}.pdf`, conflictAction: 'uniquify' });
      pending.resolve();
    } else { suggest(); }
    return;
  }
  // Descarga Masiva: el ZIP cae a la carpeta con nombre = CUFE. (En Exportador no
  // hay descarga a disco: los bytes se capturan por CDP y la petición se aborta.)
  if (!EXPORT_MODE && currentDownloadLabel && item.url && item.url.includes('DownloadZipFiles')) {
    dlCount++;
    const folder = downloadFolder || 'FacturasDIAN';
    suggest({ filename: `${folder}/${currentDownloadLabel}.zip`, conflictAction: 'uniquify' });
    return;
  }
  suggest();
});

// ── Integración ContaGO: activación + modo + captura por CDP ───────────────────
let EXPORT_MODE = false;            // false = Descarga Masiva (local); true = backend (Exportador o Terceros)
let PDF_MODE = false;               // true = Descargar PDF por CUFE desde catálogo-vpfe.dian.gov.co
const pdfDownloadQueue = [];        // cola FIFO: [{label, resolve}] para workers paralelos
let jobKind = 'invoices';           // 'invoices' (Exportador) | 'terceros'
let uploadedFile = null;           // File del listado (para crear el job del Exportador)
let currentJob = null;             // { jobId, direction, records, driveFolderUrl }
const recordMap = new Map();       // cufe -> docnum (de los records del backend)
let queryRange = { from: '', to: '' };  // rango de fechas (YYYY-MM-DD) a fijar en el filtro DIAN
const dateRangeReady = new Set();  // tabIds que ya tienen el rango aplicado en la carga actual
const dateRangeAttempts = new Map(); // tabId -> intentos de fijar el rango en la carga actual

// ── Profiler de fases (diagnóstico de rendimiento) ───────────────────────────
// Acumula tiempo total/cuenta/máximo por fase para ver dónde está el cuello de botella.
const PERF = new Map();             // fase -> { sum, count, max }
function perfAdd(name, ms) {
  const e = PERF.get(name) || { sum: 0, count: 0, max: 0 };
  e.sum += ms; e.count++; if (ms > e.max) e.max = ms;
  PERF.set(name, e);
}
// Mide una promesa y la atribuye a una fase. Devuelve el valor de la promesa.
async function perfTime(name, p) {
  const s = performance.now();
  try { return await p; } finally { perfAdd(name, performance.now() - s); }
}
// ── Diagnóstico de captura (Opción B): qué estado de verificación hay cuando un
// clic de descarga NO produce el ZIP. Identifica el mecanismo del captcha para
// implementar luego "esperar a que la verificación esté lista → 1 clic". Solo lectura.
const DIAG = { n: 0, agg: new Map(), samples: [] };
// Diagnóstico del rango de fechas: registra cada intento de fijarlo en la DIAN.
const rangeEvents = [];   // { tab, ok, method, reason, diag }
function rangeLog(tabId, out) {
  if (rangeEvents.length < 8) rangeEvents.push({
    tab: tabId, ok: !!out.ok, method: out.method || '', reason: out.reason || '', diag: (out.diag || '').slice(0, 140),
  });
}
function rangeReport() {
  let out = `\nRANGO DE FECHAS — queryRange = ${queryRange.from || '(vacío)'} → ${queryRange.to || '(vacío)'}\n`;
  if (!rangeEvents.length) { out += '  (sin intentos registrados — ¿queryRange vacío o nunca se llamó?)\n'; return out; }
  for (const e of rangeEvents) {
    out += e.ok ? `  ✓ aplicado (${e.method})\n` : `  ✗ falló: ${e.reason} · campos: ${e.diag}\n`;
  }
  return out;
}
function diagAdd(p, alertMsg) {
  DIAG.n++;
  const alert = alertMsg || p.lastAlert || '';
  const tokenState = p.tokenEl ? (p.tokenLen > 0 ? 'token-LISTO' : 'token-vacio') : 'sin-token-el';
  const k = `${tokenState} · grecaptcha=${p.hasGrecaptcha} · iframes=${p.captchaIframes} · dlBtn=${p.dlBtn}${p.dlDisabled ? '(disabled)' : ''} · alerta=${alert ? 'sí' : 'no'}`;
  DIAG.agg.set(k, (DIAG.agg.get(k) || 0) + 1);
  if (DIAG.samples.length < 10) DIAG.samples.push({ ...p, alert: alert.slice(0, 50) });
}
async function captchaDiag(tabId, alertMsg) {
  if (DIAG.n >= 40) return;           // cota para no añadir overhead indefinido
  try {
    const r = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: pageCaptchaProbe });
    const p = r?.[0]?.result; if (p) diagAdd(p, alertMsg);
  } catch (_) {}
}
// Inyectada en MAIN (para ver window.grecaptcha). Devuelve estado del captcha/verificación.
function pageCaptchaProbe() {
  const o = {};
  try {
    const ta = document.querySelector('#g-recaptcha-response, textarea[name="g-recaptcha-response"]');
    o.tokenEl = !!ta;
    o.tokenLen = ta ? (ta.value || '').length : -1;
    o.hasGrecaptcha = (typeof window.grecaptcha !== 'undefined');
    o.captchaIframes = document.querySelectorAll('iframe[src*="recaptcha"], iframe[title*="recaptcha" i]').length;
    o.grecaptchaDivs = document.querySelectorAll('.g-recaptcha, [data-sitekey]').length;
    const dl = document.querySelector('button.download-document');
    o.dlBtn = !!dl;
    o.dlDisabled = dl ? !!dl.disabled : null;
    try { o.lastAlert = (localStorage.getItem('__lastAlert') || '').slice(0, 60); } catch (_) { o.lastAlert = ''; }
  } catch (e) { o.err = String((e && e.message) || e); }
  return o;
}
function diagReport() {
  if (!DIAG.n) return '\n(Sin clics fallidos registrados aún para diagnóstico.)\n';
  let out = `\nDIAGNÓSTICO DE CAPTCHA — clics de descarga sin ZIP: ${DIAG.n}\n`;
  out += 'Patrones (cuántas veces se vio cada estado):\n';
  for (const [k, c] of [...DIAG.agg.entries()].sort((a, b) => b[1] - a[1])) out += `  ${String(c).padStart(4)}×  ${k}\n`;
  out += 'Muestras:\n';
  for (const s of DIAG.samples) {
    out += `  tokenEl=${s.tokenEl} len=${s.tokenLen} grecaptcha=${s.hasGrecaptcha} iframes=${s.captchaIframes} divs=${s.grecaptchaDivs} dlBtn=${s.dlBtn} dis=${s.dlDisabled} alert="${s.alert || s.lastAlert || ''}"\n`;
  }
  return out;
}

function perfReset() { PERF.clear(); DIAG.n = 0; DIAG.agg.clear(); DIAG.samples = []; rangeEvents.length = 0; }
function perfReport() {
  const rows = [...PERF.entries()].map(([k, e]) => ({ k, total: e.sum, avg: e.sum / e.count, count: e.count, max: e.max }));
  rows.sort((a, b) => b.total - a.total);
  const grand = rows.reduce((a, r) => a + r.total, 0) || 1;
  const f = (ms) => (ms / 1000).toFixed(ms < 10000 ? 2 : 1) + 's';
  let out = `Rendimiento por fase (orden: mayor tiempo total)\nv${chrome.runtime.getManifest().version} · ${new Date().toLocaleString()}\n`;
  out += `OK=${okCount} pendientes=${Math.max(0, cufes.length - okCount)} tabs=${TAB_COUNT_SNAPSHOT}\n\n`;
  out += 'Fase'.padEnd(18) + 'Total'.padStart(9) + ' ' + '%'.padStart(5) + ' ' + 'Prom'.padStart(8) + ' ' + 'Máx'.padStart(8) + ' ' + 'Veces'.padStart(6) + '\n';
  for (const r of rows) {
    out += r.k.padEnd(18) + f(r.total).padStart(9) + ' ' + (100 * r.total / grand).toFixed(0).padStart(4) + '%' +
           ' ' + f(r.avg).padStart(8) + ' ' + f(r.max).padStart(8) + ' ' + String(r.count).padStart(6) + '\n';
  }
  out += rangeReport();
  out += diagReport();
  return out;
}
let TAB_COUNT_SNAPSHOT = 3;
const pendingCaptures = new Map(); // tabId -> { resolve } captura CDP en curso

// Rango por AÑO: enero del año de inicio → diciembre del año de fin. Para un reporte de
// 2022 da 2022-01-01 → 2022-12-31; si abarca varios años, los cubre completos. Si no hay
// fechas válidas, cae a un rango amplio (2019 → hoy) como respaldo.
function yearBracket(fromISO, toISO) {
  const yFrom = /^(\d{4})-/.exec(fromISO || '');
  const yTo = /^(\d{4})-/.exec(toISO || '');
  if (yFrom && yTo) {
    const a = Math.min(+yFrom[1], +yTo[1]);
    const b = Math.max(+yFrom[1], +yTo[1]);
    return { from: `${a}-01-01`, to: `${b}-12-31` };
  }
  return { from: '2019-01-01', to: new Date().toISOString().slice(0, 10) };
}
let driveSel = null;               // { connected, selectedConnectionId }
let exporterCfg = null;            // { uploadToDrive, includeDriveLinks, driveConnectionId } del portal
let allowedModes = { masiva: true, exportador: true, terceros: true, pdf: true }; // se ajusta según la cuenta
let isAdminUser = false;
let mergePdf = false;              // Descarga Masiva: unir todos los PDF en uno
let pdfParts = [];                 // [{ i, bytes }] PDFs capturados para fusionar

// Estado del proceso (compartido y persistible para poder REANUDAR si se cierra el panel)
let itemDone = [];
let deferred = [];
let deferredSet = new Set();
let parkedSet = new Set();         // facturas aparcadas como "Pendiente" tras el reintento final
let isResuming = false;            // la corrida actual es una reanudación
let pendingResume = null;          // snapshot cargado de chrome.storage al reabrir

const RUN_KEY = 'contago_run';
const RUN_TTL_MS = 3 * 60 * 60 * 1000; // 3h (igual que el job del backend)

// Guarda el progreso para poder reanudar tras cerrar el panel. Se llama tras cada factura.
function persistRunNow() {
  if (!running) return;
  try {
    const mode = !EXPORT_MODE ? 'masiva' : (jobKind === 'terceros' ? 'terceros' : 'exportador');
    const doneIdx = [];
    for (let i = 0; i < itemDone.length; i++) if (itemDone[i]) doneIdx.push(i);
    const snap = {
      v: 1, ts: Date.now(), mode,
      jobId: currentJob?.jobId || null,
      driveFolderUrl: currentJob?.driveFolderUrl || null,
      cufes, total: cufes.length,
      doneIdx, deferredIdx: deferred.slice(), parkedIdx: [...parkedSet],
      queryFrom: queryRange.from, queryTo: queryRange.to,
      okCount, errCount, listingTipo, downloadFolder,
      elapsedMs: elapsedTotalMs(),   // tiempo acumulado, para trazabilidad al reanudar
      records: Object.fromEntries(recordMap),
    };
    chrome.storage.local.set({ [RUN_KEY]: snap }).catch(() => {});
  } catch (_) {}
}
function clearRun() { try { chrome.storage.local.remove(RUN_KEY); } catch (_) {} }
async function loadSavedRun() {
  try {
    const { [RUN_KEY]: s } = await chrome.storage.local.get(RUN_KEY);
    if (!s || !s.cufes?.length) return null;
    if (Date.now() - (s.ts || 0) > RUN_TTL_MS) { clearRun(); return null; }
    const pending = s.total - (s.doneIdx?.length || 0);
    if (pending <= 0) { clearRun(); return null; }   // ya estaba todo hecho
    return s;
  } catch (_) { return null; }
}

// ¿El ZIP capturado contiene un XML? (valida la captura antes de subir al backend)
async function zipHasXml(bytes) {
  try {
    const zip = await JSZip.loadAsync(bytes);
    return Object.values(zip.files).some(f => !f.dir && /\.xml$/i.test(f.name));
  } catch (_) { return false; }
}

// Extrae el PDF (representación gráfica) de los bytes de un ZIP de la DIAN.
async function extractPdfFromZipBytes(bytes) {
  try {
    const zip = await JSZip.loadAsync(bytes);
    const entry = Object.values(zip.files).find(f => !f.dir && /\.pdf$/i.test(f.name));
    if (!entry) return null;
    return await entry.async('uint8array');
  } catch (_) { return null; }
}

// Une todos los PDF capturados en uno solo y lo descarga.
async function buildAndDownloadMergedPdf() {
  const parts = pdfParts.slice().sort((a, b) => a.i - b.i);
  if (!parts.length) { setLog('No se capturó ningún PDF para unir.', 'warn'); return; }
  setLog(`Uniendo ${parts.length} PDF en uno…`, 'ok');
  const { PDFDocument } = window.PDFLib;
  const out = await PDFDocument.create();
  let added = 0;
  for (const p of parts) {
    try {
      const src = await PDFDocument.load(p.bytes, { ignoreEncryption: true });
      const pages = await out.copyPages(src, src.getPageIndices());
      pages.forEach(pg => out.addPage(pg));
      added++;
    } catch (_) { /* PDF dañado: se omite */ }
  }
  if (!added) { setLog('No se pudo unir ningún PDF (archivos no válidos).', 'err'); return; }
  const blob = new Blob([await out.save()], { type: 'application/pdf' });
  const url = URL.createObjectURL(blob);
  const name = `${downloadFolder || 'Facturas DIAN'}.pdf`;
  pendingExcelName = name; // reusa el forzado de nombre del listener (blob)
  await chrome.downloads.download({ url, filename: name, saveAs: false });
  setTimeout(() => { try { URL.revokeObjectURL(url); } catch (_) {} }, 60000);
  setLog(`📄 PDF unificado con ${added} factura(s) descargado.`, 'ok');
}

function deviceLabel() {
  return (navigator.userAgentData?.platform || navigator.platform || 'Equipo') + ' · ' + new Date().toISOString().slice(0, 10);
}

// Desenvuelve enlaces protegidos por Outlook SafeLinks
// (na01.safelinks.protection.outlook.com/?url=<enlace DIAN codificado>&...).
// Devuelve el enlace DIAN interno; si no es SafeLinks, devuelve el original.
function normalizeAccessLink(link) {
  let url = (link || '').trim();
  for (let i = 0; i < 3; i++) { // por si viene anidado
    try {
      const u = new URL(url);
      if (/(^|\.)safelinks\.protection\.outlook\.com$/i.test(u.hostname) && u.searchParams.get('url')) {
        url = u.searchParams.get('url'); // URLSearchParams ya lo decodifica una vez
        continue;
      }
    } catch (_) {}
    break;
  }
  return url;
}

async function refreshAuthUI() {
  const { token, user, apiBase } = await ContaGO.getAuth();
  const authed = !!token;
  document.getElementById('authCard').classList.toggle('hidden', authed);
  document.getElementById('accountBar').classList.toggle('hidden', !authed);
  document.getElementById('modeCard').classList.toggle('hidden', !authed);
  document.getElementById('toolArea').classList.toggle('hidden', !authed);
  const apiInput = document.getElementById('apiBaseInput');
  if (apiInput && !apiInput.value) apiInput.value = apiBase || '';
  if (authed && user) {
    document.getElementById('accountName').textContent = user.name || 'Cuenta activada';
    document.getElementById('accountEmail').textContent = user.email || '';
  }
  if (authed) {
    try { exporterCfg = await ContaGO.getExporterConfig(); } catch (_) { exporterCfg = null; }
    await loadTools();
  }
}

// Habilita en la extensión solo los modos cuya herramienta tenga el usuario.
async function loadTools() {
  try {
    const t = await ContaGO.getTools();
    isAdminUser = !!t.isAdmin;
    allowedModes = isAdminUser
      ? { masiva: true, exportador: true, terceros: true, pdf: true }
      : { masiva: !!t.modes.masiva, exportador: !!t.modes.exportador, terceros: !!t.modes.terceros, pdf: true };
  } catch (_) {}
  applyModeAccess();
}

function firstAllowedMode() {
  return ['masiva', 'exportador', 'terceros', 'pdf'].find((m) => allowedModes[m]) || null;
}

function applyModeAccess() {
  for (const btn of document.querySelectorAll('.mode-btn')) {
    const m = btn.dataset.mode;
    const ok = !!allowedModes[m];
    btn.disabled = !ok;
    btn.style.opacity = ok ? '1' : '0.5';
    btn.style.cursor = ok ? 'pointer' : 'not-allowed';
    btn.title = ok ? '' : 'No tienes esta herramienta habilitada en tu cuenta';
    const sub = btn.querySelectorAll('div')[1];
    if (sub) {
      if (sub.dataset.label === undefined) sub.dataset.label = sub.textContent;
      sub.textContent = ok ? sub.dataset.label : '🔒 No habilitada';
    }
  }
  // SIEMPRE re-aplicar el modo (no solo si el actual está bloqueado): setMode es
  // lo que muestra el toggle de "unir PDF" en Masiva, la pista del Drive, etc.
  // Si el modo activo está permitido se conserva; si no, se pasa al primero válido.
  const current = document.querySelector('.mode-btn.active')?.dataset.mode;
  const target = (current && allowedModes[current]) ? current : firstAllowedMode();
  if (target) setMode(target);
}

function setMode(mode) {
  if (!allowedModes[mode]) { setLog('No tienes esta herramienta habilitada en tu cuenta.', 'warn'); return; }
  EXPORT_MODE = mode !== 'masiva' && mode !== 'pdf'; // exportador y terceros usan el backend
  PDF_MODE = mode === 'pdf';
  jobKind = mode === 'terceros' ? 'terceros' : 'invoices';
  for (const btn of document.querySelectorAll('.mode-btn')) {
    const on = btn.dataset.mode === mode;
    btn.classList.toggle('active', on);
    btn.style.borderColor = on ? 'var(--purple)' : '#e0e0e0';
    btn.style.background = on ? '#f4ecfb' : 'white';
    btn.querySelector('div').style.color = on ? 'var(--purple-dark)' : '#666';
  }
  const sub = document.querySelector('#uploadArea .upload-sub');
  if (sub) {
    sub.textContent = mode === 'pdf'
      ? 'ZIP o Excel con columna CUFE/CUDE (nómina y eventos se omiten)'
      : mode === 'terceros'
        ? 'Generará el Excel de terceros consolidado'
        : mode === 'exportador'
          ? (exporterCfg?.uploadToDrive ? 'Irá a Drive + Excel consolidado (según el portal)' : 'Generará el Excel consolidado (según el portal)')
          : 'El Excel debe tener columna CUFE/CUDE';
  }
  // Opción "unir PDF" solo aplica en Descarga Masiva
  const mo = document.getElementById('masivaOptions');
  if (mo) mo.style.display = mode === 'masiva' ? 'flex' : 'none';
  // Modo PDF: mostrar tarjeta de CUFEs, ocultar token; uploadCard visible pero sin filtro de año
  const isPdf = mode === 'pdf';
  document.getElementById('tokenCard')?.classList.toggle('hidden', isPdf);
  document.getElementById('uploadCard')?.classList.remove('hidden');
  // Filtro de año no aplica en PDF (los CUFEs van directo al catálogo)
  const yearRow = document.getElementById('yearFilter')?.closest('div[style]');
  if (yearRow) yearRow.style.display = isPdf ? 'none' : '';
  document.getElementById('pdfCard')?.classList.toggle('hidden', !isPdf);
  // Botón de acción según modo
  const btn = document.getElementById('actionBtn');
  if (isPdf && !running) {
    btn.textContent = 'Pega los CUFE primero';
    btn.disabled = true;
    btn.className = 'start';
  }
}

document.getElementById('activateBtn').addEventListener('click', async () => {
  const msg = document.getElementById('authMsg');
  const code = (document.getElementById('activationInput').value || '').trim();
  const apiOverride = (document.getElementById('apiBaseInput').value || '').trim();
  if (code.length < 6) { msg.textContent = 'Pega el código de activación.'; msg.style.color = '#e53935'; return; }
  msg.textContent = 'Activando…'; msg.style.color = '#888';
  try {
    if (apiOverride) await ContaGO.setApiBase(apiOverride);
    const user = await ContaGO.activate(code, deviceLabel());
    msg.textContent = '✓ Activada: ' + (user.email || '');
    msg.style.color = 'var(--purple)';
    await refreshAuthUI();   // carga herramientas y selecciona el primer modo permitido
  } catch (e) {
    msg.textContent = '✗ ' + (e.message || 'No se pudo activar');
    msg.style.color = '#e53935';
  }
});

document.getElementById('logoutBtn').addEventListener('click', async () => {
  await ContaGO.logout();
  await refreshAuthUI();
});

document.getElementById('modeMasiva').addEventListener('click', () => setMode('masiva'));
document.getElementById('modeExport').addEventListener('click', () => setMode('exportador'));
document.getElementById('modeTerceros').addEventListener('click', () => setMode('terceros'));
document.getElementById('modePdf').addEventListener('click', () => setMode('pdf'));

// Textarea PDF (oculta): actualiza contador y habilita el botón de inicio cuando cambia el contenido
document.getElementById('pdfCufeInput').addEventListener('input', () => {
  const cufeList = parsePdfCufeInput();
  const countEl = document.getElementById('pdfCufeCount');
  const btn = document.getElementById('actionBtn');
  if (!running) {
    countEl.textContent = cufeList.length ? `${cufeList.length} CUFEs cargados` : '';
    btn.disabled = cufeList.length === 0;
    btn.textContent = cufeList.length ? `Descargar ${cufeList.length} PDF(s)` : 'Selecciona un archivo primero';
    btn.className = 'start';
  }
});
document.getElementById('reloadToolsBtn').addEventListener('click', async (e) => {
  const btn = e.currentTarget;
  const prev = btn.textContent; btn.textContent = '↻ …'; btn.disabled = true;
  try { exporterCfg = await ContaGO.getExporterConfig(); } catch (_) {}
  await loadTools();
  btn.textContent = prev; btn.disabled = false;
});

// ── Reanudar un proceso interrumpido ──────────────────────────────────────────
async function offerResumeIfAny() {
  const s = await loadSavedRun();
  if (!s) return;
  pendingResume = s;
  const done = s.doneIdx?.length || 0;
  const pending = s.total - done;
  const modeTxt = s.mode === 'masiva' ? 'Descarga Masiva' : s.mode === 'terceros' ? 'Terceros' : 'Exportador';
  const tMs = s.elapsedMs || 0;
  const tTxt = tMs ? ` · llevaba ${String(Math.floor(tMs / 60000)).padStart(2, '0')}:${String(Math.floor(tMs / 1000) % 60).padStart(2, '0')}` : '';
  document.getElementById('resumeMsg').textContent =
    `Quedó a medias (${modeTxt}): ${done}/${s.total} listas, faltan ${pending}${tTxt}. Reanuda donde quedó sin perder lo avanzado.`;
  document.getElementById('resumeBanner').classList.remove('hidden');
}

function doResumeRestore(s) {
  cufes = s.cufes || [];
  itemDone = new Array(cufes.length).fill(false);
  for (const i of (s.doneIdx || [])) if (i < itemDone.length) itemDone[i] = true;
  deferred = (s.deferredIdx || []).slice();
  deferredSet = new Set(deferred);
  parkedSet = new Set();   // al reanudar, las aparcadas reciben una oportunidad nueva
  // Al reanudar: usar el rango del snapshot; si viene vacío (snapshot viejo o sin rango),
  // recae al respaldo amplio (2019→hoy) para que el filtro de fechas SÍ se aplique.
  queryRange = (s.queryFrom && s.queryTo) ? { from: s.queryFrom, to: s.queryTo } : yearBracket('', '');
  dateRangeReady.clear(); dateRangeAttempts.clear();
  okCount = s.okCount || 0; errCount = s.errCount || 0;
  accumulatedMs = s.elapsedMs || 0;   // continúa el cronómetro desde donde quedó
  listingTipo = s.listingTipo || 'recibido';
  downloadFolder = s.downloadFolder || '';
  recordMap.clear();
  for (const [c, d] of Object.entries(s.records || {})) recordMap.set(c, d);
  currentJob = s.jobId ? { jobId: s.jobId, driveFolderUrl: s.driveFolderUrl || null } : null;
  EXPORT_MODE = s.mode !== 'masiva';
  jobKind = s.mode === 'terceros' ? 'terceros' : 'invoices';
  try { setMode(s.mode); } catch (_) {}   // UI del modo (si la cuenta lo permite)
  isResuming = true;
  renderList();
  for (let i = 0; i < itemDone.length; i++) if (itemDone[i]) setItemState(i, 'done', '✅', 'Hecho');
  document.getElementById('statTotal').textContent = cufes.length;
  document.getElementById('statOk').textContent = okCount;
  document.getElementById('statErr').textContent = errCount;
  document.getElementById('progressCard').classList.remove('hidden');
  updateProgress(okCount + errCount);
  const pending = cufes.length - itemDone.filter(Boolean).length;
  const btn = document.getElementById('actionBtn');
  btn.disabled = false; btn.className = 'start';
  btn.textContent = `▶ Reanudar (faltan ${pending})`;
  document.getElementById('resumeBanner').classList.add('hidden');
  setLog(`Listo para reanudar ${pending} factura(s) · rango ${queryRange.from} → ${queryRange.to}. Pega el enlace de acceso DIAN y pulsa Reanudar.`, 'ok');
}

document.getElementById('resumeBtn').addEventListener('click', () => { if (pendingResume) doResumeRestore(pendingResume); });
document.getElementById('pauseTokenBtn').addEventListener('click', () => {
  if (!running || stopRequested || reauthRequested) return;
  manualPause = true;
  reauthRequested = true;  // los workers paran al terminar la factura en curso → doReauth pedirá el token
  document.getElementById('pauseTokenBtn').disabled = true;
  document.getElementById('pauseTokenBtn').textContent = 'Pausando… (termina la factura en curso)';
  setLog('⏸️ Pausa solicitada. En cuanto terminen las facturas en curso, pega el token nuevo en el recuadro.', 'warn');
});
document.getElementById('perfBtn').addEventListener('click', async () => {
  if (PERF.size === 0) { setLog('Aún no hay métricas — corre al menos unas facturas y vuelve a pulsar.', 'warn'); return; }
  const report = perfReport();
  try { await navigator.clipboard.writeText(report); setLog('📋 Reporte de rendimiento copiado al portapapeles — pégalo aquí en el chat.', 'ok'); }
  catch (_) { setLog('No se pudo copiar; revisa la consola del panel (clic derecho → Inspeccionar).', 'warn'); }
  console.log('[PERF]\n' + report);
});
document.getElementById('discardResumeBtn').addEventListener('click', () => {
  clearRun(); pendingResume = null;
  document.getElementById('resumeBanner').classList.add('hidden');
});

refreshAuthUI().then(offerResumeIfAny);

// ── File upload ────────────────────────────────────────────────────────────────
document.getElementById('uploadArea').addEventListener('click', () => {
  document.getElementById('fileInput').click();
});

document.getElementById('fileInput').addEventListener('change', async (e) => {
  const file = e.target.files[0];
  if (!file) return;
  uploadedFile = file; // se reenvía al backend para crear el job del Exportador
  // Archivo nuevo = corrida fresca: descarta cualquier reanudación pendiente.
  isResuming = false; pendingResume = null;
  document.getElementById('resumeBanner').classList.add('hidden');
  setLog('Leyendo archivo...');
  resetProgress();
  const btn = document.getElementById('actionBtn');
  try {
    const result = file.name.toLowerCase().endsWith('.zip')
      ? await readCufesFromZip(file)
      : await readCufesFromExcel(file);

    // Modo PDF: poblar textarea con los CUFEs filtrados (nómina/eventos ya excluidos)
    if (PDF_MODE) {
      const cufeList = result.cufes || [];
      if (!cufeList.length) { setLog('No se encontraron CUFEs en el archivo.', 'err'); return; }
      const nominaTxt = result.omittedNomina ? ` · ${result.omittedNomina} nómina/eventos omitidos` : '';
      const ta = document.getElementById('pdfCufeInput');
      ta.value = cufeList.join('\n');
      ta.dispatchEvent(new Event('input')); // actualiza contador y habilita botón
      setLog(`${cufeList.length} CUFEs cargados desde ${file.name}${nominaTxt}.`, 'ok');
      document.getElementById('uploadFilename').textContent = `✓ ${file.name}  (${cufeList.length} CUFEs)`;
      document.getElementById('uploadFilename').classList.remove('hidden');
      document.getElementById('uploadArea').classList.add('has-file');
      return;
    }

    cufes = result.cufes || [];
    if (cufes.length === 0) { setLog('No se encontró la columna CUFE/CUDE o está vacía.', 'err'); return; }

    document.getElementById('uploadFilename').textContent = `✓ ${file.name}  (${cufes.length} registros)`;
    document.getElementById('uploadFilename').classList.remove('hidden');
    document.getElementById('uploadArea').classList.add('has-file');
    document.getElementById('statTotal').textContent = cufes.length;
    renderList();
    document.getElementById('progressCard').classList.remove('hidden');

    // ── Listado mixto: no se puede procesar ──
    if (result.mixed) {
      listingTipo = null; downloadFolder = '';
      btn.disabled = true; btn.className = 'start';
      btn.textContent = 'Listado mixto — no se puede procesar';
      setLog('⚠️ El listado tiene facturas RECIBIDAS y EMITIDAS mezcladas. Sepáralas en dos archivos y procesa uno a la vez.', 'err');
      return;
    }

    // ── Tipo + carpeta destino ──
    listingTipo = result.tipo || 'recibido'; // si no se detectó, se asume recibidas
    downloadFolder = buildFolderName(listingTipo, result.nit, result.nombre);
    const tipoTxt = listingTipo === 'emitido' ? 'EMITIDAS' : 'RECIBIDAS';
    const destino = listingTipo === 'emitido' ? 'Documentos enviados' : 'Documentos recibidos';

    btn.disabled = false;
    btn.className = 'start';
    btn.textContent = `Iniciar descarga (${cufes.length} facturas)`;
    updateETA();

    const nominaTxt = result.omittedNomina ? ` · ${result.omittedNomina} de nómina omitidas` : '';
    setLog(`${cufes.length} facturas ${tipoTxt}${nominaTxt}. Irá a ${destino}.`, 'ok');
    document.getElementById('uploadFilename').textContent =
      `✓ ${file.name} · ${cufes.length} facturas ${tipoTxt}` +
      (result.omittedNomina ? ` (${result.omittedNomina} de nómina omitidas)` : '') +
      (result.tipo ? '' : ' (tipo no detectado → asumo Recibidas)') +
      `\n📁 ${downloadFolder}`;
    document.getElementById('uploadFilename').style.whiteSpace = 'pre-line';
  } catch (err) {
    setLog('Error leyendo archivo: ' + err.message, 'err');
  }
});

// ── Excel / ZIP parsing ────────────────────────────────────────────────────────
async function readCufesFromZip(file) {
  const zip = await JSZip.loadAsync(file);
  const entry = Object.values(zip.files).find(f => /\.(xlsx|xls|xlsm)$/i.test(f.name) && !f.dir);
  if (!entry) throw new Error('No se encontró ningún Excel dentro del ZIP.');
  return parseExcelBuffer(await entry.async('arraybuffer'));
}
async function readCufesFromExcel(file) {
  return parseExcelBuffer(await file.arrayBuffer());
}
function parseExcelBuffer(ab) {
  const wb = XLSX.read(ab, { type: 'array' });
  if (!wb.SheetNames.length) throw new Error('El Excel está vacío.');
  for (const sheet of wb.SheetNames) {
    const rows = XLSX.utils.sheet_to_json(wb.Sheets[sheet], { header: 1, defval: '' });
    if (rows.length < 2) continue;
    const headers = rows[0].map(h => String(h || '').toLowerCase().trim());
    const idx = headers.findIndex(h => h.includes('cufe') || h.includes('cude') || (h.includes('digo') && h.includes('nico')));
    if (idx === -1) continue;

    const tipoIdx = headers.findIndex(h => h.includes('tipo') && h.includes('doc'));
    const grupoIdx = headers.findIndex(h => h.includes('grupo'));
    const emiNitIdx = headers.findIndex(h => h.includes('nit') && h.includes('emisor'));
    const emiNomIdx = headers.findIndex(h => h.includes('nombre') && h.includes('emisor'));
    const recNitIdx = headers.findIndex(h => h.includes('nit') && h.includes('receptor'));
    const recNomIdx = headers.findIndex(h => h.includes('nombre') && h.includes('receptor'));

    // Tipos que NO se descargan: eventos (Application response) y NÓMINA individual
    // (no traen el ZIP/PDF que descarga la extensión → solo harían recargar en vano).
    const norm = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
    const isOmitidaNomina = (r) => tipoIdx !== -1 && norm(r[tipoIdx]).includes('nomina');
    const isEvento = (r) => tipoIdx !== -1 && norm(r[tipoIdx]).includes('application response');

    const withCufe = rows.slice(1).filter(r => String(r[idx] || '').trim().length > 20);
    const omittedNomina = withCufe.filter(isOmitidaNomina).length;
    // Filas a procesar: con CUFE, no evento, no nómina
    const dataRows = withCufe.filter(r => !isEvento(r) && !isOmitidaNomina(r));
    if (dataRows.length === 0) continue;

    const cufes = dataRows.map(r => String(r[idx] || '').trim());

    // Tipo del listado según la columna "Grupo": recibido / emitido / mixto
    let tipo = null, mixed = false;
    if (grupoIdx !== -1) {
      const kinds = new Set();
      for (const r of dataRows) {
        const g = String(r[grupoIdx] || '').toLowerCase();
        if (g.includes('recib')) kinds.add('recibido');
        else if (g.includes('emit') || g.includes('envi')) kinds.add('emitido');
      }
      if (kinds.size > 1) mixed = true;
      else if (kinds.size === 1) tipo = [...kinds][0];
    }

    // Empresa procesada: receptor (recibidas) o emisor (emitidas). Valor más frecuente.
    const mostCommon = (colIdx) => {
      if (colIdx < 0) return '';
      const counts = {};
      for (const r of dataRows) { const v = String(r[colIdx] || '').trim(); if (v) counts[v] = (counts[v] || 0) + 1; }
      return Object.entries(counts).sort((a, b) => b[1] - a[1])[0]?.[0] || '';
    };
    let nit = '', nombre = '';
    if (tipo === 'emitido') { nit = mostCommon(emiNitIdx); nombre = mostCommon(emiNomIdx); }
    else { nit = mostCommon(recNitIdx); nombre = mostCommon(recNomIdx); } // recibido o desconocido → receptor

    return { cufes, tipo, mixed, nit, nombre, omittedNomina };
  }
  const headers = XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]], { header: 1, defval: '' })[0] || [];
  throw new Error(`Columna CUFE/CUDE no encontrada. Columnas: ${headers.map(h => `"${h}"`).join(', ')}`);
}

// ── Render list ────────────────────────────────────────────────────────────────
function renderList() {
  const list = document.getElementById('cufeList');
  list.innerHTML = '';
  cufes.forEach((cufe, i) => {
    const div = document.createElement('div');
    div.className = 'list-item';
    div.id = `item-${i}`;
    div.innerHTML = `
      <span class="item-num">${i + 1}</span>
      <span class="item-icon" id="icon-${i}">⬜</span>
      <span class="item-cufe" title="${cufe}">${cufe}</span>
      <span class="item-status" id="istatus-${i}">Pendiente</span>`;
    list.appendChild(div);
  });
}

// ── Pausa: esperar acción del usuario ─────────────────────────────────────────
function showPause(msg) {
  document.getElementById('pauseMsg').textContent = msg;
  document.getElementById('pauseBanner').style.display = 'block';
  return new Promise(resolve => { pauseResolver = resolve; });
}
function hidePause() {
  document.getElementById('pauseBanner').style.display = 'none';
  pauseResolver = null;
}

document.getElementById('retryBtn').addEventListener('click', () => {
  if (pauseResolver) { hidePause(); pauseResolver('retry'); }
});
document.getElementById('skipBtn').addEventListener('click', () => {
  if (pauseResolver) { hidePause(); pauseResolver('skip'); }
});

// ── Re-login: pedir un token nuevo (espera indefinida) ────────────────────────
function askNewToken() {
  const banner = document.getElementById('reauthBanner');
  document.getElementById('reauthInput').value = '';
  document.querySelector('#reauthBanner .pause-title').textContent = manualPause ? '⏸️ Pausa — token nuevo' : '🔑 Token vencido';
  document.getElementById('reauthMsg').textContent = manualPause
    ? 'Pausaste el proceso. Pega un enlace de acceso NUEVO (token fresco) para reanudar donde quedó — útil cuando la DIAN empieza a no entregar archivos por límite de volumen.'
    : 'El token de acceso venció. Pega un enlace de acceso NUEVO para continuar donde quedó. La herramienta espera el tiempo que haga falta.';
  banner.style.display = 'block';
  banner.scrollIntoView({ block: 'center', behavior: 'smooth' });
  return new Promise(resolve => { reauthResolver = resolve; });
}
document.getElementById('reauthBtn').addEventListener('click', () => {
  if (!reauthResolver) return;
  const link = normalizeAccessLink(document.getElementById('reauthInput').value);
  if (!/^https?:\/\//i.test(link)) {
    document.getElementById('reauthMsg').textContent = '⚠️ El enlace debe empezar con http(s):// — pega el enlace completo del correo.';
    return;
  }
  document.getElementById('reauthBanner').style.display = 'none';
  const r = reauthResolver; reauthResolver = null; r(link);
});

// ── Main loop ──────────────────────────────────────────────────────────────────
document.getElementById('actionBtn').addEventListener('click', async () => {
  if (running) {
    stopRequested = true;
    if (reauthResolver) { document.getElementById('reauthBanner').style.display = 'none'; const r = reauthResolver; reauthResolver = null; r(null); }
    document.getElementById('actionBtn').textContent = PDF_MODE ? 'Deteniendo…' : (EXPORT_MODE ? 'Finalizando…' : 'Deteniendo…');
    document.getElementById('actionBtn').disabled = true;
    return;
  }
  // Modo PDF: flujo propio, no necesita la pestaña DIAN de facturas ni el token de acceso
  const activeModeBtn = document.querySelector('.mode-btn.active')?.dataset.mode;
  if (PDF_MODE || activeModeBtn === 'pdf') {
    PDF_MODE = true;
    runPdfDownload().catch(e => {
      running = false; stopTimer();
      setLog('Error en descarga PDF: ' + (e.message || e), 'err');
      const b = document.getElementById('actionBtn');
      b.className = 'start'; b.disabled = false;
      b.textContent = `Descargar ${cufes.length || ''} PDF(s)`.trim();
    });
    return;
  }

  // Obtener la pestaña: si pegaron un enlace de acceso, abrimos el portal con él
  let tab;
  const accessLink = normalizeAccessLink(document.getElementById('tokenInput').value);
  if (accessLink) {
    if (!/^https?:\/\//i.test(accessLink)) { setLog('El enlace de acceso debe empezar con http(s)://', 'err'); return; }
    setLog('Abriendo el portal con el enlace de acceso…');
    const r = await accessWithLink(accessLink);
    if (!r.tab) { setLog('No se pudo abrir el enlace de acceso.', 'err'); return; }
    if (r.stuckLogin) { setLog('El enlace sigue redirigiendo al login tras varios intentos. ¿El token es válido y actual?', 'err'); return; }
    tab = r.tab;
  } else {
    tab = await findInvoiceTab();
  }
  if (!tab) { setLog('No se encontró la pestaña de facturas. Abre la página DIAN o pega el enlace de acceso.', 'err'); return; }

  running = true;
  stopRequested = false;
  fatalReason = '';
  if (!isResuming) {
    okCount = 0; errCount = 0; accumulatedMs = 0;
    perfReset();   // empezar con métricas de rendimiento limpias
    // "Unir PDF" solo aplica en Descarga Masiva (debe quedar fijado antes de prepareTabs).
    mergePdf = !EXPORT_MODE && !!document.getElementById('mergePdfChk')?.checked;
    pdfParts = [];
  } else {
    // Reanudación: okCount/errCount/itemDone/deferred/currentJob ya vienen restaurados.
    mergePdf = false; pdfParts = []; // el PDF unificado no se reanuda (los ZIP ya están en disco)
  }
  document.getElementById('statOk').textContent = String(okCount);
  document.getElementById('statErr').textContent = String(errCount);

  const btn = document.getElementById('actionBtn');
  btn.className = 'stop';
  btn.textContent = EXPORT_MODE ? 'Finalizar y entregar Excel' : 'Detener';
  btn.disabled = false;
  // Botón de pausa para token nuevo: visible solo en Exportador mientras corre.
  const ptb = document.getElementById('pauseTokenBtn');
  ptb.style.display = EXPORT_MODE ? 'block' : 'none';
  ptb.disabled = false; ptb.textContent = '⏸️ Pausar para nuevo token';
  if (EXPORT_MODE) setLog('Cada factura con error se intenta 2 veces; si falla, va a la cola y se reintenta al final. Las que aún no se logren quedan como "Pendiente" y el Excel se entrega solo al terminar. Puedes cerrar antes con "Finalizar y entregar Excel".', 'warn');

  // ── Exportador: crear el job en ContaGO (sube el listado y recibe los CUFEs) ──
  // En reanudación NO se crea job nuevo: currentJob y recordMap ya vienen restaurados.
  if (!isResuming) {
  currentJob = null; recordMap.clear();
  if (EXPORT_MODE) {
    if (!uploadedFile) {
      setLog('Sube primero el listado (Excel/ZIP) para el Exportador.', 'err');
      running = false; btn.className = 'start'; btn.disabled = false; btn.textContent = `Iniciar descarga (${cufes.length} facturas)`;
      return;
    }
    setLog('Creando el proceso en ContaGO…');
    try {
      // Parámetros tal cual los configuró el usuario en el portal (Exportador DIAN).
      const cfg = jobKind === 'terceros'
        ? { uploadToDrive: false, includeDriveLinks: false, driveConnectionId: null }
        : await ContaGO.getExporterConfig();
      const job = await ContaGO.createExportJob({
        excelBlob: uploadedFile,
        filename: uploadedFile.name,
        mode: jobKind,
        uploadToDrive: cfg.uploadToDrive,
        driveConnectionId: cfg.driveConnectionId,
        includeDriveLinks: cfg.includeDriveLinks,
      });
      currentJob = job;
      for (const r of (job.records || [])) recordMap.set(r.cufe, r.docnum || '');
      // Rango por AÑO del listado: enero–diciembre del año (o años) que cubra el listado,
      // derivado de las fechas que devuelve el backend. Así la búsqueda por CUFE en la DIAN
      // queda precisa al periodo del reporte (p. ej. 2022-01-01 → 2022-12-31). Si el listado
      // no trajo fechas, cae a un rango amplio (2019 → hoy) como respaldo.
      const yearSel = (document.getElementById('yearFilter')?.value || 'auto').trim();
      if (yearSel && yearSel !== 'auto' && yearSel !== 'anterior' && /^\d{4}$/.test(yearSel)) {
        queryRange = { from: `${yearSel}-01-01`, to: `${yearSel}-12-31` };
      } else {
        queryRange = yearBracket(job.startDate, job.endDate);
      }
      dateRangeReady.clear(); dateRangeAttempts.clear();
      setLog(`Rango de búsqueda: ${queryRange.from} → ${queryRange.to}.`, 'ok');
      const kindTxt = jobKind === 'terceros' ? 'terceros' : 'facturas';
      const driveTxt = jobKind === 'terceros' ? '' : (cfg.uploadToDrive ? ' · Drive activo' : ' · sin Drive') + (cfg.includeDriveLinks ? ' · con enlaces' : '');
      setLog(`Proceso ContaGO creado (${job.totalProcessable} ${kindTxt})${driveTxt}.`, 'ok');
    } catch (e) {
      setLog('No se pudo crear el proceso en ContaGO: ' + (e.message || e), 'err');
      running = false; btn.className = 'start'; btn.disabled = false; btn.textContent = `Iniciar descarga (${cufes.length} facturas)`;
      return;
    }
  }
  // Modo Masiva: queryRange viene del selector de año (EXPORT_MODE lo fija arriba en su bloque)
  if (!EXPORT_MODE) {
    const yearSel = (document.getElementById('yearFilter')?.value || 'auto').trim();
    if (yearSel && yearSel !== 'auto' && yearSel !== 'anterior' && /^\d{4}$/.test(yearSel)) {
      queryRange = { from: `${yearSel}-01-01`, to: `${yearSel}-12-31` };
    } else if (!queryRange.from) {
      queryRange = yearBracket('', '');
    }
    dateRangeReady.clear(); dateRangeAttempts.clear();
    if (queryRange.from) setLog(`Rango de búsqueda: ${queryRange.from} → ${queryRange.to}.`, 'ok');
  }
  } // /if (!isResuming)

  startTimer();               // cronómetro + velocidad facturas/min
  await setDownloadUi(false); // ocultar la barra/burbuja de descargas durante la corrida

  const MAX_AUTO_RETRIES = 2; // reintentos pesados (con recarga) por CUFE antes de encolar
  const PACE_SEC = 1;         // ritmo fijo entre descargas (1 s)
  const TAB_COUNT = 3;        // pestañas en paralelo (fijo)
  TAB_COUNT_SNAPSHOT = TAB_COUNT;

  // ── Sección destino según el tipo del listado ──
  const isEmit = listingTipo === 'emitido';
  const DOC_PATH = isEmit ? '/Document/Sent' : '/Document/Received';
  const DOC_URL = 'https://catalogo-vpfe.dian.gov.co' + DOC_PATH;
  const seccion = isEmit ? 'Documentos enviados' : 'Documentos recibidos';

  // ── Estado compartido entre workers ──
  let tabs = [];
  let createdTabs = [];
  if (!isResuming) {
    // facturas en cola (fallaron 2 veces) y completadas; en reanudación ya vienen restauradas
    deferred = []; deferredSet = new Set();
    itemDone = new Array(cufes.length).fill(false);
    parkedSet = new Set();
  }
  reauthRequested = false; manualPause = false;  // re-auth: token vencido o pausa manual
  // Salud de las pestañas: se refrescan cada N descargas (la página/reCAPTCHA se
  // degrada tras muchas y el botón deja de responder); enfriamiento si hay racha
  // de fallos (para que la DIAN/captcha se recupere).
  const RELOAD_EVERY = 40;
  const FAIL_COOLDOWN_AT = 8;
  const COOLDOWN_SEC = 45;
  const tabDownloadCount = new Map();   // tabId -> descargas desde el último refresco
  let consecutiveFails = 0;
  let cooldownUntil = 0;
  // Concurrencia de captura: 2 en Exportador (la captura es por pestaña vía CDP, no usa
  // estado global → es seguro paralelizar), 1 en Masiva (la detección de descarga en disco
  // sí requiere serializar). Semáforo simple con cola FIFO.
  const CAPTURE_CONCURRENCY = EXPORT_MODE ? 2 : 1;
  let capActive = 0;
  const capQueue = [];
  const acquireSlot = () => new Promise((resolve) => {
    const grab = () => { if (capActive < CAPTURE_CONCURRENCY) { capActive++; resolve(); } else capQueue.push(grab); };
    grab();
  });
  const releaseSlot = () => { capActive--; const next = capQueue.shift(); if (next) next(); };
  const withDownloadLock = async (fn) => {
    await acquireSlot();
    try { return await fn(); } finally { releaseSlot(); }
  };
  const exec = (tabId, func, args = []) => chrome.scripting.executeScript({ target: { tabId }, func, args });
  const logAlert = async (tabId, i) => { const m = await readLastAlert(tabId); if (m) setLog(`[#${i + 1}] Alerta aceptada automáticamente: "${m.slice(0, 70)}"`, 'warn'); };

  // Navega la pestaña principal a la sección correcta y abre TAB_COUNT pestañas en paralelo
  async function prepareTabs(primaryTab) {
    await waitNotChallenge(primaryTab.id, 60000); // no navegar durante la verificación de Azure
    const cur = await chrome.tabs.get(primaryTab.id).catch(() => primaryTab);
    if (!new RegExp(DOC_PATH.replace(/\//g, '\\/'), 'i').test(cur.url || '')) {
      setLog(`Navegando a Histórico → ${seccion}…`);
      try { await chrome.tabs.update(primaryTab.id, { url: DOC_URL }); } catch (_) {}
      await waitNotChallenge(primaryTab.id, 60000);
    }
    if (!(await waitTabReady(primaryTab.id, 60000))) { setLog(`No cargó "${seccion}" (¿verificación de Azure o token vencido?).`, 'err'); return false; }
    const newTabs = [primaryTab];
    const newCreated = [];
    for (let n = 1; n < TAB_COUNT; n++) {
      setLog(`Abriendo pestaña ${n + 1} de ${TAB_COUNT} en ${seccion}…`);
      try {
        const dup = await chrome.tabs.duplicate(primaryTab.id); // hereda URL + sesión/token
        if (await waitTabReady(dup.id, 30000)) { newTabs.push(dup); newCreated.push(dup.id); }
        else { try { await chrome.tabs.remove(dup.id); } catch (_) {} setLog(`La pestaña ${n + 1} no quedó lista; sigo con ${newTabs.length}.`, 'warn'); }
      } catch (e) { setLog(`No se pudo abrir la pestaña ${n + 1}.`, 'warn'); }
    }
    for (const t of newTabs) { await attachDialogAutoAccept(t.id); await installAlertAutoAccept(t.id); }
    tabs = newTabs; createdTabs = newCreated;
    setLog(`Procesando con ${tabs.length} pestaña(s)…`);
    return true;
  }

  // ¿Venció el token? La DIAN redirige a /User/Login cuando expira (señal más fiable).
  async function detectExpiry(tabId) {
    try {
      const t = await chrome.tabs.get(tabId);
      if (/\/user\/login/i.test(t.url || '')) return true; // redirigido al login → token vencido
    } catch (_) { return true; } // pestaña perdida → sesión muerta
    try { const r = await exec(tabId, pageStatus); return r?.[0]?.result === 'login'; } catch (_) { return false; }
  }

  // Cierra todo, pide un token NUEVO (espera indefinida) y reabre el proceso donde quedó
  async function doReauth() {
    // marcar como pausadas las que estaban activas
    const pauseTxt = manualPause ? 'Pausada (esperando token nuevo)' : 'Pausada (token vencido)';
    for (let k = 0; k < cufes.length; k++) {
      const el = document.getElementById(`item-${k}`);
      if (el && el.classList.contains('s-active')) setItemState(k, 'paused', '🔑', pauseTxt);
    }
    await detachDialogAutoAccept();
    for (const id of [...createdTabs]) { try { await chrome.tabs.remove(id); } catch (_) {} }
    try { await chrome.tabs.remove(tab.id); } catch (_) {}
    tabs = []; createdTabs = [];
    setLog(manualPause
      ? `⏸️ Pausa solicitada. Pega un enlace de acceso NUEVO para reanudar (van ${okCount}/${cufes.length}).`
      : `🔑 Token vencido. Pega un enlace de acceso NUEVO para continuar (van ${okCount}/${cufes.length}).`, 'err');
    const link = await askNewToken();          // espera el tiempo que haga falta
    if (link === null || stopRequested) return false; // el usuario pulsó Detener
    setLog('Reabriendo el portal con el nuevo token…');
    const r = await accessWithLink(link);
    if (stopRequested) return false;
    if (!r.tab || r.stuckLogin) { setLog('El nuevo enlace sigue rebotando al login. Pega otro…', 'err'); return await doReauth(); }
    tab = r.tab;
    if (!(await prepareTabs(tab))) return await doReauth();
    // Reanudando con el token nuevo → re-habilitar el botón de pausa.
    const ptb = document.getElementById('pauseTokenBtn');
    ptb.disabled = false; ptb.textContent = '⏸️ Pausar para nuevo token'; ptb.style.display = 'block';
    setLog(`▶️ Reanudando con el token nuevo (van ${okCount}/${cufes.length}).`, 'ok');
    return true;
  }

  // Ritmo entre descargas (se llama DENTRO del candado, tras una descarga, para espaciar globalmente)
  async function applyPacing() {
    if (stopRequested || PACE_SEC <= 0) return;
    await countdownWait(PACE_SEC, 'siguiente');
  }

  // Búsqueda en paralelo + descarga serializada bajo candado
  async function searchAndDownload(tabId, i, cufe) {
    // Enfriamiento global si hubo racha de fallos (deja que la DIAN/captcha se recupere).
    if (cooldownUntil > Date.now() && !stopRequested) {
      const s = Math.ceil((cooldownUntil - Date.now()) / 1000);
      setItemState(i, 'active', '⏸️', `Enfriando ${s}s…`);
      await countdownWait(s, 'enfriando');
    }
    // Refresco proactivo de la pestaña cada N descargas (evita que el botón "se muera").
    if ((tabDownloadCount.get(tabId) || 0) >= RELOAD_EVERY && !stopRequested) {
      setItemState(i, 'active', '🔄', 'Refrescando pestaña…');
      await reloadAndWait(tabId);
      tabDownloadCount.set(tabId, 0);
    }
    // Fijar el rango de fechas del lote en el filtro de la DIAN (una vez por carga de
    // página). Sin esto, buscar por CUFE no encuentra documentos de periodos fuera del
    // rango por defecto (p. ej. reportes de años anteriores).
    await perfTime('rango-fechas', ensureDateRange(tabId, i));
    setItemState(i, 'active', '⏳', 'Buscando…');
    const r1 = await perfTime('1-buscar', exec(tabId, pageStep1_FillAndSearch, [cufe]));
    if (!r1?.[0]?.result?.ok) { await logAlert(tabId, i); return { ok: false, error: r1?.[0]?.result?.error || 'Error en Buscar' }; }

    // Espera adaptativa: en cuanto aparece el botón de descarga, seguimos (en paralelo)
    setItemState(i, 'active', '⏳', 'Esperando resultado…');
    const rw = await perfTime('2-esperar-grid', exec(tabId, pageWaitForDownloadButton, []));
    if (!rw?.[0]?.result?.ready) { await logAlert(tabId, i); return { ok: false, error: 'No apareció el botón de descarga (sin resultados o verificación pendiente)' }; }

    // Descarga: SOLO una a la vez (candado) → detección fiable + ritmo de descarga sin duplicar
    const lockReqAt = performance.now();
    const res = await withDownloadLock(async () => {
      perfAdd('3-espera-candado', performance.now() - lockReqAt);
      currentDownloadLabel = cufe;
      let started = false;
      let captured = null; // Uint8Array con los bytes del ZIP (Exportador)
      // El reCAPTCHA tarda 1-3s en quedar listo: reintentamos el clic aquí mismo, SIN
      // recargar (el clic es barato: timeout de captura 3s). Más intentos = el primer
      // clic suele fallar pero el 2º/3º entra, evitando la recarga de 10s por factura.
      const MAX_CLICKS = 5;
      const captureStart = performance.now();
      for (let click = 0; click < MAX_CLICKS && !started && !stopRequested; click++) {
        if (click > 0) { setItemState(i, 'active', '⏳', `Reintentando descarga ${click + 1}/${MAX_CLICKS}…`); await sleep(1200); }
        const before = dlCount;
        const cap = (EXPORT_MODE || mergePdf) ? armCapture(tabId) : null;
        const r2 = await exec(tabId, pageStep2_ClickDownload, []);
        if (!r2?.[0]?.result?.ok) { if (cap) cap.cancel(); continue; } // botón aún no listo; reintenta
        setItemState(i, 'active', '⏳', EXPORT_MODE ? 'Capturando…' : 'Descargando…');
        if (EXPORT_MODE) {
          const bytes = await cap.promise;       // bytes vía CDP (o null si no llegó)
          // Debe ser un ZIP real (magic "PK") Y contener el XML. A veces la captura
          // CDP trae un ZIP incompleto/sin XML para algunas facturas; si subimos eso,
          // el backend responde "Sin XML". Validamos aquí y, si está mal, REINTENTAMOS
          // la descarga (la siguiente captura suele traer el ZIP completo).
          const okMagic = bytes && bytes.length > 4 && bytes[0] === 0x50 && bytes[1] === 0x4b;
          const hasXml = okMagic && await zipHasXml(bytes);
          if (hasXml) {
            captured = bytes; started = true;
          } else {
            captured = null;
            // Opción B: sondear el estado de verificación/captcha en este clic fallido
            // (ANTES de limpiar la alerta más abajo, para verla). Solo lectura.
            await captchaDiag(tabId);
            if (bytes) {
              // Diagnóstico: si el ZIP abre pero NO trae XML, registrar sus entradas
              // (caso raro; ayuda a ver qué devolvió la DIAN en la captura).
              if (okMagic) { try { const z = await JSZip.loadAsync(bytes); console.warn('[ContaGO] ZIP sin XML para', cufe, '— entradas:', Object.keys(z.files), 'bytes:', bytes.length); } catch (_) {} }
              setItemState(i, 'active', '⏳', okMagic ? 'ZIP sin XML — reintentando…' : 'Captura incompleta — reintentando…'); await sleep(1200);
            }
          }
        } else {
          for (let t = 0; t < 6000; t += 300) { await sleep(300); if (dlCount > before) { started = true; break; } }
          // Masiva con "unir PDF": tomar los bytes capturados de esta descarga.
          if (mergePdf && cap) {
            if (started) { const b = await cap.promise; if (b && b.length > 4 && b[0] === 0x50 && b[1] === 0x4b) captured = b; }
            else cap.cancel();
          }
        }
        await readLastAlert(tabId); // limpiar cualquier alerta de "verificación no terminada"
      }
      perfAdd('4-captura-zip', performance.now() - captureStart);
      // Fallo de captura: NO recargar la página (eso costaba ~10s por factura). Se
      // marca retryInPlace para que processCufe re-busque el mismo CUFE sin recargar.
      if (!started) return { ok: false, retryInPlace: true, error: EXPORT_MODE ? 'No se capturó el ZIP (captcha aún inválido)' : 'No inició la descarga (captcha aún inválido)' };
      // Captura exitosa → cuenta para la salud de la pestaña y corta la racha de fallos.
      tabDownloadCount.set(tabId, (tabDownloadCount.get(tabId) || 0) + 1);
      consecutiveFails = 0;

      // ── Descarga Masiva: el ZIP quedó en disco (todo dentro del candado) ──
      if (!EXPORT_MODE) {
        if (mergePdf && captured) {
          const pdf = await extractPdfFromZipBytes(captured);
          if (pdf) pdfParts.push({ i, bytes: pdf });
        }
        okCount++;
        document.getElementById('statOk').textContent = okCount;
        setItemState(i, 'done', '✅', 'Descargada');
        setLog(`Factura ${okCount}/${cufes.length} descargada.`, 'ok');
        await applyPacing();
        return { ok: true };
      }

      // ── Exportador: captura lista. Mantiene la pausa de ritmo DENTRO del candado
      // (descargas ≥1s aparte) y devuelve los bytes; la subida al backend ocurre FUERA
      // del candado para que otra pestaña capture mientras esta sube (más throughput).
      setItemState(i, 'active', '☁️', 'Subiendo a ContaGO…');
      await perfTime('5-pausa-ritmo', applyPacing());
      return { ok: true, captured };
    });

    // Fallo de captura o Descarga Masiva ya resuelta dentro del candado.
    if (!res.ok || !EXPORT_MODE) { await logAlert(tabId, i); return res; }

    // ── Exportador: subir los bytes al backend (Drive + Excel), FUERA del candado ──
    let up;
    try { up = await perfTime('6-subir-backend', ContaGO.uploadZip(currentJob.jobId, cufe, res.captured, '', recordMap.get(cufe) || '')); }
    catch (e) { await logAlert(tabId, i); return { ok: false, retryInPlace: true, error: 'No se pudo subir a ContaGO: ' + (e.message || e) }; }
    if (up.httpStatus === 403 || up.code === 'NIT_FORBIDDEN') {
      fatalReason = up.detalle || 'El NIT del listado no está autorizado en tu cuenta. Contacta al administrador.';
      stopRequested = true;
      setItemState(i, 'error', '🚫', 'NIT no autorizado');
      setLog('🚫 ' + fatalReason, 'err');
      await logAlert(tabId, i);
      return { ok: false, error: fatalReason };
    }
    if (up.httpStatus === 200) {
      okCount = (typeof up.ok === 'number') ? up.ok : okCount + 1;
      document.getElementById('statOk').textContent = okCount;
      setItemState(i, 'done', '✅', 'En ContaGO');
      setLog(`Factura ${okCount}/${cufes.length} procesada en ContaGO.`, 'ok');
      await logAlert(tabId, i);
      return { ok: true };
    }
    // 422/500: el backend rechazó (p. ej. "Sin XML"). Fallo REINTENTABLE: nunca se
    // descarta una factura. Re-capturamos y re-subimos en una próxima ronda.
    setItemState(i, 'active', '🔁', `El backend la rechazó (${up.httpStatus}) — se reintentará`);
    setLog(`[#${i + 1}] ${up.detalle || ('Backend status ' + up.httpStatus)} — reintentando.`, 'warn');
    await logAlert(tabId, i);
    return { ok: false, retryInPlace: true, error: up.detalle || ('Backend status ' + up.httpStatus) };
  }

  // Procesa un CUFE completo. finalPass=false → si falla va a la cola para el reintento
  // del final; finalPass=true → tras fallar el reintento final, se APARCA como "Pendiente"
  // (resumible) en vez de descartarse. El motor de reintentos (re-búsqueda en sitio +
  // recarga con enfriamiento) es el mismo probado: la recarga da tiempo a que el reCAPTCHA
  // quede resuelto, sin eso no se descarga nada.
  async function processCufe(tabId, i, finalPass) {
    if (itemDone[i] || parkedSet.has(i)) return;
    const cufe = cufes[i];
    scrollToItem(i);
    let attempt = 0;       // reintentos "pesados" (con recarga de página)
    let inPlace = 0;       // reintentos "ligeros" (re-buscar sin recargar)
    const MAX_INPLACE = 2; // re-buscar en sitio hasta 2 veces antes de recargar
    while (!stopRequested && !reauthRequested) {
      let res;
      try { res = await searchAndDownload(tabId, i, cufe); }
      catch (err) { res = { ok: false, error: 'Error de extensión: ' + err.message }; }

      if (res.ok) { itemDone[i] = true; persistRunNow(); return; }

      // ¿Token vencido? → disparar re-login y dejar esta factura pendiente
      if (!reauthRequested && await detectExpiry(tabId)) {
        reauthRequested = true;
        setItemState(i, 'paused', '🔑', 'Pausada (token vencido)');
        return;
      }

      // Fallo de captura → re-buscar el MISMO CUFE sin recargar (barato, ~2s), que
      // refresca el captcha. Solo si esto falla varias veces caemos a recarga.
      if (res.retryInPlace && inPlace < MAX_INPLACE && !stopRequested && !reauthRequested) {
        inPlace++;
        setItemState(i, 'active', '🔁', `Reintentando sin recargar (${inPlace}/${MAX_INPLACE})…`);
        continue;
      }

      attempt++;
      if (attempt <= MAX_AUTO_RETRIES && !stopRequested && !reauthRequested) {
        const cool = attempt === 1 ? 0 : 5; // 1er fallo recarga inmediata; 2º enfría 5s
        if (cool > 0) {
          setItemState(i, 'active', '🔄', `Reintento ${attempt}/${MAX_AUTO_RETRIES} — enfriando ${cool}s`);
          setLog(`[#${i + 1}] ${res.error} — esperando ${cool}s…`, 'warn');
          await countdownWait(cool, 'reintento');
          if (stopRequested || reauthRequested) return;
        } else {
          setLog(`[#${i + 1}] ${res.error} — recargando y reintentando…`, 'warn');
        }
        setItemState(i, 'active', '🔄', `Recargando y reintentando (${attempt}/${MAX_AUTO_RETRIES})…`);
        await reloadAndWait(tabId);
        inPlace = 0; // tras recargar, vuelve a permitir reintentos en sitio
      } else if (!finalPass) {
        if (!deferredSet.has(i)) { deferred.push(i); deferredSet.add(i); }
        persistRunNow();
        setItemState(i, 'paused', '🕓', 'En cola (reintento al final)');
        setLog(`[#${i + 1}] ${res.error} — en cola para reintentar al final.`, 'warn');
        // Racha de fallos → programar un enfriamiento para que la DIAN se recupere.
        consecutiveFails++;
        if (consecutiveFails >= FAIL_COOLDOWN_AT && cooldownUntil < Date.now()) {
          consecutiveFails = 0;
          cooldownUntil = Date.now() + COOLDOWN_SEC * 1000;
          setLog(`⏸️ Muchos fallos seguidos — enfriando ${COOLDOWN_SEC}s para que la DIAN se recupere…`, 'warn');
        }
        return;
      } else {
        // Reintento final también falló → APARCAR como Pendiente (resumible), no descartar.
        parkedSet.add(i);
        deferredSet.delete(i);
        setItemState(i, 'paused', '⏸️', 'Pendiente — no se pudo (reintenta con Reanudar)');
        setLog(`[#${i + 1}] ${res.error} — quedó pendiente tras el reintento final.`, 'warn');
        persistRunNow();
        return;
      }
    }
  }

  // Recorre una lista de índices con todos los workers (cola compartida)
  async function runQueue(indexList, finalPass) {
    let qi = 0;
    const worker = async (tabId) => {
      while (!stopRequested && !reauthRequested) {
        const k = qi;
        if (k >= indexList.length) break;
        qi++;
        await processCufe(tabId, indexList[k], finalPass);
        updateProgress(okCount + errCount);
      }
    };
    await Promise.all(tabs.map(t => worker(t.id)));
  }

  // Ejecuta una cola; si el token vence a mitad, re-autentica y continúa donde quedó
  async function runQueueResilient(indexList, finalPass) {
    let remaining = indexList.slice();
    while (remaining.length && !stopRequested) {
      reauthRequested = false;
      await runQueue(remaining, finalPass);
      if (stopRequested) break;
      if (reauthRequested) {
        const ok = await doReauth();
        manualPause = false;   // ya se consumió el motivo (manual vs vencido)
        if (!ok) break;
        remaining = remaining.filter(i => !itemDone[i] && !parkedSet.has(i) && (finalPass || !deferredSet.has(i)));
      } else break;
    }
  }

  // ── Preparar pestañas y arrancar ──
  if (!(await prepareTabs(tab))) {
    running = false; stopTimer();
    btn.disabled = false; btn.className = 'start'; btn.textContent = `Iniciar descarga (${cufes.length} facturas)`;
    return;
  }

  persistRunNow();  // snapshot inicial (por si se cierra el panel ya empezado)
  await runQueueResilient(cufes.map((_, idx) => idx), false); // 1ª vuelta
  // UNA pasada final sobre las que quedaron en cola (el error pudo reestablecerse).
  // Pequeño enfriamiento antes, para darle aire a la DIAN. Las que aún fallen quedan
  // aparcadas como "Pendiente" → el proceso SIEMPRE termina (no hay bucle infinito).
  if (deferred.length > 0 && !stopRequested) {
    const pend = deferred.splice(0); deferredSet = new Set();
    setLog(`Reintento final: ${pend.length} factura(s) que quedaron en cola…`, 'warn');
    await countdownWait(Math.min(COOLDOWN_SEC, 20), 'reintento');
    if (!stopRequested) await runQueueResilient(pend, true);
    else for (const i of pend) if (!itemDone[i] && !parkedSet.has(i)) { deferred.push(i); deferredSet.add(i); }
  }

  running = false;
  currentDownloadLabel = null;
  stopTimer();
  hidePause();
  if (reauthResolver) { document.getElementById('reauthBanner').style.display = 'none'; reauthResolver = null; }
  await detachDialogAutoAccept();
  for (const id of createdTabs) { try { await chrome.tabs.remove(id); } catch (_) {} } // cerrar las pestañas extra
  await setDownloadUi(true);
  document.getElementById('etaLabel').textContent = '';

  // ── Exportador: finalizar el job y descargar el Excel consolidado ──
  if (fatalReason) {
    // Corte por una causa de fondo (p. ej. NIT no autorizado): mensaje claro y
    // persistente, no se pisa con logs de captura de otras pestañas.
    setLog('🚫 Proceso detenido: ' + fatalReason, 'err');
  } else if (EXPORT_MODE && currentJob && okCount > 0) {
    try {
      setLog('Generando el Excel consolidado en ContaGO…', 'ok');
      await ContaGO.finalizeJob(currentJob.jobId);
      const { url, filename } = await ContaGO.fetchResultExcel(currentJob.jobId);
      pendingExcelName = filename;            // lo fija onDeterminingFilename
      await chrome.downloads.download({ url, filename, saveAs: false });
      setTimeout(() => { try { URL.revokeObjectURL(url); } catch (_) {} }, 60000);
      const driveTxt = currentJob.driveFolderUrl ? ' · facturas subidas a Google Drive' : '';
      const pend = Math.max(0, cufes.length - okCount);
      const pendTxt = pend ? ` · ${pend} pendiente(s) — pulsa "Reanudar" para reintentarlas` : '';
      setLog(`✅ Listo: ${okCount}/${cufes.length} facturas en "${filename}"${driveTxt}${pendTxt}.`, pend ? 'warn' : 'ok');
    } catch (e) {
      setLog('Las facturas se procesaron, pero falló la generación/descarga del Excel: ' + (e.message || e), 'err');
    }
  } else if (EXPORT_MODE) {
    const pend = Math.max(0, cufes.length - okCount);
    if (!stopRequested) setLog(`Terminó sin facturas logradas${pend ? ` · ${pend} pendiente(s) — pulsa "Reanudar" para reintentarlas` : ''}.`, 'err');
  } else if (okCount > 0) {
    setLog(`✅ Listo: ${okCount} facturas en Descargas/${downloadFolder || 'FacturasDIAN'}${errCount ? ` · ${errCount} fallaron tras la cola` : ''}.`, errCount ? 'warn' : 'ok');
  } else if (!stopRequested) {
    setLog(`Terminó sin descargas (${errCount} fallidas).`, 'err');
  }

  // ── Masiva: unir todos los PDF capturados en uno y descargarlo ──
  if (mergePdf && pdfParts.length) {
    try { await buildAndDownloadMergedPdf(); }
    catch (e) { setLog('No se pudo generar el PDF unificado: ' + (e.message || e), 'err'); }
  }

  // Volcar el reporte de rendimiento a la consola para diagnóstico (también con el botón 📋).
  if (PERF.size) console.log('[PERF] Fin del proceso\n' + perfReport());

  // Fin del proceso. Si quedaron facturas pendientes/aparcadas (Exportador, sin causa
  // fatal), CONSERVAMOS el snapshot para poder reanudar solo esas y mostramos el banner
  // de Reanudar de una vez. Si todo quedó resuelto, se limpia.
  isResuming = false;
  const hasPending = EXPORT_MODE && !fatalReason && (cufes.length - okCount) > 0;
  if (hasPending) {
    await offerResumeIfAny();
  } else {
    clearRun();
  }

  document.getElementById('pauseTokenBtn').style.display = 'none';
  btn.disabled = false;
  btn.className = 'done';
  btn.textContent = 'Completado — reiniciar';
  btn.addEventListener('click', () => location.reload(), { once: true });
});

// Espera a que una pestaña termine de cargar y esté ya en el dominio de la DIAN
async function waitTabLoaded(tabId, timeoutMs = 30000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    if (stopRequested) return false;
    try {
      const t = await chrome.tabs.get(tabId);
      if (t.status === 'complete' && /catalogo-vpfe\.dian\.gov\.co/i.test(t.url || '')) return true;
    } catch (_) {}
    await sleep(400);
  }
  return false;
}

// Abre/renavega al enlace de acceso. El primer acceso a veces rebota a /User/Login
// tras el challenge de Azure aunque el token sea válido (la cookie de Azure aún no
// estaba lista). Pero ese primer intento YA autentica la sesión, así que al reabrir
// el token entra. Reintentamos con paciencia antes de darlo por inválido.
async function accessWithLink(link, maxAttempts = 6) {
  let tabId = null;
  const onLogin = (u) => /\/user\/login|\/account\/login|\/login(\?|$)|signin|sign-in/i.test(u || '');
  // Tras abrir el token (aunque rebote a login), la SESIÓN ya queda autenticada por
  // cookie. Por eso alternamos: intentos impares reabren el TOKEN; los pares van
  // DIRECTO a la app usando la cookie ya puesta (que es lo que "destraba" el rebote).
  const DIAN_APP = 'https://catalogo-vpfe.dian.gov.co/Document/Received';
  for (let attempt = 1; attempt <= maxAttempts && !stopRequested; attempt++) {
    const target = (attempt % 2 === 1) ? link : DIAN_APP;
    try {
      if (tabId == null) { const c = await chrome.tabs.create({ url: target, active: true }); tabId = c.id; }
      else { await chrome.tabs.update(tabId, { url: target }); }
    } catch (_) {}
    await waitTabLoaded(tabId, 45000);
    await waitNotChallenge(tabId, 60000);
    await sleep(1500); // dejar asentar la redirección/sesión tras el challenge antes de evaluar
    let t = null; try { t = await chrome.tabs.get(tabId); } catch (_) {}
    const url = (t && t.url || '').toLowerCase();
    if (t && /catalogo-vpfe\.dian\.gov\.co/i.test(url) && !onLogin(url)) return { tab: t, stuckLogin: false }; // entró bien
    if (attempt < maxAttempts) {
      setLog(`El acceso rebotó al login (intento ${attempt}/${maxAttempts}); reintentando…`, 'warn');
      await sleep(2500); // dar tiempo a que la cookie de Azure quede lista
    }
  }
  let t = null; try { t = await chrome.tabs.get(tabId); } catch (_) {}
  return { tab: t, stuckLogin: true };
}

// Espera a que una pestaña esté lista para buscar (sin recargarla), aguardando el challenge de Azure
async function waitTabReady(tabId, timeoutMs = 45000) {
  const start = Date.now();
  let lastLog = 0;
  while (Date.now() - start < timeoutMs) {
    if (stopRequested) return false;
    let st = 'loading';
    try {
      const r = await chrome.scripting.executeScript({ target: { tabId }, func: pageStatus });
      st = r?.[0]?.result || 'loading';
    } catch (_) {}
    if (st === 'ready') return true;
    if (st === 'challenge' && Date.now() - lastLog > 2500) { setLog('⏳ Esperando la verificación de Azure…', 'warn'); lastLog = Date.now(); }
    await sleep(400);
  }
  return false;
}

// Espera a que la pestaña deje de estar en la verificación de Azure (para no navegar en medio del challenge)
async function waitNotChallenge(tabId, timeoutMs = 45000) {
  const start = Date.now();
  let lastLog = 0;
  while (Date.now() - start < timeoutMs) {
    if (stopRequested) return false;
    let st = 'loading';
    try {
      const r = await chrome.scripting.executeScript({ target: { tabId }, func: pageStatus });
      st = r?.[0]?.result || 'loading';
    } catch (_) {}
    if (st !== 'challenge') return true;
    if (Date.now() - lastLog > 2500) { setLog('⏳ Esperando la verificación de Azure…', 'warn'); lastLog = Date.now(); }
    await sleep(400);
  }
  return false;
}

// Mostrar/ocultar la barra/burbuja de descargas del navegador
async function setDownloadUi(enabled) {
  try { await chrome.downloads.setUiOptions({ enabled }); return; } catch (_) {}
  try { await chrome.downloads.setShelfEnabled(enabled); } catch (_) {}
}

// ── Página: Paso 1 — llenar y buscar (espera a que la página esté lista) ───────
// Aplica el rango de fechas del lote en la página DIAN, una sola vez por carga de página
// (se resetea al recargar). Best-effort: si no encuentra el control de fechas, sigue sin
// fijarlo (no rompe el flujo que ya funciona para fechas recientes).
async function ensureDateRange(tabId, i) {
  if (!queryRange.from || !queryRange.to) return;       // sin rango conocido → nada que hacer
  if (dateRangeReady.has(tabId)) return;                // ya aplicado/agotado en esta carga
  try {
    if (typeof i === 'number') setItemState(i, 'active', '📅', 'Fijando rango de fechas…');
    const r = await chrome.scripting.executeScript({
      target: { tabId }, world: 'MAIN', func: pageSetDateRange, args: [queryRange.from, queryRange.to],
    });
    const out = r?.[0]?.result || {};
    rangeLog(tabId, out);
    if (out.ok) {
      dateRangeReady.add(tabId);                        // logrado → no repetir esta carga
      setLog(`Rango de fechas aplicado en la DIAN (${out.method}).`, 'ok');
      await sleep(900);                                 // dar tiempo a que la grilla refiltre
    } else {
      const n = (dateRangeAttempts.get(tabId) || 0) + 1;
      dateRangeAttempts.set(tabId, n);
      if (n >= 3) {
        dateRangeReady.add(tabId);                      // tras 3 fallos, no seguir pagando 4s c/CUFE
        setLog(`Rango de fechas no disponible en esta pestaña (${out.reason || 'control no hallado'}).`, 'warn');
      } else {
        setLog(`Rango pendiente (${out.reason || 'control no hallado'}). Reintentando en próxima factura…`, 'warn');
      }
    }
  } catch (_) { /* best-effort: continuar */ }
}

// Se inyecta en el mundo MAIN (acceso a jQuery/daterangepicker de la DIAN). Async: espera
// hasta 4s a que el daterangepicker esté inicializado (DIAN carga jQuery y el plugin de forma
// diferida). El recuadro de la DIAN muestra "YYYY/MM/DD - YYYY/MM/DD". Nunca lanza.
async function pageSetDateRange(fromISO, toISO) {
  const out = { ok: false, reason: '', diag: '', method: '' };
  try {
    const fSlash = fromISO.replace(/-/g, '/');
    const tSlash = toISO.replace(/-/g, '/');
    const rangeStr = `${fSlash} - ${tSlash}`;
    const wait = ms => new Promise(r => setTimeout(r, ms));
    const fire = (el, types) => types.forEach(t => { try { el.dispatchEvent(new Event(t, { bubbles: true })); } catch (_) {} });
    const setNativeVal = (el, v) => {
      try { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(el, v); }
      catch (_) { el.value = v; }
      fire(el, ['input', 'change', 'keyup', 'blur']);
      try { el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'Enter', keyCode: 13, which: 13 })); } catch (_) {}
    };

    // ── Estrategia 1: API daterangepicker (jQuery) — espera hasta 4s a que inicialice ──
    let drp = null, $el = null;
    for (let t = 0; t < 20; t++) {
      const $ = window.jQuery || window.$;
      if ($) {
        const tryFind = (sel) => { try { $(sel).each(function () { const d = $(this).data && $(this).data('daterangepicker'); if (d) { drp = d; $el = $(this); return false; } }); } catch (_) {} };
        tryFind('input, .form-control, [class*="date"], [class*="Date"], [class*="range"], [class*="Range"]');
        if (!drp) tryFind('*');
      }
      if (drp) break;
      await wait(200);
    }
    if (drp && $el) {
      const $ = window.jQuery || window.$;
      try {
        const start = window.moment ? window.moment(fromISO, 'YYYY-MM-DD') : new Date(fromISO + 'T00:00:00');
        const end = window.moment ? window.moment(toISO, 'YYYY-MM-DD').endOf('day') : new Date(toISO + 'T23:59:59');
        drp.setStartDate(start); drp.setEndDate(end);
        if (typeof drp.callback === 'function') { try { drp.callback(start, end, drp.chosenLabel); } catch (_) {} }
        try { $el.trigger('apply.daterangepicker', drp); } catch (_) {}
        const ab = document.querySelector('.daterangepicker .applyBtn, .daterangepicker button.applyBtn');
        if (ab) { try { ab.click(); } catch (_) {} }
        out.ok = true; out.method = 'api'; return out;
      } catch (_) { /* sigue a estrategia 2 */ }
    }

    // ── Estrategia 2: input de texto que muestra el rango → escribir el valor ──
    const inputs = [...document.querySelectorAll('input')];
    const rangeRe = /\d{2,4}[\/\-]\d{1,2}[\/\-]\d{1,4}\s*-\s*\d{2,4}[\/\-]\d{1,2}[\/\-]\d{1,4}/;
    const labelRe = /fecha|rango|date|range/i;
    let target = inputs.find(el => rangeRe.test(el.value || ''))
      || inputs.find(el => labelRe.test(`${el.placeholder || ''} ${el.name || ''} ${el.id || ''} ${el.getAttribute('aria-label') || ''}`));
    if (target) {
      setNativeVal(target, rangeStr);
      const ab = document.querySelector('.daterangepicker .applyBtn, .daterangepicker button.applyBtn');
      if (ab) { try { ab.click(); } catch (_) {} }
      out.ok = true; out.method = 'input'; return out;
    }

    // ── Falla: reportar candidatos (primeros inputs visibles) para afinar el selector ──
    const desc = (el) => {
      const cls = (typeof el.className === 'string' ? el.className : '').split(/\s+/).filter(Boolean).slice(0, 2).join('.');
      return `${el.tagName}${el.id ? '#' + el.id : ''}${cls ? '.' + cls : ''}{${(el.value || el.placeholder || '').slice(0, 22)}}`;
    };
    const $ = window.jQuery || window.$;
    out.reason = $ ? 'control de fechas no hallado' : 'sin jQuery';
    out.diag = inputs.filter(el => el.offsetParent !== null).slice(0, 8).map(desc).join(' ');
    return out;
  } catch (e) { out.reason = String((e && e.message) || e); return out; }
}

async function pageStep1_FillAndSearch(cufe) {
  const wait = (ms) => new Promise(r => setTimeout(r, ms));

  // Busca el campo "Código único" de forma amplia
  const findInput = () =>
    [...document.querySelectorAll('input')].find(i => {
      const ph = (i.placeholder || i.getAttribute('aria-label') || i.name || i.id || '').toLowerCase();
      return ph.includes('digo') || ph.includes('nico') || ph.includes('cufe') || ph.includes('cude') || ph.includes('unico');
    }) || document.querySelector('input[type="text"]:not([type="hidden"])') || document.querySelector('input:not([type="hidden"])');

  // Busca el botón "Buscar" de forma amplia: texto, value, clases e ícono de lupa
  const findBuscar = () => {
    const cands = [...document.querySelectorAll('button, input[type="submit"], input[type="button"], a, [role="button"]')];
    const visible = (el) => el && (el.offsetParent !== null || el.getClientRects().length > 0);
    const byText = cands.find(el => {
      const t = (el.textContent || el.value || '').replace(/\s+/g, ' ').trim().toLowerCase();
      return visible(el) && (t === 'buscar' || t.includes('buscar') || t.includes('consultar'));
    });
    return byText
      || document.querySelector('button.btn-radian-success, .btn-radian-success')
      || document.querySelector('button.btn-success:not(.applyBtn)')
      || cands.find(el => visible(el) && el.querySelector && el.querySelector('i.fa-search, .fa-search'));
  };

  // Espera hasta ~10 s a que la página (React) termine de pintar campo + botón
  let inp = null, buscar = null;
  for (let t = 0; t < 10000; t += 250) {
    inp = findInput();
    buscar = findBuscar();
    if (inp && buscar) break;
    await wait(250);
  }

  if (!inp) return { ok: false, error: 'Campo "Código único" no encontrado tras esperar — ¿estás en la página correcta (Document/Received)?' };
  if (!buscar) return { ok: false, error: 'Botón "Buscar" no apareció tras esperar 10s — recargando…' };

  const setVal = (el, v) => {
    try {
      const s = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
      s.call(el, v);
    } catch (_) { el.value = v; }
    el.dispatchEvent(new Event('input',  { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  };

  inp.focus();
  setVal(inp, '');
  setVal(inp, cufe);

  await wait(150); // dar un instante a React para registrar el valor antes de buscar
  buscar.click();
  return { ok: true };
}

// ── Página: esperar (adaptativo) a que aparezca el botón de descarga ───────────
async function pageWaitForDownloadButton() {
  const wait = (ms) => new Promise(r => setTimeout(r, ms));
  for (let t = 0; t < 9000; t += 250) {
    if (document.querySelector('button.download-document')) return { ready: true };
    await wait(250);
  }
  return { ready: false };
}

// ── Página: Paso 2 — clic en el botón de descarga (síncrono) ──────────────────
function pageStep2_ClickDownload() {
  const btn = document.querySelector('button.download-document');
  if (!btn) return { ok: false, error: 'Botón de descarga no encontrado — el resultado no cargó o el CUFE no existe' };
  btn.click();
  return { ok: true };
}

// ── Recargar la página DIAN y esperar a que esté lista para buscar ────────────
async function reloadAndWait(tabId, timeoutMs = 30000) {
  dateRangeReady.delete(tabId); dateRangeAttempts.delete(tabId); // recarga resetea el filtro → reaplicar
  try { await chrome.tabs.reload(tabId); } catch (_) {}
  const start = Date.now();
  await sleep(500); // margen mínimo para que arranque la recarga
  let lastLog = 0;
  while (Date.now() - start < timeoutMs) {
    if (stopRequested) return false;
    let st = 'loading';
    try {
      const r = await chrome.scripting.executeScript({ target: { tabId }, func: pageStatus });
      st = r?.[0]?.result || 'loading';
    } catch (_) { /* la pestaña puede estar navegando aún */ }
    if (st === 'ready') {
      await installAlertAutoAccept(tabId);  // reinstalar override de alertas
      await enableFetchCapture(tabId);       // CLAVE: re-habilitar captura CDP tras la recarga
      return true;
    }
    if (st === 'challenge' && Date.now() - lastLog > 2500) { setLog('⏳ Esperando la verificación de Azure…', 'warn'); lastLog = Date.now(); }
    await sleep(250); // sondeo frecuente: seguir apenas la página esté lista
  }
  return false;
}

// ── Auto-aceptar diálogos nativos ya abiertos vía chrome.debugger (CDP) ───────
// Es la única forma de cerrar un alert/confirm que YA apareció (la página queda
// congelada y el override de window.alert no alcanza a ejecutarse).
const debuggerTabs = new Set();

// Si el usuario cierra el aviso "está depurando este navegador" (o se cae la
// conexión del debugger), la captura deja de funcionar y todo falla con "captcha
// inválido". Mientras hay una corrida activa, reconectamos automáticamente.
chrome.debugger.onDetach.addListener(async (source, reason) => {
  const tabId = source.tabId;
  if (!debuggerTabs.has(tabId)) return;
  debuggerTabs.delete(tabId);
  if (!running || stopRequested || reason === 'target_closed') return;
  setLog('⚠️ Se cerró el aviso de depuración (la captura lo necesita). Reconectando…', 'warn');
  await sleep(400);
  if (!running || stopRequested) return;
  try { await attachDialogAutoAccept(tabId); } catch (_) {}
});

function onDebuggerEvent(source, method, params) {
  const tabId = source.tabId;
  if (!debuggerTabs.has(tabId)) return;

  if (method === 'Page.javascriptDialogOpening') {
    const msg = (params && params.message) || '';
    // Aceptar el diálogo automáticamente
    chrome.debugger.sendCommand({ tabId }, 'Page.handleJavaScriptDialog', { accept: true }).catch(() => {});
    setLog(`Alerta del navegador aceptada automáticamente: "${String(msg).slice(0, 80)}"`, 'warn');
    return;
  }

  // Exportador: capturar los bytes del ZIP en stage Response (método verificado
  // por la sonda: Fetch.getResponseBody) y abortar la bajada a disco.
  if (method === 'Fetch.requestPaused') {
    const reqId = params.requestId;
    const url = (params.request && params.request.url) || '';
    if (/DownloadZipFiles/i.test(url)) {
      // La petición llegó: ampliar el margen para leer el cuerpo (conexiones lentas).
      pendingCaptures.get(tabId)?.markStarted?.();
      (async () => {
        let bytes = null;
        try {
          const body = await chrome.debugger.sendCommand({ tabId }, 'Fetch.getResponseBody', { requestId: reqId });
          if (body && typeof body.body === 'string') {
            const bin = body.base64Encoded ? atob(body.body) : body.body;
            const arr = new Uint8Array(bin.length);
            for (let k = 0; k < bin.length; k++) arr[k] = bin.charCodeAt(k);
            bytes = arr;
          }
        } catch (_) {}
        // Exportador: ABORTAR (no escribir a disco ni diálogo "Guardar como").
        // Masiva con "unir PDF": CONTINUAR (el ZIP debe seguir bajando a disco).
        if (EXPORT_MODE) {
          try { await chrome.debugger.sendCommand({ tabId }, 'Fetch.failRequest', { requestId: reqId, errorReason: 'Aborted' }); }
          catch (_) { try { await chrome.debugger.sendCommand({ tabId }, 'Fetch.continueRequest', { requestId: reqId }); } catch (_) {} }
        } else {
          try { await chrome.debugger.sendCommand({ tabId }, 'Fetch.continueRequest', { requestId: reqId }); } catch (_) {}
        }
        const cap = pendingCaptures.get(tabId);
        if (cap) cap.resolve(bytes);
      })();
    } else {
      chrome.debugger.sendCommand({ tabId }, 'Fetch.continueRequest', { requestId: reqId }).catch(() => {});
    }
  }
}

// (Re)habilita la captura CDP de DownloadZipFiles en una pestaña. Debe llamarse
// al adjuntar y DESPUÉS DE CADA RECARGA: si no, tras recargar el dominio Fetch
// puede dejar de interceptar y todas las descargas de esa pestaña agotan timeout.
async function enableFetchCapture(tabId) {
  if (!(EXPORT_MODE || mergePdf)) return;
  try {
    await chrome.debugger.sendCommand({ tabId }, 'Fetch.enable', {
      patterns: [{ urlPattern: '*DownloadZipFiles*', requestStage: 'Response' }],
    });
  } catch (_) {}
}

// Arma una captura para la próxima descarga de esa pestaña (Exportador).
// Dos fases: si en `firstByteMs` no llega ninguna petición DownloadZipFiles, falla
// rápido (no se disparó la descarga). Pero en cuanto la petición SÍ llega
// (markStarted), se da un margen largo `bodyMs` para leer el cuerpo completo del
// ZIP — clave para conexiones lentas / ZIP grandes (antes 6s fijos se quedaban
// cortos y daban "captcha aún inválido" en falso).
function armCapture(tabId, firstByteMs = 3000, bodyMs = 45000) {
  const prev = pendingCaptures.get(tabId);
  if (prev) prev.resolve(null); // descarta una captura anterior sin resolver
  let resolveFn, timer;
  const promise = new Promise((res) => { resolveFn = res; });
  const settle = (bytes) => { clearTimeout(timer); pendingCaptures.delete(tabId); resolveFn(bytes); };
  timer = setTimeout(() => settle(null), firstByteMs);
  const markStarted = () => { clearTimeout(timer); timer = setTimeout(() => settle(null), bodyMs); };
  pendingCaptures.set(tabId, { resolve: settle, markStarted });
  return { promise, cancel: () => settle(null) };
}

async function attachDialogAutoAccept(tabId) {
  try {
    await chrome.debugger.attach({ tabId }, '1.3');
  } catch (e) {
    // Quizá quedó adjunto de una corrida anterior: soltar y reintentar una vez
    try { await chrome.debugger.detach({ tabId }); await chrome.debugger.attach({ tabId }, '1.3'); }
    catch (e2) {
      setLog('No se pudo activar el auto-aceptar de alertas a nivel navegador (¿DevTools abierto?). Se usa el respaldo.', 'warn');
      return false;
    }
  }
  try {
    await chrome.debugger.sendCommand({ tabId }, 'Page.enable');
    debuggerTabs.add(tabId);
    if (!chrome.debugger.onEvent.hasListener(onDebuggerEvent)) chrome.debugger.onEvent.addListener(onDebuggerEvent);
    // Interceptar la respuesta de DownloadZipFiles para leer los bytes:
    // Exportador (subir al backend) o Masiva con "unir PDF".
    await enableFetchCapture(tabId);
    return true;
  } catch (_) { return false; }
}

async function detachDialogAutoAccept() {
  for (const id of [...debuggerTabs]) {
    debuggerTabs.delete(id);
    try { await chrome.debugger.detach({ tabId: id }); } catch (_) {}
  }
}

// Si el panel/pestaña se cierra a media corrida, soltar el debugger para no dejar el aviso pegado
window.addEventListener('beforeunload', () => {
  for (const id of debuggerTabs) { try { chrome.debugger.detach({ tabId: id }); } catch (_) {} }
});

// ── Aceptar automáticamente alert/confirm/prompt de la página (respaldo JS) ────
// Se inyecta en el "mundo real" (MAIN) de la página, porque los alert nativos
// solo se pueden sustituir desde ahí, no desde el mundo aislado de la extensión.
async function installAlertAutoAccept(tabId) {
  try {
    await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: pageInstallAlertAutoAccept });
  } catch (_) {}
}
function pageInstallAlertAutoAccept() {
  if (window.__alertAutoAccept) return;
  window.__alertAutoAccept = true;
  window.alert = function (m) { try { localStorage.setItem('__lastAlert', String(m == null ? '' : m)); } catch (_) {} };
  window.confirm = function (m) { try { localStorage.setItem('__lastAlert', String(m == null ? '' : m)); } catch (_) {} return true; };
  window.prompt = function (m, d) { return d == null ? '' : d; };
}

// Lee y limpia el último alert que la página intentó mostrar (mundo aislado, mismo localStorage)
async function readLastAlert(tabId) {
  try {
    const r = await chrome.scripting.executeScript({
      target: { tabId },
      func: () => { const m = localStorage.getItem('__lastAlert'); localStorage.removeItem('__lastAlert'); return m; }
    });
    return r?.[0]?.result || '';
  } catch (_) { return ''; }
}

// Se ejecuta en la página: ¿ya cargó el campo de búsqueda y el botón Buscar?
function pageIsReadyToSearch() {
  if (document.readyState !== 'complete') return false;
  const hasInput = [...document.querySelectorAll('input')].some(i => {
    const ph = (i.placeholder || i.getAttribute('aria-label') || i.name || i.id || '').toLowerCase();
    return ph.includes('digo') || ph.includes('nico') || ph.includes('cufe') || ph.includes('cude') || ph.includes('unico');
  });
  const hasBtn =
    [...document.querySelectorAll('button, input[type="submit"], input[type="button"], a, [role="button"]')].some(el => {
      const t = (el.textContent || el.value || '').replace(/\s+/g, ' ').trim().toLowerCase();
      return t === 'buscar' || t.includes('buscar') || t.includes('consultar');
    }) ||
    !!document.querySelector('button.btn-radian-success, .btn-radian-success');
  return hasInput && hasBtn;
}

// Estado de la página: 'ready' (formulario listo) | 'challenge' (verificación Azure/WAF) | 'loading'
function pageStatus() {
  const title = (document.title || '').toLowerCase();
  const body = (document.body ? document.body.innerText || '' : '').slice(0, 2500).toLowerCase();
  const txt = title + ' ' + body;
  const looksChallenge =
    /verif|verify|checking your browser|just a moment|un momento|comprobando|validando|are human|human verification|web application firewall|firewall|ddos|cargando la verificaci/i.test(txt);
  // Las pantallas de verificación no tienen el formulario de la app
  const hasAppInput = [...document.querySelectorAll('input')].some(i => {
    const ph = (i.placeholder || i.getAttribute('aria-label') || i.name || i.id || '').toLowerCase();
    return ph.includes('digo') || ph.includes('nico') || ph.includes('cufe') || ph.includes('cude') || ph.includes('unico');
  });
  if (looksChallenge && !hasAppInput) return 'challenge';

  const hasBtn =
    [...document.querySelectorAll('button, input[type="submit"], input[type="button"], a, [role="button"]')].some(el => {
      const t = (el.textContent || el.value || '').replace(/\s+/g, ' ').trim().toLowerCase();
      return t === 'buscar' || t.includes('buscar') || t.includes('consultar');
    }) ||
    !!document.querySelector('button.btn-radian-success, .btn-radian-success');
  if (hasAppInput && hasBtn && document.readyState === 'complete') return 'ready';

  // Login / sesión vencida (token expirado): texto típico o URL de autenticación, sin el formulario de la app
  const url = (location.href || '').toLowerCase();
  const looksLogin =
    /\/user\/login|\/account\/login|\/login|\/auth|signin|sign-in/.test(url) ||
    /sesi[oó]n (ha )?(expir|vencid|caduc)|token (expir|vencid|inv[aá]lid|caduc)|vuelva? a iniciar sesi|inicie? sesi[oó]n|iniciar sesi[oó]n|acceso denegado|no autorizado|unauthorized|debe autenticar/i.test(txt);
  if (looksLogin && !hasAppInput) return 'login';

  if (document.readyState !== 'complete') return 'loading';
  return 'loading';
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function setItemState(index, stateClass, icon, statusText) {
  const item = document.getElementById(`item-${index}`);
  if (!item) return;
  item.className = `list-item s-${stateClass}`;
  document.getElementById(`icon-${index}`).textContent = icon;
  document.getElementById(`istatus-${index}`).textContent = statusText;
}
function scrollToItem(index) {
  document.getElementById(`item-${index}`)?.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}
function updateProgress(done) {
  document.getElementById('progressFill').style.width = `${(okCount / cufes.length) * 100}%`;
  // "Pendientes" en vivo: todo lo que aún no se ha logrado (se reintenta hasta lograrlo).
  document.getElementById('statErr').textContent = String(Math.max(0, cufes.length - okCount));
}
const _logHistory = [];
function setLog(msg, type) {
  const el = document.getElementById('logMsg');
  el.textContent = msg;
  el.className = 'log' + (type ? ' ' + type : '');
  _logHistory.push(`[${new Date().toISOString().slice(11,19)}] ${msg}`);
  const ta = document.getElementById('logHistory');
  if (ta) { ta.value = _logHistory.join('\n'); ta.scrollTop = ta.scrollHeight; }
}
function resetProgress() {
  okCount = 0; errCount = 0;
  stopTimer(); startTime = 0; accumulatedMs = 0;
  document.getElementById('statOk').textContent = '0';
  document.getElementById('statErr').textContent = '0';
  document.getElementById('progressFill').style.width = '0%';
  document.getElementById('elapsedLabel').textContent = '00:00';
  document.getElementById('rateLabel').textContent = '0.0';
}
function updateETA() {
  // ~6.5 s por factura (5 s de carga de resultados + margen de descarga)
  const mins = Math.max(1, Math.round((cufes.length * 6.5) / 60));
  document.getElementById('etaLabel').textContent = `~${mins} min estimados`;
}
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// ── Cronómetro y velocidad (facturas/min) ─────────────────────────────────────
function startTimer() {
  startTime = Date.now();
  clearInterval(timerInterval);
  timerInterval = setInterval(updateTimer, 1000);
  updateTimer();
}
function stopTimer() {
  clearInterval(timerInterval);
  timerInterval = null;
  updateTimer(); // congela el valor final
}
function updateTimer() {
  if (!startTime) return;
  const ms = elapsedTotalMs();
  const totalSec = Math.floor(ms / 1000);
  const mm = String(Math.floor(totalSec / 60)).padStart(2, '0');
  const ss = String(totalSec % 60).padStart(2, '0');
  document.getElementById('elapsedLabel').textContent = `${mm}:${ss}`;
  const mins = ms / 60000;
  const rate = mins > 0 ? okCount / mins : 0;
  document.getElementById('rateLabel').textContent = rate.toFixed(1);
}

// Espera con cuenta regresiva visible; se corta si el usuario pulsa Detener
async function countdownWait(seconds, label) {
  for (let s = seconds; s > 0; s--) {
    if (stopRequested || reauthRequested) break;
    document.getElementById('etaLabel').textContent = `${label} en ${s}s`;
    await sleep(1000);
  }
  document.getElementById('etaLabel').textContent = '';
}

// ── Modo PDF por CUFE ──────────────────────────────────────────────────────────

// Función inyectada en la página para capturar todo su estado
function pageDiagnostic() {
  const url = location.href;
  const title = document.title;

  const inputs = [...document.querySelectorAll('input, textarea, select')].map(el => ({
    tag: el.tagName,
    id: el.id || null,
    name: el.name || null,
    type: el.type || null,
    placeholder: el.placeholder || null,
    value: (el.value || '').slice(0, 60),
    visible: el.offsetParent !== null && getComputedStyle(el).display !== 'none',
    disabled: el.disabled,
  }));

  const buttons = [...document.querySelectorAll('button, input[type="submit"], input[type="button"], a[role="button"]')].map(el => ({
    tag: el.tagName,
    id: el.id || null,
    text: el.textContent.trim().slice(0, 60),
    value: (el.value || '').slice(0, 40),
    type: el.type || null,
    href: el.href ? el.href.slice(0, 80) : null,
    disabled: el.disabled,
    visible: el.offsetParent !== null && getComputedStyle(el).display !== 'none',
  }));

  const forms = [...document.querySelectorAll('form')].map(f => ({
    id: f.id || null,
    action: f.action,
    method: f.method,
    fields: [...f.querySelectorAll('input,textarea,select')].map(i => `${i.name||i.id}[${i.type}]`),
  }));

  const modals = [...document.querySelectorAll('[class*="modal"],[class*="dialog"],[role="dialog"],[class*="popup"]')]
    .filter(el => getComputedStyle(el).display !== 'none')
    .map(el => el.innerHTML.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 200));

  const bodyText = (document.body?.innerText || '').replace(/\s+/g, ' ').trim().slice(0, 1000);

  return { url, title, inputs, buttons, forms, modals, bodyText };
}

document.getElementById('saveLogBtn').addEventListener('click', () => {
  const text = _logHistory.join('\n');
  const blob = new Blob([text], { type: 'text/plain' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `contago-pdf-logs-${new Date().toISOString().slice(0,19).replace(/:/g,'-')}.txt`;
  a.click();
  URL.revokeObjectURL(url);
});

document.getElementById('copyLogBtn').addEventListener('click', () => {
  const ta = document.getElementById('logHistory');
  if (!ta) return;
  ta.select();
  document.execCommand('copy');
  document.getElementById('copyLogBtn').textContent = '✅ Copiado';
  setTimeout(() => { document.getElementById('copyLogBtn').textContent = '📋 Copiar logs'; }, 2000);
});

// ── PDF → Excel ───────────────────────────────────────────────────────────────
document.getElementById('pdfExcelBtn').addEventListener('click', () => {
  document.getElementById('pdfExcelInput').click();
});

document.getElementById('pdfExcelInput').addEventListener('change', async (e) => {
  const files = [...e.target.files];
  e.target.value = ''; // reset so same files can be re-selected
  if (!files.length) return;

  const status = document.getElementById('pdfExcelStatus');
  const btn = document.getElementById('pdfExcelBtn');
  btn.disabled = true;
  btn.textContent = `⏳ Procesando ${files.length} PDF(s)…`;
  status.textContent = '';

  try {
    const { url, filename, errors } = await ContaGO.parsePdfsToExcel(files);
    // Trigger download via pendingExcelName + blob URL
    pendingExcelName = filename;
    await chrome.downloads.download({ url, filename, saveAs: false });
    URL.revokeObjectURL(url);
    status.textContent = `✓ Excel descargado: ${filename}` + (errors ? ` · ${errors}` : '');
    status.style.color = errors ? '#e65100' : '#388e3c';
  } catch (err) {
    status.textContent = `✗ ${err.message}`;
    status.style.color = '#c62828';
  } finally {
    btn.disabled = false;
    btn.textContent = '📊 Generar Excel desde PDFs';
  }
});


// Después de cada carga, verifica si hay antibot WAF. Si lo hay, pausa y navega a SearchDocument al reanudar.
// Devuelve true si hubo antibot y el usuario eligió Skip; false si se puede continuar.
async function handleAntibotIfNeeded(tabId, cufeLabel, searchUrl) {
  const r = await injectScript(tabId, pagePdfIsAntibot);
  if (r !== true) return false;
  // WAF detectado: volver a SearchDocument y hacer poll hasta que se resuelva
  setLog(`⚠ WAF detectado — esperando resolución…`, 'warn');
  await chrome.tabs.update(tabId, { url: searchUrl });
  await waitForTabComplete(tabId, 20000).catch(() => {});
  // Poll dinámico: sale en cuanto la página deje de ser WAF (máx 15 s)
  const wafStart = Date.now();
  for (let w = 0; w < 30; w++) {
    await sleep(500);
    const still = await injectScript(tabId, pagePdfIsAntibot);
    if (still !== true) break;
  }
  // Esperar el redirect post-WAF → SearchDocument termina de cargar
  await waitForTabComplete(tabId, 8000).catch(() => {});
  setLog(`WAF: resuelto en ${((Date.now() - wafStart) / 1000).toFixed(1)}s`, 'ok');
  return false;
}

function parsePdfCufeInput() {
  const raw = document.getElementById('pdfCufeInput')?.value || '';
  return raw.split(/[\n\r,;]+/).map(s => s.trim()).filter(s => s.length > 20);
}

// Espera a que un tab termine de cargar (status = 'complete').
function waitForTabComplete(tabId, timeout = 15000) {
  return new Promise((resolve, reject) => {
    let done = false;
    const finish = (ok) => {
      if (done) return; done = true;
      chrome.tabs.onUpdated.removeListener(listener);
      clearTimeout(timer);
      ok ? resolve() : reject(new Error('tab-timeout'));
    };
    const timer = setTimeout(() => finish(false), timeout);
    const listener = (id, info) => { if (id === tabId && info.status === 'complete') finish(true); };
    chrome.tabs.onUpdated.addListener(listener);
    // Por si ya está cargada
    chrome.tabs.get(tabId).then(t => { if (t.status === 'complete') finish(true); }).catch(() => {});
  });
}

// Ejecuta una función en el contexto MAIN de un tab.
async function injectScript(tabId, fn, args) {
  try {
    const r = await chrome.scripting.executeScript({ target: { tabId }, world: 'MAIN', func: fn, args: args || [] });
    return r?.[0]?.result || {};
  } catch (_) { return {}; }
}

// Funciones inyectadas en la página del catálogo DIAN ────────────────────────

// Llena el campo CUFE y envía el formulario de búsqueda.
function pagePdfFillSearch(cufe) {
  const inp = document.querySelector('input[name="Id"]')
    || [...document.querySelectorAll('input[type="text"]')].find(el => !el.hidden && el.offsetParent !== null);
  if (!inp) return { ok: false, reason: 'no-input' };
  try {
    const setter = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value')?.set;
    if (setter) setter.call(inp, cufe); else inp.value = cufe;
    inp.dispatchEvent(new Event('input', { bubbles: true }));
    inp.dispatchEvent(new Event('change', { bubbles: true }));
  } catch (_) { inp.value = cufe; }
  const form = inp.closest('form');
  const btn = form?.querySelector('button[type="submit"],input[type="submit"],button')
    || document.querySelector('button[type="submit"],input[type="submit"]');
  if (!btn) return { ok: false, reason: 'no-btn' };
  btn.click();
  return { ok: true };
}

// Verifica si el botón "Descargar PDF" está disponible y no está deshabilitado.
// Devuelve info diagnóstica para ayudar a depurar.
// Detecta la página de verificación antibot de Azure WAF.
// Solo dispara cuando la página del challenge está activa Y los elementos normales de DIAN no están.
function pagePdfIsAntibot() {
  // Si hay un campo de búsqueda DIAN o un form de descarga, estamos en una página normal
  const hasDianContent = !!document.querySelector('input[name="Id"], form[action*="DownloadPDF"], form[action*="ShowDocument"]');
  if (hasDianContent) return false;

  const body = (document.body?.innerText || '').toLowerCase();
  const title = document.title.toLowerCase();

  // Indicadores específicos del challenge de Azure WAF / Cloudflare
  const hasChallengePage =
    (body.includes('comprobando') && body.includes('bot')) ||
    (body.includes('checking') && body.includes('bot')) ||
    body.includes('just a moment...') ||
    title === 'just a moment...' ||
    title.includes('solicitud bloqueada') ||
    !!document.querySelector('#azureWAF, #waf-block, [id*="challenge-running"]');

  return hasChallengePage;
}

// Verifica que el form DownloadPDF existe y que Turnstile ya está resuelto.
function pagePdfCheckDownload() {
  const form = document.querySelector('form[action*="DownloadPDF"]');
  if (!form) return { ready: false, reason: 'no-form', url: location.href };
  const turnstileVal = document.querySelector('[name="cf-turnstile-response"]')?.value || '';
  if (!turnstileVal) return { ready: false, reason: 'no-turnstile', url: location.href };
  return { ready: true, url: location.href };
}

// Verifica si el Turnstile de SearchDocument ya está resuelto (listo para buscar).
function pagePdfSearchReady() {
  // Mismo selector que pagePdfFillSearch
  const inp = document.querySelector('input[name="Id"]')
    || [...document.querySelectorAll('input[type="text"]')].find(el => !el.hidden && el.offsetParent !== null);
  if (!inp) return { ready: false, reason: 'no-input' };
  const turnstile = document.querySelector('[name="cf-turnstile-response"]')?.value || '';
  if (!turnstile) return { ready: false, reason: 'no-turnstile' };
  return { ready: true };
}

// Hace clic en "Confirmar" si hay un modal de confirmación visible tras la búsqueda.
function pagePdfClickConfirm() {
  const btn = [...document.querySelectorAll('button,input[type="button"],input[type="submit"]')]
    .find(b => /^confirmar$/i.test(b.textContent.trim()) || /^confirmar$/i.test((b.value || '').trim()));
  if (!btn || btn.disabled) return { found: false };
  btn.click();
  return { found: true };
}

// Copia el token Turnstile al campo captcha y envía el form.
function pagePdfClickDownload() {
  const form = document.querySelector('form[action*="DownloadPDF"]');
  if (!form) return { ok: false, reason: 'no-form' };
  const turnstileVal = document.querySelector('[name="cf-turnstile-response"]')?.value || '';
  const captchaField = form.querySelector('[name="captcha"]');
  if (captchaField) captchaField.value = turnstileVal;
  try { form.submit(); return { ok: true }; } catch (e) { return { ok: false, reason: e.message }; }
}

// ── Worker de descarga PDF (cola compartida) ──────────────────────────────────
// workQueue es un array compartido; ambos workers usan .shift() para sacar el siguiente índice.
async function runPdfWorkerLoop(tabId, workQueue, SEARCH_URL) {
  // Si tabId es null, abrir una pestaña nueva
  if (!tabId) {
    try {
      const t = await chrome.tabs.create({ url: SEARCH_URL, active: false });
      tabId = t.id;
      await waitForTabComplete(tabId, 20000);
      await sleep(3000 + Math.random() * 1500);
    } catch (e) {
      setLog(`Worker: no pudo abrir pestaña — ${e.message}`, 'err');
      return;
    }
  }

  let i;
  while ((i = workQueue.shift()) !== undefined && !stopRequested) {
    const cufe = cufes[i];
    setItemState(i, 'active', '⏳', 'Buscando…');

    let success = false;

    for (let attempt = 0; attempt < 5 && !success && !stopRequested; attempt++) {
      setLog(`CUFE ${i + 1}/${cufes.length} · intento ${attempt + 1}/5`, 'ok');

      // Asegurar que estamos en SearchDocument
      let tabUrl = '';
      try {
        const t = await chrome.tabs.get(tabId);
        tabUrl = t.url || '';
        if (!tabUrl.includes('SearchDocument')) {
          if (tabUrl.includes('/Login')) setLog(`CUFE ${i + 1}: Login detectado → SearchDocument…`, 'warn');
          await chrome.tabs.update(tabId, { url: SEARCH_URL });
          await waitForTabComplete(tabId, 15000);
          await sleep(1500);
        }
      } catch (_) {
        setLog(`CUFE ${i + 1}: pestaña cerrada, reabriendo…`, 'warn');
        const t = await chrome.tabs.create({ url: SEARCH_URL, active: false });
        tabId = t.id;
        await waitForTabComplete(tabId, 20000);
        await sleep(2000);
      }

      // Antibot check
      if (await handleAntibotIfNeeded(tabId, cufe, SEARCH_URL) === true) {
        setItemState(i, 'error', '⏭', 'Saltado'); errCount++;
        updateProgress(okCount + errCount);
        document.getElementById('statErr').textContent = String(Math.max(0, cufes.length - okCount));
        break;
      }

      // Esperar Turnstile de SearchDocument
      setLog(`CUFE ${i + 1}: esperando Turnstile…`, 'ok');
      let searchReady = false;
      for (let w = 0; w < 24 && !stopRequested; w++) {
        const r = await injectScript(tabId, pagePdfSearchReady);
        if (r?.ready) { searchReady = true; break; }
        await sleep(500);
      }
      if (!searchReady) {
        await chrome.tabs.update(tabId, { url: SEARCH_URL });
        await waitForTabComplete(tabId, 15000).catch(() => {});
        await sleep(2000); continue;
      }
      setLog(`CUFE ${i + 1}: Turnstile OK — buscando…`, 'ok');
      await sleep(300);

      // Llenar CUFE y Buscar
      const sr = await injectScript(tabId, pagePdfFillSearch, [cufe]);
      setLog(`CUFE ${i + 1}: fill → ok=${sr?.ok}`, sr?.ok ? 'ok' : 'err');
      if (!sr?.ok) {
        await sleep(1500);
        await chrome.tabs.update(tabId, { url: SEARCH_URL });
        await waitForTabComplete(tabId, 15000).catch(() => {});
        await sleep(1000); continue;
      }

      // Esperar AJAX y hacer clic en el enlace de resultado
      await sleep(2000 + Math.random() * 500);
      const linkResult = await injectScript(tabId, () => {
        const direct = document.querySelector('a[href*="ShowDocumentToPublic"]');
        if (direct) { direct.click(); return { clicked: true }; }
        const any = [...document.querySelectorAll('a[href]')]
          .find(a => a.href.includes('catalogo-vpfe') && !a.href.includes('SearchDocument') && !a.href.endsWith('/'));
        if (any) { any.click(); return { clicked: true }; }
        return { clicked: false };
      });
      setLog(`CUFE ${i + 1}: enlace → ${linkResult?.clicked ? 'OK' : 'no encontrado'}`, 'ok');
      if (!linkResult?.clicked) { continue; }

      // Esperar ShowDocumentToPublic
      try {
        await waitForTabComplete(tabId, 15000);
        await sleep(2000 + Math.random() * 500);
      } catch (_) { continue; }

      // Antibot en ShowDocumentToPublic
      await handleAntibotIfNeeded(tabId, cufe, SEARCH_URL);

      const urlAfter = (await chrome.tabs.get(tabId).catch(() => ({url:''}))).url || '';
      if (urlAfter.includes('/Login')) {
        await chrome.tabs.update(tabId, { url: SEARCH_URL });
        await waitForTabComplete(tabId, 15000).catch(() => {});
        await sleep(2000); continue;
      }

      // Esperar Turnstile de descarga — primera ronda (máx 40 s)
      let downloadReady = false;
      for (let p = 0; p < 80 && !stopRequested; p++) {
        const check = await injectScript(tabId, pagePdfCheckDownload);
        if (check?.ready) { downloadReady = true; break; }
        await sleep(500);
      }
      if (!downloadReady) {
        setLog(`CUFE ${i + 1}: Turnstile descarga no resuelto → SearchDocument…`, 'warn');
        await chrome.tabs.update(tabId, { url: SEARCH_URL });
        await waitForTabComplete(tabId, 15000).catch(() => {});
        await sleep(2000 + Math.random() * 1000); continue;
      }

      // Encolar descarga y enviar form
      let dlResolve;
      const dlPromise = new Promise(resolve => {
        dlResolve = resolve;
        pdfDownloadQueue.push({ label: cufe, resolve });
      });
      setLog(`CUFE ${i + 1}: descargando PDF…`, 'ok');
      const cr = await injectScript(tabId, pagePdfClickDownload);
      if (!cr?.ok) {
        // Quitar de la cola si no se envió
        const idx = pdfDownloadQueue.findIndex(p => p.resolve === dlResolve);
        if (idx >= 0) pdfDownloadQueue.splice(idx, 1);
        continue;
      }

      try {
        await Promise.race([dlPromise, sleep(25000).then(() => Promise.reject(new Error('timeout')))]);
        success = true;
      } catch (_) {
        const idx = pdfDownloadQueue.findIndex(p => p.resolve === dlResolve);
        if (idx >= 0) pdfDownloadQueue.splice(idx, 1);
        setLog(`CUFE ${i + 1}: timeout → reintentando…`, 'warn');
        await chrome.tabs.update(tabId, { url: SEARCH_URL });
        await waitForTabComplete(tabId, 15000).catch(() => {});
        await sleep(3000 + Math.random() * 2000);
      }
    } // /attempt

    if (success) {
      okCount++; itemDone[i] = true;
      setItemState(i, 'done', '✅', 'Descargado');
    } else if (!itemDone[i]) {
      errCount++;
      setItemState(i, 'error', '❌', 'Error');
    }
    updateProgress(okCount + errCount);
    document.getElementById('statOk').textContent = String(okCount);
    document.getElementById('statErr').textContent = String(Math.max(0, cufes.length - okCount));

    // Pausa entre CUFEs: 2-3 s
    if (!stopRequested && workQueue.length > 0) {
      const ms = 2000 + Math.random() * 1000;
      setLog(`W${tabId % 100}: pausa ${(ms/1000).toFixed(1)}s…`, 'ok');
      await sleep(ms);
    }
  } // /while workQueue
  // No cerramos la pestaña aquí; runPdfDownload hace el cleanup al final
}

// ── Loop principal del modo PDF ───────────────────────────────────────────────
async function runPdfDownload() {
  _logHistory.length = 0;
  const lh = document.getElementById('logHistory');
  if (lh) lh.value = '';
  setLog('Iniciando modo PDF…', 'ok');
  const pdfCufes = parsePdfCufeInput();
  if (!pdfCufes.length) { setLog('Selecciona primero un archivo con CUFEs.', 'err'); return; }

  cufes = pdfCufes;
  itemDone = new Array(cufes.length).fill(false);
  okCount = 0; errCount = 0; accumulatedMs = 0;
  renderList();
  document.getElementById('statTotal').textContent = cufes.length;
  document.getElementById('statOk').textContent = '0';
  document.getElementById('statErr').textContent = String(cufes.length);
  document.getElementById('progressCard').classList.remove('hidden');

  running = true; stopRequested = false;
  const btn = document.getElementById('actionBtn');
  btn.className = 'stop'; btn.textContent = '⏹ Detener'; btn.disabled = false;
  startTimer();
  downloadFolder = `FacturasDIAN-PDF-${new Date().toISOString().slice(0, 10)}`;

  const SEARCH_URL = 'https://catalogo-vpfe.dian.gov.co/User/SearchDocument';

  // Abrir o reutilizar tab del catálogo
  let workerTabId;
  try {
    const existing = await chrome.tabs.query({ url: 'https://catalogo-vpfe.dian.gov.co/*' });
    if (existing.length > 0) {
      workerTabId = existing[0].id;
      await chrome.tabs.update(workerTabId, { url: SEARCH_URL });
    } else {
      const tab = await chrome.tabs.create({ url: SEARCH_URL, active: false });
      workerTabId = tab.id;
    }
    await waitForTabComplete(workerTabId, 20000);
    await sleep(3000 + Math.random() * 1500); // WAF JS + tiempo humano
  } catch (e) {
    setLog('No se pudo abrir la página del catálogo DIAN: ' + e.message, 'err');
    running = false; stopTimer();
    btn.className = 'start'; btn.textContent = `Descargar ${cufes.length} PDF(s)`; btn.disabled = false;
    return;
  }

  const workerCount = parseInt(document.querySelector('input[name="workerCount"]:checked')?.value || '2', 10);
  setLog(`Iniciando descarga de ${cufes.length} PDF(s) con ${workerCount} pestañas…`, 'ok');

  // Cola compartida: todos los workers sacan de aquí con .shift() — balance automático
  const workQueue = cufes.map((_, i) => i);
  const extraTabs = [];

  // Abre una pestaña nueva, espera que cargue y lanza el worker loop
  const openWorker = async (delayMs) => {
    if (delayMs > 0) await sleep(delayMs);
    try {
      const t = await chrome.tabs.create({ url: SEARCH_URL, active: false });
      extraTabs.push(t.id);
      await waitForTabComplete(t.id, 20000);
      await sleep(2000 + Math.random() * 1000);
      await runPdfWorkerLoop(t.id, workQueue, SEARCH_URL);
    } catch (e) {
      setLog(`Worker extra: error abriendo pestaña — ${e.message}`, 'warn');
    }
  };

  // W0 = pestaña principal ya abierta; workers extra con 5s de escalonamiento entre sí
  const extraWorkers = [];
  for (let i = 1; i < workerCount; i++) extraWorkers.push(openWorker(5000 * i));
  await Promise.all([
    runPdfWorkerLoop(workerTabId, workQueue, SEARCH_URL),
    ...extraWorkers,
  ]);

  // ── Reintentos automáticos de fallidos (hasta 3 rondas extra) ────────────────
  const MAX_RETRY_ROUNDS = 3;
  const RETRY_PAUSE_MS   = 35000; // 35 s entre rondas

  for (let round = 1; round <= MAX_RETRY_ROUNDS && !stopRequested; round++) {
    // Índices que aún no se descargaron
    const retryIdx = cufes.map((_, i) => i).filter(i => !itemDone[i]);
    if (!retryIdx.length) break;

    setLog(`Ronda ${round}/${MAX_RETRY_ROUNDS}: ${retryIdx.length} fallido(s) — esperando ${RETRY_PAUSE_MS/1000}s antes de reintentar…`, 'warn');

    // Pausa antes de reintentar (da tiempo a que la DIAN libere cuota / WAF)
    for (let s = RETRY_PAUSE_MS; s > 0 && !stopRequested; s -= 5000) {
      await sleep(Math.min(5000, s));
      setLog(`Ronda ${round}: reintentando en ${Math.ceil(s/1000 - Math.min(5, s/1000))}s…`, 'warn');
    }
    if (stopRequested) break;

    // Resetear visual de los fallidos
    for (const i of retryIdx) {
      itemDone[i] = false;
      errCount = Math.max(0, errCount - 1);
      setItemState(i, 'paused', '🔄', `Reintento ${round}`);
    }

    setLog(`Ronda ${round}: reintentando ${retryIdx.length} CUFE(s)…`, 'ok');
    pdfDownloadQueue.length = 0;

    const retryQueue = [...retryIdx];
    const retryExtra = [];
    for (let w = 1; w < workerCount; w++) {
      retryExtra.push((async (delayMs) => {
        if (delayMs > 0) await sleep(delayMs);
        try {
          const t = await chrome.tabs.create({ url: SEARCH_URL, active: false });
          extraTabs.push(t.id);
          await waitForTabComplete(t.id, 20000);
          await sleep(2000 + Math.random() * 1000);
          await runPdfWorkerLoop(t.id, retryQueue, SEARCH_URL);
        } catch (e) {
          setLog(`Worker retry: error — ${e.message}`, 'warn');
        }
      })(5000 * w));
    }

    await Promise.all([
      runPdfWorkerLoop(workerTabId, retryQueue, SEARCH_URL),
      ...retryExtra,
    ]);
    pdfDownloadQueue.length = 0;
  }

  // ── Limpieza final ───────────────────────────────────────────────────────────
  running = false; stopRequested = false;
  stopTimer(); hidePause();

  for (const tid of extraTabs) try { await chrome.tabs.remove(tid); } catch (_) {}

  const pendingCount = cufes.length - okCount;
  btn.disabled = false;
  btn.className = okCount ? 'done' : 'start';
  btn.textContent = okCount
    ? `✓ ${okCount} PDFs descargados${pendingCount ? ` · ${pendingCount} sin descargar` : ''}`
    : `Sin descargas (${pendingCount} fallaron)`;
  setLog(
    okCount
      ? `✅ Listo: ${okCount}/${cufes.length} PDFs en Descargas/${downloadFolder}.${pendingCount ? ` · ${pendingCount} no se pudieron descargar.` : ''}`
      : `Sin descargas exitosas (${errCount} fallidas).`,
    pendingCount && okCount ? 'warn' : (okCount ? 'ok' : 'err')
  );
}

// ────────────────────────────────────────────────────────────────────────────
// Cliente de la API de ContaGO para la extensión.
//   · Activación: canjea el código CTG-XXXX-XXXX por un JWT (90 días) y lo guarda.
//   · Exportador DIAN: crea el job (sube el Excel de listado), recibe los CUFEs a
//     buscar, sube cada ZIP capturado, finaliza y descarga el Excel consolidado.
//
// El JWT se reutiliza tal cual contra /dian-ext/* (mismas licencias + NITs que el
// portal). La descarga de los bytes la hace popup.js vía chrome.debugger (CDP).
// ────────────────────────────────────────────────────────────────────────────
window.ContaGO = (function () {
  const DEFAULT_API = "https://contago-api-production.up.railway.app";
  const STORE_KEY = "contago_auth"; // { token, user, apiBase }

  async function getStore() {
    const { [STORE_KEY]: s } = await chrome.storage.local.get(STORE_KEY);
    return s || {};
  }
  async function setStore(patch) {
    const cur = await getStore();
    const next = { ...cur, ...patch };
    await chrome.storage.local.set({ [STORE_KEY]: next });
    return next;
  }
  async function getApiBase() {
    return (await getStore()).apiBase || DEFAULT_API;
  }
  async function setApiBase(url) {
    await setStore({ apiBase: String(url || "").replace(/\/+$/, "") || DEFAULT_API });
  }
  async function getAuth() {
    const s = await getStore();
    return { token: s.token || null, user: s.user || null, apiBase: s.apiBase || DEFAULT_API };
  }
  async function logout() {
    await deactivate(); // libera el slot en el servidor (best-effort)
    const s = await getStore();
    await chrome.storage.local.set({ [STORE_KEY]: { apiBase: s.apiBase } }); // conserva el endpoint
  }

  async function authHeaders() {
    const { token } = await getAuth();
    return token ? { Authorization: `Bearer ${token}` } : {};
  }

  // ── Activación ──────────────────────────────────────────────────────────────
  async function activate(code, deviceLabel) {
    const base = await getApiBase();
    const resp = await fetch(`${base}/ext/activate`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ code: String(code || "").trim().toUpperCase(), deviceLabel: deviceLabel || "" }),
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || !data.token) {
      throw new Error(data.message || data.detalle || "Código no válido o ya utilizado.");
    }
    await setStore({ token: data.token, user: data.user || null, deviceId: data.deviceId || null });
    return data.user || {};
  }

  // Desvincula este dispositivo del servidor (best-effort, no bloquea el logout).
  async function deactivate() {
    try {
      const { token } = await getStore();
      if (!token) return;
      const base = await getApiBase();
      await fetch(`${base}/ext/deactivate`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      });
    } catch (_) {}
  }

  // ── Herramientas habilitadas para el usuario (gating de modos) ──────────────
  async function getTools() {
    const base = await getApiBase();
    const resp = await fetch(`${base}/ext/tools`, { headers: { ...(await authHeaders()) } });
    if (!resp.ok) return { modes: {}, isAdmin: false };
    const d = await resp.json().catch(() => ({}));
    return { modes: d.modes || {}, isAdmin: !!d.isAdmin };
  }

  // ── Google Drive: conexión seleccionada por el usuario ──────────────────────
  async function driveStatus() {
    const base = await getApiBase();
    const resp = await fetch(`${base}/auth/google/status`, { headers: { ...(await authHeaders()) } });
    if (!resp.ok) return { connected: false, selectedConnectionId: null };
    const d = await resp.json().catch(() => ({}));
    return {
      connected: !!d.connected,
      selectedConnectionId: d.selectedConnectionId || null,
      connections: d.connections || [],
    };
  }

  // ── Preferencias del Exportador (las configura el usuario en el portal) ──────
  async function getExporterConfig() {
    const base = await getApiBase();
    const resp = await fetch(`${base}/ext/exporter-config`, { headers: { ...(await authHeaders()) } });
    if (!resp.ok) return { uploadToDrive: false, includeDriveLinks: false, driveConnectionId: null };
    const d = await resp.json().catch(() => ({}));
    return {
      uploadToDrive: !!d.uploadToDrive,
      includeDriveLinks: !!d.includeDriveLinks,
      driveConnectionId: d.driveConnectionId || null,
    };
  }

  // ── Exportador DIAN (reusa /dian-ext) ───────────────────────────────────────
  // Crea el job subiendo el Excel de listado. Devuelve { jobId, direction, records }.
  async function createExportJob({ excelBlob, filename, mode, startDate, endDate, driveConnectionId, uploadToDrive, includeDriveLinks }) {
    const base = await getApiBase();
    const fd = new FormData();
    fd.append("excel", excelBlob, filename || "listado.xlsx");
    if (mode) fd.append("mode", mode);
    if (startDate) fd.append("start_date", startDate);
    if (endDate) fd.append("end_date", endDate);
    if (uploadToDrive && driveConnectionId) {
      fd.append("upload_to_drive", "true");
      fd.append("drive_connection_id", driveConnectionId);
    }
    if (includeDriveLinks) fd.append("include_drive_links", "true");
    const resp = await fetch(`${base}/dian-ext/job`, { method: "POST", headers: { ...(await authHeaders()) }, body: fd });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || !data.jobId) throw new Error(data.detalle || "No se pudo crear el proceso en ContaGO.");
    return data; // { jobId, direction, records, totalProcessable, totalCufes, skipped, driveFolderUrl }
  }

  // Sube un ZIP (Uint8Array) ya capturado. trackId/docnum opcionales para el parseo.
  async function uploadZip(jobId, cufe, bytes, trackId, docnum) {
    const base = await getApiBase();
    const qs = new URLSearchParams({ cufe, trackId: trackId || "", docnum: docnum || "" }).toString();
    let resp = null;
    for (let a = 1; a <= 3; a++) {
      try {
        resp = await fetch(`${base}/dian-ext/job/${jobId}/zip?${qs}`, {
          method: "POST",
          headers: { ...(await authHeaders()), "Content-Type": "application/octet-stream" },
          body: bytes,
        });
        break;
      } catch (e) { if (a === 3) throw e; await new Promise((r) => setTimeout(r, 700 * a)); }
    }
    const data = await resp.json().catch(() => ({}));
    // OJO: el cuerpo trae su propio campo `status:"ok"`, por eso el código HTTP va
    // en `httpStatus` (si no, el spread lo pisaría y todo se leería como error).
    return { httpStatus: resp.status, ...data }; // + progress (ok/miss/received/total) o code NIT_FORBIDDEN
  }

  async function reportMiss(jobId, cufe) {
    const base = await getApiBase();
    const resp = await fetch(`${base}/dian-ext/job/${jobId}/miss?cufe=${encodeURIComponent(cufe)}`, {
      method: "POST", headers: { ...(await authHeaders()) },
    });
    return { httpStatus: resp.status, ...(await resp.json().catch(() => ({}))) };
  }

  async function finalizeJob(jobId) {
    const base = await getApiBase();
    const resp = await fetch(`${base}/dian-ext/job/${jobId}/finalize`, { method: "POST", headers: { ...(await authHeaders()) } });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) throw new Error(data.detalle || "No se pudo generar el Excel.");
    return data;
  }

  // Descarga el Excel consolidado y dispara la descarga local en el navegador.
  // Devuelve { url, filename } del Excel; la descarga la dispara popup.js para
  // poder fijar el nombre en onDeterminingFilename (el blob no conserva nombre).
  async function fetchResultExcel(jobId) {
    const base = await getApiBase();
    const resp = await fetch(`${base}/dian-ext/job/${jobId}/download`, { headers: { ...(await authHeaders()) } });
    if (!resp.ok) throw new Error("El Excel aún no está listo.");
    const cd = resp.headers.get("Content-Disposition") || "";
    const m = cd.match(/filename\*?=(?:UTF-8'')?"?([^";]+)"?/i);
    const filename = (m && decodeURIComponent(m[1])) || "Facturas DIAN.xlsx";
    const blob = await resp.blob();
    const url = URL.createObjectURL(blob);
    return { url, filename };
  }

  // Sube PDFs al backend, los parsea y devuelve { url, filename } del Excel resultante.
  async function parsePdfsToExcel(files) {
    const base = await getApiBase();
    const fd = new FormData();
    for (const f of files) fd.append("pdfs", f, f.name);
    const resp = await fetch(`${base}/api/pdf-parse/to-excel`, {
      method: "POST",
      headers: { ...(await authHeaders()) },
      body: fd,
    });
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      throw new Error(err.error || `Error ${resp.status} generando Excel`);
    }
    const cd = resp.headers.get("Content-Disposition") || "";
    const m = cd.match(/filename\*?=(?:UTF-8'')?"?([^";]+)"?/i);
    const filename = (m && decodeURIComponent(m[1])) || "Facturas PDF DIAN.xlsx";
    const blob = await resp.blob();
    const url = URL.createObjectURL(blob);
    const errors = resp.headers.get("X-Parse-Errors") || "";
    return { url, filename, errors };
  }

  // Sube PDFs + listado DIAN al backend y devuelve { url, filename, errors, matched, driveUploaded } del Excel resultante.
  // driveConnectionId opcional: si se proporciona, el backend sube los PDFs a Drive y añade enlaces al Excel.
  async function parsePdfsToExcelWithListado(pdfFiles, listadoFile, driveConnectionId) {
    const base = await getApiBase();
    const fd = new FormData();
    for (const f of pdfFiles) fd.append("pdfs", f, f.name);
    if (listadoFile) fd.append("listado", listadoFile, listadoFile.name);
    if (driveConnectionId) {
      fd.append("driveConnectionId", driveConnectionId);
      fd.append("includeDriveLinks", "true");
    }
    const resp = await fetch(`${base}/api/pdf-parse/to-excel`, {
      method: "POST",
      headers: { ...(await authHeaders()) },
      body: fd,
    });
    if (!resp.ok) {
      const err = await resp.json().catch(() => ({}));
      throw new Error(err.error || `Error ${resp.status} generando Excel`);
    }
    const cd = resp.headers.get("Content-Disposition") || "";
    const m = cd.match(/filename\*?=(?:UTF-8'')?"?([^";]+)"?/i);
    const filename = (m && decodeURIComponent(m[1])) || "Facturas PDF DIAN.xlsx";
    const blob = await resp.blob();
    const url = URL.createObjectURL(blob);
    const errors        = resp.headers.get("X-Parse-Errors") || "";
    const matched       = resp.headers.get("X-Listado-Matched") || "0";
    const driveUploading = resp.headers.get("X-Drive-Uploading") === "true";
    const driveJobId    = resp.headers.get("X-Drive-Job-Id") || null;
    return { url, filename, errors, matched, driveUploading, driveJobId };
  }

  async function getDriveProgress(jobId) {
    const base = await getApiBase();
    const resp = await fetch(`${base}/api/pdf-parse/drive-progress/${encodeURIComponent(jobId)}`, {
      headers: { ...(await authHeaders()) },
    });
    if (!resp.ok) return null;
    return resp.json().catch(() => null);
  }

  return {
    getAuth, setApiBase, getApiBase, logout, activate, deactivate,
    driveStatus, getTools, getExporterConfig, createExportJob, uploadZip, reportMiss, finalizeJob, fetchResultExcel,
    parsePdfsToExcel, parsePdfsToExcelWithListado, getDriveProgress,
  };
})();

// Se ejecuta en document_start, en el mundo MAIN de la página DIAN, ANTES que el
// código de la página. Neutraliza alert/confirm/prompt para que el navegador
// nunca abra un diálogo nativo (que robaría el foco y traería la ventana al
// frente). Guarda el último mensaje para que la extensión pueda registrarlo.
(function () {
  if (window.__alertAutoAccept) return;
  window.__alertAutoAccept = true;
  const remember = (m) => { try { localStorage.setItem("__lastAlert", String(m == null ? "" : m)); } catch (_) {} };
  window.alert = function (m) { remember(m); };
  window.confirm = function (m) { remember(m); return true; };  // aceptar siempre
  window.prompt = function (m, d) { return d == null ? "" : d; };
})();

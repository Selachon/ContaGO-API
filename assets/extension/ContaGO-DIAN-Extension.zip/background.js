// Abre la extensión cuando el portal de ContaGO lo solicita (botón "Abrir
// extensión"). chrome.sidePanel.open() exige un gesto de usuario que se pierde al
// venir desde la web vía mensajes; por eso, si el panel lateral falla, abrimos la
// herramienta en una ventana emergente (no requiere gesto y siempre funciona).
// Al instalar/actualizar, inyecta el puente en las pestañas del portal YA abiertas
// (Chrome no lo hace solo), para que detecten la extensión sin recargar la página.
const PORTAL_MATCHES = [
  "https://contago.com.co/*",
  "https://www.contago.com.co/*",
  "http://localhost:5173/*",
  "http://localhost:4173/*",
  "http://100.107.175.14:5173/*",
  "http://100.107.175.14:4173/*",
];
// Abrir como panel lateral al hacer clic en el ícono de la barra de herramientas
if (chrome.sidePanel?.setPanelBehavior) {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
}

chrome.runtime.onInstalled.addListener(() => {
  if (chrome.sidePanel?.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  }
  chrome.tabs.query({ url: PORTAL_MATCHES }, (tabs) => {
    for (const t of tabs || []) {
      if (t.id == null) continue;
      chrome.scripting.executeScript({ target: { tabId: t.id }, files: ["content-bridge.js"] }).catch(() => {});
    }
  });
});

// ── Enrutamiento de descargas ─────────────────────────────────────────────────
// popup.js guarda cdl_folder / cdl_label / cdl_pdf_label / cdl_trackmap en
// chrome.storage.session justo antes de cada descarga. background.js es el
// ÚNICO contexto que registra onDeterminingFilename para evitar que dos suggest()
// colisionen (en MV3 el service-worker gana y pisaría la sugerencia del panel).
chrome.downloads.onDeterminingFilename.addListener((item, suggest) => {
  chrome.storage.session
    .get(['cdl_folder', 'cdl_label', 'cdl_pdf_label', 'cdl_trackmap'])
    .then(s => {
      const folder = s.cdl_folder || '';

      // Modo PDF (catálogo VPFE)
      if (item.url && item.url.includes('/Document/DownloadPDF') && s.cdl_pdf_label) {
        suggest({ filename: `${folder || 'FacturasDIAN-PDF'}/${s.cdl_pdf_label}.pdf`, conflictAction: 'uniquify' });
        return;
      }

      // Descarga Masiva: ZIP por CUFE
      if (item.url && item.url.includes('DownloadZipFiles')) {
        const tmatch = item.url.match(/[?&]trackId=([^&]+)/i);
        const trackId = tmatch ? decodeURIComponent(tmatch[1]) : null;
        let label = s.cdl_label || '';
        // cdl_trackmap resuelve descargas lentas que llegan DESPUÉS de que
        // cdl_label ya avanzó al siguiente CUFE (descargas no serializadas).
        if (trackId && s.cdl_trackmap) {
          try {
            const tm = JSON.parse(s.cdl_trackmap);
            if (tm[trackId]) {
              label = tm[trackId];
              delete tm[trackId];
              chrome.storage.session.set({ cdl_trackmap: JSON.stringify(tm) }).catch(() => {});
            }
          } catch (_) {}
        }
        if (label) {
          suggest({ filename: `${folder || 'FacturasDIAN'}/${label}.zip`, conflictAction: 'uniquify' });
          return;
        }
      }

      suggest(); // para todo lo demás (blobs de Excel, etc.) Chrome usa el nombre por defecto
    })
    .catch(() => suggest());
  return true;
});

chrome.runtime.onMessage.addListener((msg, sender) => {
  if (!(msg && msg.type === "CONTAGO_OPEN_EXT" && sender.tab)) return;

  const openWindow = () => {
    chrome.windows.create({
      url: chrome.runtime.getURL("popup.html?mode=tab"),
      type: "popup",
      width: 470,
      height: 740,
    }).catch(() => {});
  };

  try {
    chrome.sidePanel.setOptions({ path: "popup.html?mode=panel", enabled: true });
    const p = chrome.sidePanel.open({ windowId: sender.tab.windowId });
    if (p && typeof p.catch === "function") p.catch(() => openWindow());
    else openWindow();
  } catch (_) {
    openWindow();
  }
});
